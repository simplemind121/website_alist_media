# website_alist_media — VPS 安装（对齐 prod-odoo）

模块：原生「选择媒体」AList 页签，**仅覆盖网站编辑器 / 通用 HTML 字段**，不涉及商品图片
（商品图片继续用 `media_picker`，两者不重叠、不冲突）。

## 1. 上传 zip

传到 VPS，例如：`/home/wuxialex0968/website_alist_media.zip`

```bash
scp website_alist_media.zip USER@VPS:/home/wuxialex0968/
```

## 2. 解压到 addons

```bash
rm -rf /opt/prod-apps/odoo/addons/website_alist_media
mv /home/wuxialex0968/website_alist_media.zip /opt/prod-apps/odoo/addons/website_alist_media.zip
cd /opt/prod-apps/odoo/addons
unzip -o website_alist_media.zip
rm website_alist_media.zip
ls -la /opt/prod-apps/odoo/addons/website_alist_media
```

确认目录内有 `__manifest__.py`。

## 3. 先在测试库验证，再上 letaoge

这一版已经不碰 `product.image` / `website_sale` 模板了，和 `media_picker` 冲突的可能性很低，
但里面仍有一部分（`media_dialog_extra_tabs` 资源注册、追加到 `MAIN_PLUGINS`）依赖 Odoo 内部
私有结构，没有 100% 把握在你这台 19.0 具体版本上一定生效。建议先复制一份 letaoge 到测试库装一次：

```bash
docker exec prod-odoo odoo -i website_alist_media -d letaoge_test \
  --db_host=odoo-db --db_port=5432 --db_user=odoo \
  --db_password='YOUR_DB_PASSWORD' \
  --no-http \
  --stop-after-init
```

安装完打开测试库，确认：

1. **网站编辑器**（非商品页）插入图片 → 「选择媒体」弹窗里出现 **AList** 标签页。
2. 选一张图插入后，查看元素 `src` 应为你配置的 CDN 域名，不是 `/web/image/...`。
3. 商品表单「添加媒体」和 `/shop` 店面图库**行为和装这个模块之前完全一样**（因为这版根本没碰这块）。
   如果这里出现异常，说明有别的地方冲突，先别往生产装。

确认没问题后再对 letaoge 正式库执行同样的 `-i`（首次安装）或 `-u`（升级）命令。

## 4. 容器内正式安装 / 升级

把 `YOUR_DB_PASSWORD` 换成你自己的库密码（不要贴到聊天里）：

**首次安装：**

```bash
docker exec prod-odoo odoo -i website_alist_media -d letaoge \
  --db_host=odoo-db --db_port=5432 --db_user=odoo \
  --db_password='YOUR_DB_PASSWORD' \
  --no-http \
  --stop-after-init

docker restart prod-odoo
```

**升级（从旧版 19.0.1.x 升级到本版 19.0.2.0.0 —— 会删除旧版新增的
`product.image.alist_cdn_url` / `alist_media_kind` 字段和 `website_sale` 模板继承，
如果旧版从未在这台机器上装过可以跳过这条，直接首次安装）：**

```bash
docker exec prod-odoo odoo -u website_alist_media -d letaoge \
  --db_host=odoo-db --db_port=5432 --db_user=odoo \
  --db_password='YOUR_DB_PASSWORD' \
  --no-http \
  --stop-after-init

docker restart prod-odoo
```

也可在后台：**应用** → 去掉「应用」筛选 → 更新应用列表 → 搜索 **Website AList Media** → 升级。

## 5. 后台配置媒体源

路径：**网站 → 配置 → AList Media → Media Sources** → 新建

| 字段 | 建议值（按你现网） |
|------|-------------------|
| 类型 | AList |
| API Base URL | `https://one.051288888.xyz` |
| Token | Alist 后台 API Token（或填 `secret_ref` 环境变量名） |
| Root path | 媒体库起始目录，如 `/media` |
| CDN / Public Base URL | `https://media.051288888.xyz` |
| CDN Strip Path Prefix | `/d` |
| Trusted domains | `one.051288888.xyz` 与 `media.051288888.xyz` |

保存后点 **Test Connection**，应为 Connected / ok。

生产更稳妥：Token 放进容器环境变量，源上只填 `secret_ref`（如 `WEBSITE_ALIST_TOKEN_MAIN`），
不要把 token 写进数据库字段。

## 6. 网站 CSP（需要时）

若页面图片被浏览器拦，在网站设置里把 CDN 域名加入：

- `img-src`：`https://media.051288888.xyz`
- `media-src`：`https://media.051288888.xyz`（视频）

## 注意

- 商品图片相关功能一律不受影响，继续用 `media_picker`。
- 数据库名、容器名若与上面不同，改成你机器上的实际值（`docker ps` 看容器名）。
