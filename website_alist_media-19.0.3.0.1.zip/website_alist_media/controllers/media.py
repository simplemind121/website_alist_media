# -*- coding: utf-8 -*-
"""JSON routes for the AList MediaDialog tab. Never returns tokens/secrets."""
import logging

from odoo import http
from odoo.http import request
from odoo.exceptions import AccessError, UserError

from ..models.alist_client import AlistError

_logger = logging.getLogger(__name__)


def _require_editor():
    """Website designers / system admins may browse sources."""
    user = request.env.user
    if not (
        user.has_group('website.group_website_designer')
        or user.has_group('base.group_system')
    ):
        raise AccessError('Website designer rights required.')


def _source(source_id):
    source = request.env['website.alist.media.source'].sudo().browse(int(source_id))
    if not source.exists() or not source.active:
        raise UserError('Media source not found or inactive.')
    return source


def _safe_error(exc):
    msg = str(exc)
    # Never leak env names that might look like secrets in odd messages
    return {'error': msg}


class WebsiteAlistMediaController(http.Controller):

    @http.route(
        '/website_alist_media/sources',
        type='jsonrpc', auth='user', methods=['POST'],
    )
    def sources(self):
        _require_editor()
        Source = request.env['website.alist.media.source'].sudo()
        rows = Source.search([('active', '=', True)], order='sequence, id')
        return {
            'sources': [{
                'id': s.id,
                'name': s.name,
                'source_type': s.source_type,
                'root_path': s.root_path or '/',
                'page_size': s.page_size or 30,
                # Intentionally omit token, secret_ref, s3_secret_key, base_url internals
            } for s in rows],
        }

    @http.route(
        '/website_alist_media/list',
        type='jsonrpc', auth='user', methods=['POST'],
    )
    def list_media(self, source_id=None, path='/', page=1, per_page=None, query=None, **kwargs):
        _require_editor()
        source = _source(source_id)
        try:
            data = source.list_media(
                path=path or source.root_path or '/',
                page=page,
                per_page=per_page,
                query=query,
            )
        except AlistError as exc:
            return _safe_error(exc)
        except UserError as exc:
            return _safe_error(exc)
        return {'ok': True, 'source_id': source.id, **data}

    @http.route(
        '/website_alist_media/search',
        type='jsonrpc', auth='user', methods=['POST'],
    )
    def search_media(self, source_id=None, query='', page=1, per_page=None, **kwargs):
        return self.list_media(
            source_id=source_id, path='/', page=page, per_page=per_page, query=query,
        )

    @http.route(
        '/website_alist_media/resolve',
        type='jsonrpc', auth='user', methods=['POST'],
    )
    def resolve_media(self, source_id=None, item_ref=None, **kwargs):
        _require_editor()
        source = _source(source_id)
        try:
            result = source.resolve_media(item_ref)
        except AlistError as exc:
            return _safe_error(exc)
        except UserError as exc:
            return _safe_error(exc)
        return {'ok': True, 'source_id': source.id, **result}
