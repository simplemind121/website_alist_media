# -*- coding: utf-8 -*-
"""Minimal S3-compatible list/resolve (boto3 optional; requests ListObjects fallback)."""
from __future__ import annotations

import logging
import os
from urllib.parse import quote
from xml.etree import ElementTree as ET

import requests

from .cdn_utils import (
    DEFAULT_IMAGE_EXT,
    DEFAULT_VIDEO_EXT,
    guess_media_type,
    normalize_path,
    parse_extensions,
)
from .alist_client import AlistError, REQUEST_TIMEOUT

_logger = logging.getLogger(__name__)


def _creds(source):
    access = (getattr(source, 'token', None) or '').strip()
    secret = (getattr(source, 's3_secret_key', None) or '').strip()
    ref = (getattr(source, 'secret_ref', None) or '').strip()
    if ref:
        access = access or (os.environ.get(ref) or '').strip()
        secret = secret or (
            os.environ.get(ref + '_SECRET')
            or os.environ.get(ref.replace('ACCESS_KEY', 'SECRET_KEY'))
            or ''
        ).strip()
    if not access:
        access = (os.environ.get('WEBSITE_ALIST_S3_ACCESS_KEY') or '').strip()
        secret = secret or (os.environ.get('WEBSITE_ALIST_S3_SECRET_KEY') or '').strip()
    return access, secret


def _public_url(source, key: str) -> str:
    base = (source.cdn_base_url or source.base_url or '').rstrip('/')
    if not base:
        raise AlistError('S3 cdn_base_url (public URL) is required.')
    if not base.lower().startswith(('http://', 'https://')):
        raise AlistError(f'S3 public URL must be absolute http(s) (got: {base!r}).')
    return f'{base}/{quote(key.lstrip("/"), safe="/")}'


def _prefix(source):
    raw = (source.s3_prefix or source.root_path or '').strip().strip('/')
    return raw + '/' if raw else ''


def list_dir(source, path='/', page=1, per_page=30, use_cache=True):
    # path is treated as additional prefix under configured s3_prefix/root
    root = source.root_path or '/'
    path = normalize_path(path, root)
    page = max(1, int(page or 1))
    per_page = max(1, min(int(per_page or source.page_size or 30), 200))
    prefix = _prefix(source)
    rel = path.strip('/')
    list_prefix = prefix + (rel + '/' if rel else '')

    image_ext, video_ext = (
        parse_extensions(getattr(source, 'image_extensions', None), DEFAULT_IMAGE_EXT),
        parse_extensions(getattr(source, 'video_extensions', None), DEFAULT_VIDEO_EXT),
    )

    try:
        items = _list_boto3(source, list_prefix, path) or _list_requests(source, list_prefix, path)
    except AlistError:
        raise
    except Exception as exc:
        raise AlistError(f'S3 list failed: {exc}') from exc

    # Filter to media + dirs; simple pagination in-memory
    filtered = []
    for it in items:
        if it.get('is_dir'):
            filtered.append(it)
            continue
        mt = guess_media_type(it.get('name') or '', image_ext, video_ext)
        if mt == 'unknown':
            continue
        it['media_type'] = mt
        filtered.append(it)

    start = (page - 1) * per_page
    page_items = filtered[start:start + per_page]
    return {
        'items': page_items,
        'total': len(filtered),
        'page': page,
        'per_page': per_page,
        'path': path,
    }


def _list_boto3(source, list_prefix, path):
    try:
        import boto3
        from botocore.config import Config
    except ImportError:
        return None
    access, secret = _creds(source)
    if not access or not secret:
        raise AlistError('S3 credentials missing (token/secret_ref or env).')
    client = boto3.client(
        's3',
        endpoint_url=(source.s3_endpoint or source.base_url or None),
        aws_access_key_id=access,
        aws_secret_access_key=secret,
        region_name=source.s3_region or 'auto',
        config=Config(signature_version='s3v4', connect_timeout=REQUEST_TIMEOUT, read_timeout=REQUEST_TIMEOUT),
    )
    bucket = source.s3_bucket
    if not bucket:
        raise AlistError('S3 bucket is not configured.')
    resp = client.list_objects_v2(Bucket=bucket, Prefix=list_prefix, Delimiter='/', MaxKeys=200)
    items = []
    for cp in resp.get('CommonPrefixes') or []:
        pfx = cp.get('Prefix') or ''
        name = pfx[len(list_prefix):].rstrip('/')
        if not name:
            continue
        full = path.rstrip('/') + '/' + name if path != '/' else '/' + name
        items.append({'ref': full, 'name': name, 'is_dir': True, 'media_type': 'unknown', 'size': None, 'preview_url': None})
    for obj in resp.get('Contents') or []:
        key = obj.get('Key') or ''
        if key.endswith('/'):
            continue
        name = key.rsplit('/', 1)[-1]
        full = path.rstrip('/') + '/' + name if path != '/' else '/' + name
        url = _public_url(source, key)
        items.append({
            'ref': full,
            'name': name,
            'is_dir': False,
            'media_type': 'unknown',
            'size': obj.get('Size'),
            'preview_url': url,
            'url': url,
            's3_key': key,
        })
    return items


def _list_requests(source, list_prefix, path):
    """Anonymous/public ListObjects XML fallback (no signing). Prefer boto3."""
    endpoint = (source.s3_endpoint or source.base_url or '').rstrip('/')
    bucket = source.s3_bucket
    if not endpoint or not bucket:
        raise AlistError('S3 endpoint and bucket are required.')
    url = f'{endpoint}/{bucket}'
    try:
        resp = requests.get(
            url,
            params={'list-type': '2', 'prefix': list_prefix, 'delimiter': '/', 'max-keys': '200'},
            timeout=REQUEST_TIMEOUT,
        )
    except requests.exceptions.RequestException as exc:
        raise AlistError(f'Could not reach S3: {exc}') from exc
    if resp.status_code != 200:
        raise AlistError(f'S3 returned HTTP {resp.status_code} (install boto3 for signed list).')
    try:
        root = ET.fromstring(resp.content)
    except ET.ParseError as exc:
        raise AlistError('S3 returned invalid XML.') from exc
    ns = ''
    if root.tag.startswith('{'):
        ns = root.tag.split('}')[0] + '}'
    items = []
    for cp in root.findall(f'{ns}CommonPrefixes'):
        pfx = (cp.findtext(f'{ns}Prefix') or '')
        name = pfx[len(list_prefix):].rstrip('/')
        if not name:
            continue
        full = path.rstrip('/') + '/' + name if path != '/' else '/' + name
        items.append({'ref': full, 'name': name, 'is_dir': True, 'media_type': 'unknown', 'size': None, 'preview_url': None})
    for contents in root.findall(f'{ns}Contents'):
        key = contents.findtext(f'{ns}Key') or ''
        if key.endswith('/'):
            continue
        name = key.rsplit('/', 1)[-1]
        full = path.rstrip('/') + '/' + name if path != '/' else '/' + name
        url = _public_url(source, key)
        size_txt = contents.findtext(f'{ns}Size')
        items.append({
            'ref': full,
            'name': name,
            'is_dir': False,
            'media_type': 'unknown',
            'size': int(size_txt) if size_txt and size_txt.isdigit() else None,
            'preview_url': url,
            'url': url,
            's3_key': key,
        })
    return items


def search(source, query, page=1, per_page=30):
    query = (query or '').strip().lower()
    listed = list_dir(source, path=source.root_path or '/', page=1, per_page=200)
    if not query:
        return listed
    filtered = [i for i in listed['items'] if query in (i.get('name') or '').lower()]
    page = max(1, int(page or 1))
    per_page = max(1, min(int(per_page or 30), 200))
    start = (page - 1) * per_page
    return {
        'items': filtered[start:start + per_page],
        'total': len(filtered),
        'page': page,
        'per_page': per_page,
        'path': listed.get('path'),
    }


def resolve(source, item_ref):
    root = source.root_path or '/'
    path = normalize_path(item_ref, root)
    prefix = _prefix(source)
    rel = path.strip('/')
    key = prefix + rel
    url = _public_url(source, key)
    name = path.rsplit('/', 1)[-1] or key.rsplit('/', 1)[-1]
    image_ext, video_ext = (
        parse_extensions(getattr(source, 'image_extensions', None), DEFAULT_IMAGE_EXT),
        parse_extensions(getattr(source, 'video_extensions', None), DEFAULT_VIDEO_EXT),
    )
    media_type = guess_media_type(name, image_ext, video_ext)
    return {
        'url': url,
        'media_type': media_type,
        'name': name,
        'ref': path,
        'preview_url': url if media_type == 'image' else None,
    }


def health(source):
    import time
    t0 = time.monotonic()
    try:
        list_dir(source, path=source.root_path or '/', page=1, per_page=1, use_cache=False)
        return {'status': 'ok', 'latency_ms': int((time.monotonic() - t0) * 1000)}
    except AlistError as exc:
        return {
            'status': 'down',
            'latency_ms': int((time.monotonic() - t0) * 1000),
            'message': str(exc),
        }
