# -*- coding: utf-8 -*-
"""Thin AList HTTP client (server-side only). Tokens never leave the worker."""
from __future__ import annotations

import logging
import os
import time

import requests

from .cdn_utils import (
    DEFAULT_IMAGE_EXT,
    DEFAULT_VIDEO_EXT,
    guess_media_type,
    normalize_path,
    parse_extensions,
    rewrite_url_to_cdn,
)

_logger = logging.getLogger(__name__)

REQUEST_TIMEOUT = 5
CACHE_TTL = 20
BREAKER_FAILURE_THRESHOLD = 3
BREAKER_COOLDOWN = 30

_breaker_failures = {}
_breaker_open_until = {}
_list_cache = {}


class AlistError(Exception):
    """Safe-to-show connectivity/API error (never includes secrets)."""


def _breaker_check(source_id):
    open_until = _breaker_open_until.get(source_id)
    if open_until and time.monotonic() < open_until:
        raise AlistError(
            "This AList connection failed recently and is temporarily disabled. "
            "Please try again in a few seconds."
        )


def _breaker_record_success(source_id):
    _breaker_failures.pop(source_id, None)
    _breaker_open_until.pop(source_id, None)


def _breaker_record_failure(source_id):
    now = time.monotonic()
    failures = [t for t in _breaker_failures.get(source_id, []) if now - t < 60]
    failures.append(now)
    _breaker_failures[source_id] = failures
    if len(failures) >= BREAKER_FAILURE_THRESHOLD:
        _breaker_open_until[source_id] = now + BREAKER_COOLDOWN


def _token_for(source):
    token = (getattr(source, 'token', None) or '').strip()
    if token:
        return token
    ref = (getattr(source, 'secret_ref', None) or '').strip()
    if ref:
        return (os.environ.get(ref) or '').strip() or None
    return None


def _request(source, method, api_path, json_body):
    source_id = source.id or 0
    _breaker_check(source_id)
    base = (source.base_url or '').rstrip('/')
    if not base:
        raise AlistError('AList base_url is not configured.')
    url = base + api_path
    headers = {'Content-Type': 'application/json'}
    token = _token_for(source)
    if token:
        headers['Authorization'] = token
    try:
        resp = requests.request(
            method, url, json=json_body, headers=headers, timeout=REQUEST_TIMEOUT,
        )
    except requests.exceptions.Timeout:
        _breaker_record_failure(source_id)
        raise AlistError(f'Connection to AList timed out after {REQUEST_TIMEOUT}s.')
    except requests.exceptions.RequestException as exc:
        _breaker_record_failure(source_id)
        raise AlistError(f'Could not reach AList: {exc}')
    if resp.status_code != 200:
        _breaker_record_failure(source_id)
        raise AlistError(f'AList returned HTTP {resp.status_code}.')
    try:
        payload = resp.json()
    except ValueError:
        _breaker_record_failure(source_id)
        raise AlistError('AList returned an unexpected (non-JSON) response.')
    if payload.get('code') != 200:
        _breaker_record_failure(source_id)
        raise AlistError(payload.get('message') or 'AList API error.')
    _breaker_record_success(source_id)
    return payload.get('data') or {}


def _maybe_cdn(source, url):
    if not url or not getattr(source, 'cdn_base_url', None):
        return url
    return rewrite_url_to_cdn(
        url,
        source.cdn_base_url,
        getattr(source, 'cdn_strip_path_prefix', None) or '/d',
    )


def _exts(source):
    return (
        parse_extensions(getattr(source, 'image_extensions', None), DEFAULT_IMAGE_EXT),
        parse_extensions(getattr(source, 'video_extensions', None), DEFAULT_VIDEO_EXT),
    )


def list_dir(source, path='/', page=1, per_page=30, use_cache=True):
    root = source.root_path or '/'
    path = normalize_path(path, root)
    page = max(1, int(page or 1))
    per_page = max(1, min(int(per_page or source.page_size or 30), 200))
    source_id = source.id or 0
    cache_key = (source_id, path, page, per_page)
    if use_cache:
        cached = _list_cache.get(cache_key)
        if cached and time.monotonic() - cached[0] < CACHE_TTL:
            return cached[1]

    data = _request(source, 'POST', '/api/fs/list', {
        'path': path,
        'page': page,
        'per_page': per_page,
        'refresh': False,
    })
    image_ext, video_ext = _exts(source)
    items = []
    for entry in data.get('content') or []:
        name = entry.get('name') or ''
        is_dir = bool(entry.get('is_dir'))
        full = path.rstrip('/') + '/' + name if path != '/' else '/' + name
        content_type = entry.get('type') or entry.get('content_type') or entry.get('mime')
        media_type = (
            'unknown' if is_dir
            else guess_media_type(name, image_ext, video_ext, content_type=content_type)
        )
        sign = entry.get('sign')
        if sign is not None:
            sign = str(sign)
        thumb = entry.get('thumb') or entry.get('thumbnail')
        preview = None
        if isinstance(thumb, str) and thumb.startswith(('http://', 'https://')):
            preview = _maybe_cdn(source, thumb)
        elif media_type == 'image':
            base = (source.base_url or '').rstrip('/')
            q = f'?sign={sign}' if sign else ''
            preview = _maybe_cdn(source, f'{base}/d{full}{q}') if base else None
        items.append({
            'ref': full,
            'name': name,
            'is_dir': is_dir,
            'media_type': media_type,
            'size': entry.get('size'),
            'preview_url': preview,
            'sign': sign,
        })
    result = {
        'items': items,
        'total': int(data.get('total') or len(items)),
        'page': page,
        'per_page': per_page,
        'path': path,
    }
    _list_cache[cache_key] = (time.monotonic(), result)
    return result


def search(source, query, page=1, per_page=30):
    query = (query or '').strip().lower()
    listed = list_dir(source, path=source.root_path or '/', page=1, per_page=200)
    if not query:
        return listed
    filtered = [i for i in listed['items'] if query in (i.get('name') or '').lower()]
    page = max(1, int(page or 1))
    per_page = max(1, min(int(per_page or 30), 200))
    start = (page - 1) * per_page
    return {
        'items': filtered[start:start + per_page],
        'total': len(filtered),
        'page': page,
        'per_page': per_page,
        'path': listed.get('path'),
    }


def resolve(source, item_ref):
    root = source.root_path or '/'
    path = normalize_path(item_ref, root)
    data = _request(source, 'POST', '/api/fs/get', {'path': path})
    raw_url = data.get('raw_url') or data.get('url')
    if not raw_url:
        raise AlistError('AList did not return a raw_url for this file.')
    raw_url = _maybe_cdn(source, raw_url)
    name = data.get('name') or os.path.basename(path)
    image_ext, video_ext = _exts(source)
    content_type = data.get('type') or data.get('content_type') or data.get('mime')
    media_type = guess_media_type(name, image_ext, video_ext, content_type=content_type)
    return {
        'url': raw_url,
        'media_type': media_type,
        'name': name,
        'ref': path,
        'preview_url': raw_url if media_type == 'image' else None,
    }


def health(source):
    t0 = time.monotonic()
    try:
        root = normalize_path(source.root_path or '/', source.root_path or '/')
        _request(source, 'POST', '/api/fs/list', {
            'path': root, 'page': 1, 'per_page': 1, 'refresh': False,
        })
        return {'status': 'ok', 'latency_ms': int((time.monotonic() - t0) * 1000)}
    except AlistError as exc:
        return {
            'status': 'down',
            'latency_ms': int((time.monotonic() - t0) * 1000),
            'message': str(exc),
        }
