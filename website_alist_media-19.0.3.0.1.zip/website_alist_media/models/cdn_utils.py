# -*- coding: utf-8 -*-
"""Pure helpers: path normalize, CDN rewrite, host allowlist (unit-testable)."""
from __future__ import annotations

from urllib.parse import urlparse, urlunparse

DEFAULT_IMAGE_EXT = ('.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.svg')
DEFAULT_VIDEO_EXT = ('.mp4', '.mov', '.webm', '.mkv', '.avi', '.m4v', '.ogg', '.ogv')


def normalize_path(path: str, root_path: str = '/') -> str:
    """Normalize path and reject ``..`` escape outside root_path."""
    root = '/' + (root_path or '/').strip('/')
    if root != '/':
        root = root.rstrip('/')
    raw = (path or '/').replace('\\', '/')
    parts = []
    for seg in raw.split('/'):
        if not seg or seg == '.':
            continue
        if seg == '..':
            if parts:
                parts.pop()
            continue
        parts.append(seg)
    joined = '/' + '/'.join(parts) if parts else '/'
    if root == '/':
        return joined
    if joined == root or joined.startswith(root + '/'):
        return joined
    return root


def rewrite_url_to_cdn(url: str, cdn_base_url: str, strip_path_prefix: str = '/d') -> str:
    """Rewrite AList raw/direct URL onto CDN base; keep query (sign).

    ``https://one.../d/b2/FILE.jpg?sign=...``
    → ``https://media.../b2/FILE.jpg?sign=...``
    """
    cdn = (cdn_base_url or '').strip().rstrip('/')
    if not cdn or not url:
        return url
    parsed = urlparse(url.strip())
    if not parsed.scheme or not parsed.netloc:
        return url
    path = parsed.path or '/'
    strip = (strip_path_prefix or '').rstrip('/')
    if strip:
        if path == strip:
            path = '/'
        elif path.startswith(strip + '/'):
            path = path[len(strip):] or '/'
    cdn_parsed = urlparse(cdn if '://' in cdn else 'https://' + cdn)
    return urlunparse((
        cdn_parsed.scheme or parsed.scheme or 'https',
        cdn_parsed.netloc,
        path,
        '',
        parsed.query,
        '',
    ))


def guess_media_type(name: str, image_ext=None, video_ext=None, content_type: str | None = None) -> str:
    """Classify by filename extension, with optional MIME ``content_type`` hint."""
    lower = (name or '').lower()
    image_ext = image_ext or DEFAULT_IMAGE_EXT
    video_ext = video_ext or DEFAULT_VIDEO_EXT
    if any(lower.endswith(ext) for ext in image_ext):
        return 'image'
    if any(lower.endswith(ext) for ext in video_ext):
        return 'video'
    ctype = (content_type or '').split(';')[0].strip().lower()
    if ctype.startswith('image/'):
        return 'image'
    if ctype.startswith('video/'):
        return 'video'
    return 'unknown'


def parse_extensions(csv_text: str, defaults: tuple) -> tuple:
    if not (csv_text or '').strip():
        return defaults
    parts = []
    for raw in csv_text.replace(';', ',').split(','):
        ext = raw.strip().lower()
        if not ext:
            continue
        if not ext.startswith('.'):
            ext = '.' + ext
        parts.append(ext)
    return tuple(parts) if parts else defaults


def host_from_url(url: str) -> str:
    if not url:
        return ''
    try:
        parsed = urlparse(url if '://' in url else 'https://' + url)
        return (parsed.hostname or '').lower()
    except Exception:
        return ''


def is_host_allowed(hostname: str, allowed_hosts: set) -> bool:
    """Exact match or subdomain of an allowlisted host."""
    hostname = (hostname or '').lower().rstrip('.')
    if not hostname:
        return False
    for domain in allowed_hosts:
        domain = (domain or '').lower().rstrip('.')
        if not domain:
            continue
        if hostname == domain or hostname.endswith('.' + domain):
            return True
    return False


def collect_allowed_hosts(*url_or_host_fields, extra_domains_text: str = '') -> set:
    hosts = set()
    for value in url_or_host_fields:
        if not value:
            continue
        h = host_from_url(value) if '://' in value or '/' in value else value.lower().strip()
        if h:
            hosts.add(h)
    for line in (extra_domains_text or '').splitlines():
        line = line.strip().lower()
        if line and not line.startswith('#'):
            hosts.add(line.split('/')[0].split(':')[0])
    return hosts
