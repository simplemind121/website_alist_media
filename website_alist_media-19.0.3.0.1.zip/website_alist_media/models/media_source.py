# -*- coding: utf-8 -*-
from urllib.parse import urlparse

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from . import alist_client
from . import s3_client
from .cdn_utils import collect_allowed_hosts, host_from_url, is_host_allowed


class WebsiteAlistMediaSource(models.Model):
    """Configured AList / S3 media source for the MediaDialog AList tab.

    Secrets (token / S3 keys) are server-only: never returned by JSON controllers.
    """
    _name = 'website.alist.media.source'
    _description = 'AList / S3 Media Source'
    _order = 'sequence, id'

    name = fields.Char(required=True)
    active = fields.Boolean(default=True)
    sequence = fields.Integer(default=10)
    source_type = fields.Selection([
        ('alist', 'AList'),
        ('s3', 'S3 Compatible (B2/R2/MinIO)'),
    ], required=True, default='alist')

    base_url = fields.Char(
        string='API Base URL',
        help='AList base URL (https://one.example.com) or S3 API endpoint. Server-side only.',
    )
    token = fields.Char(
        string='Token / Access Key',
        help='AList token or S3 access key. Prefer secret_ref for production. Never sent to browser.',
    )
    secret_ref = fields.Char(
        string='Secret Reference (env)',
        help='Environment variable name for the token/access key. '
             'S3 secret key is read from secret_ref+"_SECRET" or ACCESS→SECRET swap.',
    )
    s3_secret_key = fields.Char(
        string='S3 Secret Key',
        help='Optional plaintext secret (prefer env via secret_ref). Server-only.',
    )
    root_path = fields.Char(string='Root Path', default='/')
    cdn_base_url = fields.Char(
        string='CDN / Public Base URL',
        help='Permanent public CDN origin, e.g. https://media.example.com (no trailing slash).',
    )
    cdn_strip_path_prefix = fields.Char(
        string='CDN Strip Path Prefix',
        default='/d',
        help='Path prefix stripped when rewriting AList /d/... URLs onto the CDN (default /d).',
    )
    trusted_domains = fields.Text(
        string='Extra Trusted Domains',
        help='One host per line. Resolved URLs must match configured source/CDN hosts '
             '(or these extras). SSRF protection.',
    )
    image_extensions = fields.Char(
        string='Image Extensions',
        default='.jpg,.jpeg,.png,.webp,.gif,.bmp,.svg',
    )
    video_extensions = fields.Char(
        string='Video Extensions',
        default='.mp4,.mov,.webm,.mkv,.avi,.m4v,.ogg,.ogv',
    )
    page_size = fields.Integer(default=30)

    # S3-specific
    s3_endpoint = fields.Char(string='S3 Endpoint')
    s3_bucket = fields.Char(string='S3 Bucket')
    s3_region = fields.Char(string='S3 Region', default='auto')
    s3_prefix = fields.Char(string='S3 Prefix')

    state = fields.Selection([
        ('untested', 'Not Tested'),
        ('ok', 'Connected'),
        ('error', 'Error'),
    ], default='untested', readonly=True, copy=False)
    last_test_message = fields.Char(readonly=True, copy=False)
    last_test_date = fields.Datetime(readonly=True, copy=False)

    @api.constrains('base_url', 'cdn_base_url', 's3_endpoint')
    def _check_urls(self):
        for rec in self:
            for field_name in ('base_url', 'cdn_base_url', 's3_endpoint'):
                val = rec[field_name]
                if not val:
                    continue
                parsed = urlparse(val if '://' in val else 'https://' + val)
                if parsed.scheme not in ('http', 'https') or not parsed.netloc:
                    raise ValidationError(_('%s must be an absolute http(s) URL.') % field_name)

    def _allowed_hosts(self):
        self.ensure_one()
        return collect_allowed_hosts(
            self.base_url,
            self.cdn_base_url,
            self.s3_endpoint,
            extra_domains_text=self.trusted_domains or '',
        )

    def assert_url_allowed(self, url):
        """Raise if URL host is not in the configured allowlist (SSRF)."""
        self.ensure_one()
        host = host_from_url(url)
        if not is_host_allowed(host, self._allowed_hosts()):
            raise UserError(_(
                'Resolved URL host %(host)s is not allowlisted for source "%(name)s".'
            ) % {'host': host or '(empty)', 'name': self.name})

    def _client_module(self):
        self.ensure_one()
        if self.source_type == 's3':
            return s3_client
        return alist_client

    def action_test_connection(self):
        self.ensure_one()
        client = self._client_module()
        result = client.health(self)
        if result.get('status') == 'ok':
            self.write({
                'state': 'ok',
                'last_test_message': _('Connection successful (%s ms).') % result.get('latency_ms', '?'),
                'last_test_date': fields.Datetime.now(),
            })
        else:
            self.write({
                'state': 'error',
                'last_test_message': result.get('message') or _('Connection failed.'),
                'last_test_date': fields.Datetime.now(),
            })

    def list_media(self, path='/', page=1, per_page=None, query=None):
        self.ensure_one()
        client = self._client_module()
        per_page = per_page or self.page_size or 30
        if query:
            return client.search(self, query, page=page, per_page=per_page)
        return client.list_dir(self, path=path, page=page, per_page=per_page)

    def resolve_media(self, item_ref):
        self.ensure_one()
        client = self._client_module()
        result = client.resolve(self, item_ref)
        self.assert_url_allowed(result['url'])
        return result
