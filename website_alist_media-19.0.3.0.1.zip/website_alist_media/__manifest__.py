# -*- coding: utf-8 -*-
{
    'name': 'Website AList Media (MediaDialog)',
    'summary': 'Add an AList tab to Odoo 19 MediaDialog (website editor / HTML fields); insert CDN URLs without filestore.',
    'description': """
Website AList Media
===================
Extends the native Odoo 19 「选择媒体」 MediaDialog with an **AList** tab
(and optional S3-compatible sources) for the **website builder and generic
HTML fields** (page content, blog posts, etc). Selected images/videos become
permanent CDN public URLs inserted directly into the HTML — no binary is
written to the Odoo filestore.

* Backend media sources (AList / S3): base URL, secrets server-only, CDN rewrite
* JSON list/search/resolve controllers (≈5s timeout; tokens never to browser)
* OWL tab via ``media_dialog_extra_tabs`` (html_editor Plugin API, Odoo 19.0)
* ``onlyImages`` MediaDialog patch so gallery Add / cover / bg-image also show AList
* Body/block video insert: AList can select CDN mp4/webm → ``<video controls playsinline>``
* Section background video: AList tab beside Videos; direct CDN URL via ``<video autoplay muted loop>``

Scope note
----------
This module deliberately does **not** touch ``product.image``, the
``website_sale.shop_product_image`` / ``carousel_product_indicators``
templates, or the product form's 「添加媒体」 CustomMediaDialog flow.
Those are already covered in this environment by the existing
``media_picker`` module. Adding this module's own copy of that same
integration (as an earlier draft of this module did) would have installed
a second ``alist_cdn_url``/``alist_media_kind`` field on ``product.image``
and a second, conflicting xpath ``position="replace"`` on the exact same
storefront templates ``media_picker`` already patches — which on install/
upgrade would very likely raise a view-inheritance "element not found"
error, or at best silently fight with the existing customization. This
module is intentionally scoped to only the general content editor, which
``media_picker`` does not touch, so the two can install side by side.
    """,
    'version': '19.0.3.0.1',
    'category': 'Website/Website',
    'author': 'Custom Development',
    'license': 'LGPL-3',
    'depends': [
        'html_editor',
        'html_builder',
        'website',
        'web',
    ],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/media_source_views.xml',
    ],
    'assets': {
        # Backend HTML fields (blog body, generic html_editor widgets)
        'web.assets_backend': [
            'website_alist_media/static/src/scss/alist_selector.scss',
            'website_alist_media/static/src/utils/bg_video_utils.js',
            'website_alist_media/static/src/media_dialog/alist_selector.js',
            'website_alist_media/static/src/media_dialog/alist_selector.xml',
            'website_alist_media/static/src/media_dialog/alist_media_plugin.js',
            'website_alist_media/static/src/media_dialog/alist_media_plugin_backend.js',
            'website_alist_media/static/src/media_dialog/media_dialog_only_images_patch.js',
        ],
        # Website builder: AList tab + onlyImages + BG-video MediaDialog patch
        'website.website_builder_assets': [
            'website_alist_media/static/src/scss/alist_selector.scss',
            'website_alist_media/static/src/utils/bg_video_utils.js',
            'website_alist_media/static/src/media_dialog/alist_selector.js',
            'website_alist_media/static/src/media_dialog/alist_selector.xml',
            'website_alist_media/static/src/media_dialog/alist_media_plugin.js',
            'website_alist_media/static/src/media_dialog/alist_media_plugin_website.js',
            'website_alist_media/static/src/media_dialog/media_dialog_only_images_patch.js',
            'website_alist_media/static/src/builder/background_video_dialog_patch.js',
            'website_alist_media/static/src/xml/background_video_direct.xml',
            'website_alist_media/static/src/interactions/background_video_direct_patch.js',
        ],
        # Public site + editor iframe: play CDN mp4/webm as <video>
        'web.assets_frontend': [
            'website_alist_media/static/src/utils/bg_video_utils.js',
            'website_alist_media/static/src/xml/background_video_direct.xml',
            'website_alist_media/static/src/interactions/background_video_direct_patch.js',
            'website_alist_media/static/src/scss/alist_selector.scss',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
}
