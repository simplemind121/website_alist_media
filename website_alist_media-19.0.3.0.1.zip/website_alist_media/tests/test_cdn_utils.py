# -*- coding: utf-8 -*-
"""Pure unit tests for CDN / path helpers (no Odoo registry required)."""
import importlib.util
import os
import unittest

_HELPER = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'models', 'cdn_utils.py'))
_spec = importlib.util.spec_from_file_location('website_alist_media_cdn_utils', _HELPER)
cdn_utils = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(cdn_utils)

normalize_path = cdn_utils.normalize_path
rewrite_url_to_cdn = cdn_utils.rewrite_url_to_cdn
is_host_allowed = cdn_utils.is_host_allowed
collect_allowed_hosts = cdn_utils.collect_allowed_hosts
host_from_url = cdn_utils.host_from_url
guess_media_type = cdn_utils.guess_media_type


class TestNormalizePath(unittest.TestCase):
    def test_root(self):
        self.assertEqual(normalize_path('/', '/'), '/')

    def test_simple(self):
        self.assertEqual(normalize_path('/b2/photos', '/'), '/b2/photos')

    def test_dotdot_inside(self):
        self.assertEqual(normalize_path('/b2/a/../c', '/'), '/b2/c')

    def test_escape_outside_root(self):
        self.assertEqual(normalize_path('/other/secret', '/b2'), '/b2')

    def test_under_root(self):
        self.assertEqual(normalize_path('/b2/photos/x', '/b2'), '/b2/photos/x')

    def test_backslash(self):
        self.assertEqual(normalize_path('\\b2\\a', '/'), '/b2/a')


class TestCdnRewrite(unittest.TestCase):
    def test_strip_d(self):
        url = 'https://one.example.com/d/b2/FILE.jpg?sign=abc'
        out = rewrite_url_to_cdn(url, 'https://media.example.com', '/d')
        self.assertEqual(out, 'https://media.example.com/b2/FILE.jpg?sign=abc')

    def test_no_cdn(self):
        url = 'https://one.example.com/d/file.jpg'
        self.assertEqual(rewrite_url_to_cdn(url, '', '/d'), url)

    def test_exact_strip(self):
        url = 'https://one.example.com/d'
        out = rewrite_url_to_cdn(url, 'https://cdn.example.com', '/d')
        self.assertEqual(out, 'https://cdn.example.com/')


class TestAllowlist(unittest.TestCase):
    def test_exact(self):
        self.assertTrue(is_host_allowed('media.example.com', {'media.example.com'}))

    def test_subdomain(self):
        self.assertTrue(is_host_allowed('img.media.example.com', {'media.example.com'}))

    def test_reject(self):
        self.assertFalse(is_host_allowed('evil.com', {'media.example.com'}))

    def test_collect(self):
        hosts = collect_allowed_hosts(
            'https://one.example.com',
            'https://media.example.com/cdn',
            extra_domains_text='cdn2.example.com\n# comment\n',
        )
        self.assertIn('one.example.com', hosts)
        self.assertIn('media.example.com', hosts)
        self.assertIn('cdn2.example.com', hosts)

    def test_host_from_url(self):
        self.assertEqual(host_from_url('https://Media.Example.com/x'), 'media.example.com')


class TestGuess(unittest.TestCase):
    def test_image(self):
        self.assertEqual(guess_media_type('a.PNG'), 'image')

    def test_video(self):
        self.assertEqual(guess_media_type('clip.mp4'), 'video')

    def test_unknown(self):
        self.assertEqual(guess_media_type('readme.txt'), 'unknown')

    def test_ogg(self):
        self.assertEqual(guess_media_type('a.ogg'), 'video')
        self.assertEqual(guess_media_type('a.ogv'), 'video')

    def test_content_type_video(self):
        self.assertEqual(guess_media_type('blob', content_type='video/mp4'), 'video')

    def test_content_type_image(self):
        self.assertEqual(guess_media_type('blob', content_type='image/png'), 'image')

    def test_extension_wins_over_content_type(self):
        self.assertEqual(guess_media_type('clip.mp4', content_type='image/png'), 'video')


if __name__ == '__main__':
    unittest.main()
