# -*- coding: utf-8 -*-
# Standalone: python3 -m unittest discover -s tests -v
# Under Odoo: modules imported for discovery.
from . import test_cdn_utils
from . import test_only_images_filter
from . import test_bg_video_utils
