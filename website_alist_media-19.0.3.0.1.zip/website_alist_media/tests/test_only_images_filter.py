# -*- coding: utf-8 -*-
"""Pure unit tests mirroring media_dialog_only_images_patch.js helpers."""
import unittest


IMAGE_FRIENDLY_EXTRA_TAB_IDS = {"ALIST"}


class _Ds(dict):
    """Minimal dataset stand-in (attr + get)."""

    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc


class _El:
    def __init__(self, **dataset):
        self.dataset = _Ds(dataset)


class _Media:
    def __init__(self, parent=None):
        self.parentElement = parent


def is_only_images_dialog(props):
    if props.get("onlyImages"):
        return True
    media = props.get("media")
    parent = getattr(media, "parentElement", None) if media is not None else None
    if parent is None:
        return False
    dataset = getattr(parent, "dataset", {}) or {}
    oe_field = dataset.get("oeField") if hasattr(dataset, "get") else getattr(dataset, "oeField", None)
    oe_type = dataset.get("oeType") if hasattr(dataset, "get") else getattr(dataset, "oeType", None)
    return oe_field == "image" or oe_type == "image"


def filter_image_friendly_extra_tabs(extra_tabs, allow_ids=None):
    allow = allow_ids or IMAGE_FRIENDLY_EXTRA_TAB_IDS
    return [t for t in (extra_tabs or []) if t.get("id") in allow]


class TestFilterImageFriendlyExtraTabs(unittest.TestCase):
    def test_keeps_alist_only(self):
        tabs = [
            {"id": "ALIST", "title": "AList"},
            {"id": "VIDEOS", "title": "Videos"},
            {"id": "DOCUMENTS", "title": "Documents"},
        ]
        self.assertEqual(
            [t["id"] for t in filter_image_friendly_extra_tabs(tabs)],
            ["ALIST"],
        )

    def test_empty(self):
        self.assertEqual(filter_image_friendly_extra_tabs(None), [])
        self.assertEqual(filter_image_friendly_extra_tabs([]), [])


class TestIsOnlyImagesDialog(unittest.TestCase):
    def test_prop_true(self):
        self.assertTrue(is_only_images_dialog({"onlyImages": True}))

    def test_prop_false(self):
        self.assertFalse(is_only_images_dialog({"onlyImages": False}))
        self.assertFalse(is_only_images_dialog({}))

    def test_oe_field_image(self):
        media = _Media(parent=_El(oeField="image"))
        self.assertTrue(is_only_images_dialog({"media": media}))

    def test_oe_type_image(self):
        media = _Media(parent=_El(oeType="image"))
        self.assertTrue(is_only_images_dialog({"media": media}))

    def test_unrelated_media(self):
        media = _Media(parent=_El(oeField="body"))
        self.assertFalse(is_only_images_dialog({"media": media}))


if __name__ == "__main__":
    unittest.main()
