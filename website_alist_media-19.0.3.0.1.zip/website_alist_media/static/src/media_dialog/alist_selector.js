/** @odoo-module **/

import { Component, onWillStart, useState } from "@odoo/owl";
import { _t } from "@web/core/l10n/translation";
import { rpc } from "@web/core/network/rpc";
import { useService } from "@web/core/utils/hooks";
import { KeepLast } from "@web/core/utils/concurrency";
import {
    DIRECT_VIDEO_EXTENSIONS,
    isDirectMediaVideoUrl,
    urlPathLower,
} from "@website_alist_media/utils/bg_video_utils";

/**
 * True when an AList list/resolve item (or its CDN URL) is a direct video file.
 * Prefer media_type from the API; fall back to extension on name/url/ref.
 * @param {object} media
 * @returns {boolean}
 */
export function isAListVideoMedia(media) {
    if (!media || typeof media !== "object") {
        return false;
    }
    if (media.media_type === "video") {
        return true;
    }
    if (media.media_type === "image") {
        return false;
    }
    const candidates = [media.name, media.url, media.ref, media.preview_url];
    for (const c of candidates) {
        if (c && isDirectMediaVideoUrl(String(c))) {
            return true;
        }
        if (c && typeof c === "string") {
            const lower = urlPathLower(c);
            if (DIRECT_VIDEO_EXTENSIONS.some((ext) => lower.endsWith(ext))) {
                return true;
            }
        }
    }
    return false;
}

/**
 * AList / S3 tab for Odoo 19 MediaDialog.
 * createElements builds <img>/<video> with CDN URLs — no ir.attachment binary.
 */
export class AListSelector extends Component {
    static template = "website_alist_media.AListSelector";
    // Keep "img" so ImageSelector cleanup does not strip classes from AList images.
    // VIDEO nodes get o_alist_cdn_video only in createElements; renderMedia patch
    // strips forced img-* classes from those videos afterward.
    static mediaSpecificClasses = ["img", "img-fluid", "o_we_custom_image"];
    static mediaSpecificStyles = ["transform", "width"];
    static mediaExtraClasses = [
        "rounded-circle",
        "rounded",
        "img-thumbnail",
        "shadow",
        "w-25",
        "w-50",
        "w-75",
        "w-100",
    ];
    static tagNames = ["IMG", "VIDEO"];
    static props = {
        "*": true,
    };

    setup() {
        this.notification = useService("notification");
        this.keepLast = new KeepLast();
        this.state = useState({
            sources: [],
            sourceId: null,
            path: "/",
            pathStack: [],
            items: [],
            total: 0,
            page: 1,
            perPage: 30,
            needle: "",
            loading: false,
            error: null,
        });
        onWillStart(async () => {
            await this.loadSources();
            if (this.state.sourceId) {
                await this.fetchList();
            }
        });
    }

    /** True when MediaDialog opened with onlyImages (or oe image field). */
    get onlyImages() {
        return Boolean(this.props.onlyImages);
    }

    /** True when opened as BG-video picker (videosOnly / isForBgVideo). */
    get videosOnly() {
        return Boolean(this.props.videosOnly || this.props.isForBgVideo);
    }

    /** Items shown in the grid: dirs always; files filtered by onlyImages / videosOnly. */
    get visibleItems() {
        if (this.onlyImages) {
            return this.state.items.filter(
                (item) => item.is_dir || item.media_type === "image"
            );
        }
        if (this.videosOnly) {
            return this.state.items.filter(
                (item) => item.is_dir || isAListVideoMedia(item)
            );
        }
        return this.state.items;
    }

    get selectedRefs() {
        return (this.props.selectedMedia[this.props.id] || []).map((m) => m.ref);
    }

    async loadSources() {
        try {
            const result = await rpc("/website_alist_media/sources", {});
            const sources = result.sources || [];
            this.state.sources = sources;
            if (sources.length) {
                this.state.sourceId = sources[0].id;
                this.state.path = sources[0].root_path || "/";
                this.state.perPage = sources[0].page_size || 30;
            }
        } catch (err) {
            this.state.error = _t("Could not load media sources.");
            console.error(err);
        }
    }

    async onSourceChange(ev) {
        const id = parseInt(ev.target.value, 10);
        const src = this.state.sources.find((s) => s.id === id);
        this.state.sourceId = id;
        this.state.path = (src && src.root_path) || "/";
        this.state.pathStack = [];
        this.state.page = 1;
        this.state.needle = "";
        await this.fetchList();
    }

    async fetchList() {
        if (!this.state.sourceId) {
            return;
        }
        this.state.loading = true;
        this.state.error = null;
        const payload = {
            source_id: this.state.sourceId,
            path: this.state.path,
            page: this.state.page,
            per_page: this.state.perPage,
            query: this.state.needle || null,
        };
        try {
            const result = await this.keepLast.add(
                rpc("/website_alist_media/list", payload)
            );
            if (result.error) {
                this.state.error = result.error;
                this.state.items = [];
                this.props.errorMessages?.(result.error);
            } else {
                this.state.items = result.items || [];
                this.state.total = result.total || 0;
                this.state.path = result.path || this.state.path;
                this.props.errorMessages?.(null);
            }
        } catch (err) {
            this.state.error = _t("Failed to list media.");
            console.error(err);
        } finally {
            this.state.loading = false;
        }
    }

    async onSearch(ev) {
        this.state.needle = ev.target.value || "";
        this.state.page = 1;
        await this.fetchList();
    }

    async openDir(item) {
        if (!item.is_dir) {
            return;
        }
        this.state.pathStack.push(this.state.path);
        this.state.path = item.ref;
        this.state.page = 1;
        this.state.needle = "";
        await this.fetchList();
    }

    async goUp() {
        const prev = this.state.pathStack.pop();
        if (prev !== undefined) {
            this.state.path = prev;
        } else {
            const src = this.state.sources.find((s) => s.id === this.state.sourceId);
            this.state.path = (src && src.root_path) || "/";
        }
        this.state.page = 1;
        await this.fetchList();
    }

    async loadMore() {
        if (this.state.items.length >= this.state.total) {
            return;
        }
        this.state.page += 1;
        this.state.loading = true;
        try {
            const result = await rpc("/website_alist_media/list", {
                source_id: this.state.sourceId,
                path: this.state.path,
                page: this.state.page,
                per_page: this.state.perPage,
                query: this.state.needle || null,
            });
            if (!result.error) {
                this.state.items = [...this.state.items, ...(result.items || [])];
                this.state.total = result.total || this.state.total;
            }
        } finally {
            this.state.loading = false;
        }
    }

    isSelected(item) {
        return this.selectedRefs.includes(item.ref);
    }

    async onClickItem(item) {
        if (item.is_dir) {
            await this.openDir(item);
            return;
        }
        const isVideo = isAListVideoMedia(item);
        const isImage = item.media_type === "image";
        if (this.onlyImages && !isImage) {
            this.notification.add(_t("This dialog only accepts images."), {
                type: "warning",
            });
            return;
        }
        if (this.videosOnly && !isVideo) {
            this.notification.add(_t("This dialog only accepts videos."), {
                type: "warning",
            });
            return;
        }
        if (!isImage && !isVideo) {
            return;
        }
        // Resolve to permanent CDN URL on select
        let media = {
            ...item,
            source_id: this.state.sourceId,
            mediaType: "alist",
            media_type: isVideo ? "video" : item.media_type,
        };
        try {
            const resolved = await rpc("/website_alist_media/resolve", {
                source_id: this.state.sourceId,
                item_ref: item.ref,
            });
            if (resolved.error) {
                this.notification.add(resolved.error, { type: "danger" });
                return;
            }
            const resolvedType =
                resolved.media_type ||
                (isAListVideoMedia({ ...item, ...resolved }) ? "video" : item.media_type);
            media = {
                ...media,
                url: resolved.url,
                media_type: resolvedType,
                name: resolved.name || item.name,
                preview_url: resolved.preview_url || resolved.url,
                id: `${this.state.sourceId}:${item.ref}`,
            };
        } catch (err) {
            this.notification.add(_t("Could not resolve media URL."), { type: "danger" });
            return;
        }
        this.props.selectMedia(media);
        if (!this.props.multiSelect) {
            await this.props.save();
        }
    }

    /**
     * Called by MediaDialog.renderMedia — insert CDN URL elements, no filestore.
     */
    static async createElements(selectedMedia) {
        return selectedMedia.map((media) => {
            const url = media.url;
            if (isAListVideoMedia(media)) {
                const videoEl = document.createElement("video");
                videoEl.setAttribute("controls", "controls");
                videoEl.setAttribute("playsinline", "playsinline");
                videoEl.src = url;
                // Do NOT use media_iframe_video — that class is for YT/Vimeo
                // iframe wrappers; website.media_video would try to rebuild an iframe.
                videoEl.classList.add("o_alist_cdn_video", "img-fluid");
                videoEl.dataset.alistExternal = "1";
                if (media.name) {
                    videoEl.setAttribute("title", media.name);
                }
                return videoEl;
            }
            const imageEl = document.createElement("img");
            imageEl.src = url;
            imageEl.alt = media.name || "";
            imageEl.classList.add("img", "img-fluid", "o_we_custom_image");
            // Mark as external so save pipelines can skip binary upload
            imageEl.dataset.alistExternal = "1";
            return imageEl;
        });
    }
}
