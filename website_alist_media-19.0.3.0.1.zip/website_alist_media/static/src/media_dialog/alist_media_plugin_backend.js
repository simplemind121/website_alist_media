/** @odoo-module **/

/**
 * Backend / generic HTML-field entry: ensure AListMediaPlugin is in MAIN_PLUGINS.
 * Loaded only via ``web.assets_backend`` (not website builder assets).
 */
import { MAIN_PLUGINS } from "@html_editor/plugin_sets";
import { AListMediaPlugin } from "./alist_media_plugin";

if (!MAIN_PLUGINS.includes(AListMediaPlugin)) {
    MAIN_PLUGINS.push(AListMediaPlugin);
}
