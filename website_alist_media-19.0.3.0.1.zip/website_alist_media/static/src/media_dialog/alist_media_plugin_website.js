/** @odoo-module **/

/**
 * Website builder entry: register AListMediaPlugin on ``website-plugins``.
 * Website builder composes Plugins from CORE_PLUGINS + this registry
 * (see website_builder.js) — MAIN_PLUGINS.push alone does not reach it.
 *
 * Guard with ``contains`` so a dual/bundle re-load never raises DuplicatedKeyError.
 * Loaded only via ``website.website_builder_assets``.
 */
import { registry } from "@web/core/registry";
import { AListMediaPlugin } from "./alist_media_plugin";

const websitePlugins = registry.category("website-plugins");
if (!websitePlugins.contains(AListMediaPlugin.id)) {
    websitePlugins.add(AListMediaPlugin.id, AListMediaPlugin);
}
