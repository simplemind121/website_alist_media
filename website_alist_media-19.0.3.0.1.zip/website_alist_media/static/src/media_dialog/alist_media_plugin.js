/** @odoo-module **/

import { Plugin } from "@html_editor/plugin";
import { _t } from "@web/core/l10n/translation";
import { AListSelector } from "./alist_selector";

/**
 * Odoo 19 html_editor Plugin that registers the AList MediaDialog tab via
 * the official ``media_dialog_extra_tabs`` resource (same pattern as VideoPlugin /
 * FilePlugin in odoo/odoo 19.0).
 *
 * Side-effect registration lives in dedicated entry files so backend
 * (``web.assets_backend``) and website builder (``website.website_builder_assets``)
 * bundles do not double-execute the same registry / MAIN_PLUGINS mutations:
 *
 * - ``alist_media_plugin_backend.js`` → MAIN_PLUGINS (HTML fields)
 * - ``alist_media_plugin_website.js`` → website-plugins registry
 *
 * @see addons/html_editor/static/src/main/media/video_plugin.js
 * @see addons/html_editor/static/src/main/media/media_plugin.js
 */
export class AListMediaPlugin extends Plugin {
    static id = "alist_media";

    /** @type {import("plugins").EditorResources} */
    resources = {
        media_dialog_extra_tabs: {
            id: "ALIST",
            title: _t("AList"),
            Component: this.componentForMediaDialog,
            sequence: 40,
        },
    };

    get componentForMediaDialog() {
        return AListSelector;
    }
}
