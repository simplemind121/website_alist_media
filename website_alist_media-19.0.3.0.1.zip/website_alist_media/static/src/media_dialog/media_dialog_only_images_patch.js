/** @odoo-module **/

/**
 * Patch MediaDialog.addTabs so ``onlyImages`` flows still get image-friendly
 * extraTabs (at least ALIST). Stock Odoo returns early after the Images tab
 * and skips ``extraTabs.forEach``, which is why gallery Add / s_image drop /
 * cover / bg-image never showed AList.
 *
 * Also patch renderMedia so AList CDN ``<video>`` elements are not force-tagged
 * with ImageSelector classes (``img`` / ``o_we_custom_image``). Stock
 * renderMedia always adds the active tab's mediaSpecificClasses; AList must
 * keep ``img`` in that list so ImageSelector cleanup does not strip image
 * classes from AList ``<img>`` inserts — but those image classes must not
 * land on body videos (would look like / behave as images downstream).
 *
 * Non-onlyImages paths keep full stock behavior via ``super.addTabs()``.
 */
import { MediaDialog, TABS } from "@html_editor/main/media/media_dialog/media_dialog";
import { patch } from "@web/core/utils/patch";

/** Extra-tab ids that are valid in image-only MediaDialog flows. */
export const IMAGE_FRIENDLY_EXTRA_TAB_IDS = new Set(["ALIST"]);

/** Image-only classes that must not remain on AList CDN ``<video>`` nodes. */
const IMAGE_ONLY_CLASSES = ["img", "o_we_custom_image", "media_iframe_video"];

/**
 * Whether MediaDialog should treat the current open as image-only
 * (mirrors stock MediaDialog.addTabs detection).
 * @param {object} props
 * @returns {boolean}
 */
export function isOnlyImagesDialog(props) {
    return Boolean(
        props.onlyImages ||
            (props.media &&
                props.media.parentElement &&
                (props.media.parentElement.dataset.oeField === "image" ||
                    props.media.parentElement.dataset.oeType === "image"))
    );
}

/**
 * Extra tabs to keep when onlyImages is true.
 * @param {Array<{id: string}>} extraTabs
 * @param {Set<string>} [allowIds]
 * @returns {Array}
 */
export function filterImageFriendlyExtraTabs(
    extraTabs,
    allowIds = IMAGE_FRIENDLY_EXTRA_TAB_IDS
) {
    return (extraTabs || []).filter((tab) => allowIds.has(tab.id));
}

/**
 * Normalize AList CDN video elements after stock renderMedia class merging.
 * @param {HTMLElement[]} elements
 * @returns {HTMLElement[]}
 */
export function sanitizeAListVideoElements(elements) {
    for (const el of elements || []) {
        if (!el || el.tagName !== "VIDEO") {
            continue;
        }
        const looksAList =
            el.classList.contains("o_alist_cdn_video") ||
            el.dataset?.alistExternal === "1";
        if (!looksAList) {
            // Leave stock / non-AList videos alone if any appear.
            continue;
        }
        el.classList.remove(...IMAGE_ONLY_CLASSES);
        el.classList.add("o_alist_cdn_video", "img-fluid");
        if (!el.hasAttribute("controls")) {
            el.setAttribute("controls", "controls");
        }
        if (!el.hasAttribute("playsinline")) {
            el.setAttribute("playsinline", "playsinline");
        }
        el.dataset.alistExternal = "1";
    }
    return elements;
}

patch(MediaDialog.prototype, {
    addTabs() {
        if (!isOnlyImagesDialog(this.props)) {
            return super.addTabs(...arguments);
        }

        // Stock-equivalent Images tab, then image-friendly extraTabs only.
        if (!this.props.noImages) {
            this.addTab(TABS.IMAGES, {
                useMediaLibrary: this.props.useMediaLibrary,
                multiSelect: this.props.multiImages,
                addFieldImage: this.props.addFieldImage,
            });
        }
        for (const tab of filterImageFriendlyExtraTabs(this.props.extraTabs)) {
            this.addTab(tab, { onlyImages: true });
        }
        // Intentionally skip Documents / Icons / Videos (stock onlyImages return).
    },

    async renderMedia(selectedMedia) {
        const elements = await super.renderMedia(...arguments);
        return sanitizeAListVideoElements(elements);
    },
});
