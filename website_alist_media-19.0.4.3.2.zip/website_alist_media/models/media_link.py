# -*- coding: utf-8 -*-
"""Reference index + link health check for AList/CDN URLs (19.0.4.0.0).

- scan: finds every CDN/AList URL used in website content and records where
  (model / record / field). Answers "is this file still used anywhere?"
  before deleting it in AList.
- check: HEAD (fallback ranged GET) each indexed URL, flags broken ones
  (file deleted/moved in AList, CDN misconfigured).

Read-only towards content: never modifies the scanned records.
"""
import logging
import time
from collections import defaultdict

import requests

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .cdn_utils import host_from_url, is_host_allowed
from .media_utils import (
    budget_exhausted,
    clamp_setting,
    extract_urls_for_hosts,
    is_transient_failure,
    next_link_status,
    SKIPPED_NOT_ALLOWLISTED,
)

_logger = logging.getLogger(__name__)

MAX_ROWS_PER_TARGET = 20000

#: ir.config_parameter keys (all clamped, see media_utils.LIMITS)
PARAM_PREFIX = 'website_alist_media.'

# (model, field). Skipped automatically when the model/field is absent.
# 19.0.4.3.2: Odoo 19 keeps the product page body in description_ecommerce
# (website_description is the pre-19 name), and cover images inserted from the
# AList tab live in cover_properties (JSON with url(...)), not in content.
SCAN_TARGETS = (
    ('ir.ui.view', 'arch_db'),
    ('blog.post', 'content'),
    ('blog.post', 'cover_properties'),
    ('blog.blog', 'cover_properties'),
    ('website.page', 'arch_db'),
    ('product.template', 'description_ecommerce'),
    ('product.template', 'website_description'),
    ('product.public.category', 'website_description'),
    ('event.event', 'description'),
    ('event.event', 'cover_properties'),
    ('slide.channel', 'description'),
    ('slide.channel', 'cover_properties'),
    ('hr.job', 'description'),
)


class WebsiteAlistMediaLink(models.Model):
    _name = 'website.alist.media.link'
    _description = 'AList Media URL usage & health'
    _order = 'status_sequence, ref_count desc, url'
    _rec_name = 'url'

    url = fields.Char(required=True, index=True, readonly=True)
    source_id = fields.Many2one('website.alist.media.source', ondelete='cascade', readonly=True)
    ref_ids = fields.One2many('website.alist.media.link.ref', 'link_id', string='Used in', readonly=True)
    ref_count = fields.Integer(readonly=True)
    status = fields.Selection([
        ('unchecked', 'Not checked'),
        ('ok', 'OK'),
        ('broken', 'Broken (4xx)'),
        ('error', 'Error (5xx / network)'),
    ], default='unchecked', readonly=True, index=True)
    status_sequence = fields.Integer(compute='_compute_status_sequence', store=True)
    http_code = fields.Integer(readonly=True)
    last_checked = fields.Datetime(readonly=True)
    last_message = fields.Char(readonly=True)
    fail_count = fields.Integer(
        readonly=True, default=0,
        help='Consecutive failed probes. A link is only flagged once this '
             'reaches the configured threshold, so a short CDN hiccup does not '
             'mark every URL broken.')

    _url_unique = models.Constraint('UNIQUE(url)', 'URL must be unique.')

    @api.depends('status')
    def _compute_status_sequence(self):
        order = {'broken': 0, 'error': 1, 'unchecked': 2, 'ok': 3}
        for rec in self:
            rec.status_sequence = order.get(rec.status, 9)

    @api.model
    def _setting(self, name):
        """Clamped ir.config_parameter, so a typo can never hang the cron."""
        raw = self.env['ir.config_parameter'].sudo().get_param(PARAM_PREFIX + name)
        return clamp_setting(name, raw)

    def _check_editor_access(self):
        if not (self.env.su or self.env.user.has_group('website.group_website_designer')):
            raise UserError(_('Only website designers can run the media link scan/check.'))

    # ------------------------------------------------------------------ scan
    @api.model
    def _source_hosts(self):
        """{host: source} for CDN/base hosts of active sources."""
        mapping = {}
        for source in self.env['website.alist.media.source'].sudo().search([]):
            for url in (source.cdn_base_url, source.base_url):
                host = host_from_url(url or '')
                if host and host not in mapping:
                    mapping[host] = source
        return mapping

    @api.model
    def _iter_target_rows(self, model_name, field_name, hosts):
        """Yield (res_id, text) rows containing any host. Raw SQL on the column
        (cast to text) so translated jsonb fields are covered in all languages."""
        if model_name not in self.env:
            return
        Model = self.env[model_name]
        field = Model._fields.get(field_name)
        if not field or not field.store or not field.column_type:
            return
        table, column = Model._table, field.name
        clauses = ' OR '.join([f'"{column}"::text ILIKE %s'] * len(hosts))
        params = [f'%{h}%' for h in hosts]
        query = f'SELECT id, "{column}"::text FROM "{table}" WHERE {clauses} LIMIT {MAX_ROWS_PER_TARGET}'
        self.env.cr.execute(query, params)
        yield from self.env.cr.fetchall()

    @api.model
    def action_scan_references(self):
        """Rebuild the reference index. Safe to run anytime (read-only on content)."""
        self._check_editor_access()
        host_map = self._source_hosts()
        if not host_map:
            return self._notify(_('No media source with a CDN/base URL configured.'))
        hosts = set(host_map)
        budget = self._setting('scan_time_budget')
        started = time.monotonic()
        truncated = False
        found = {}  # url -> set((model, res_id, field))
        for model_name, field_name in SCAN_TARGETS:
            if budget_exhausted(started, time.monotonic(), budget):
                truncated = True
                _logger.warning(
                    'website_alist_media: scan time budget (%ss) reached, '
                    'skipping remaining targets from %s.%s', budget, model_name, field_name)
                break
            for res_id, text in self._iter_target_rows(model_name, field_name, hosts):
                for url in extract_urls_for_hosts(text, hosts):
                    found.setdefault(url, set()).add((model_name, res_id, field_name))

        if truncated and not found:
            return self._notify(_('Scan stopped early (time budget); nothing indexed.'))

        Ref = self.env['website.alist.media.link.ref'].sudo()
        Link = self.sudo()
        existing = {link.url: link for link in Link.search([])}
        Ref.search([]).unlink()

        # Create missing links in one call, then all refs in one call, instead of
        # one round-trip per URL (a big site has thousands).
        missing = [url for url in found if url not in existing]
        if missing:
            created = Link.create([{
                'url': url,
                'source_id': (host_map.get(host_from_url(url)).id
                              if host_map.get(host_from_url(url)) else False),
            } for url in missing])
            for url, link in zip(missing, created):
                existing[url] = link

        ref_vals = []
        by_count = defaultdict(list)
        for url, refs in found.items():
            link = existing.get(url)
            if not link:
                continue
            ref_vals += [{
                'link_id': link.id, 'res_model': m, 'res_id': rid, 'res_field': f,
            } for (m, rid, f) in refs]
            by_count[len(refs)].append(link.id)
        if ref_vals:
            Ref.create(ref_vals)
        for count, link_ids in by_count.items():
            Link.browse(link_ids).ref_count = count
        # URLs no longer referenced anywhere: keep the row (history) with count 0
        stale = [link.id for url, link in existing.items() if url not in found]
        if stale:
            Link.browse(stale).ref_count = 0

        _logger.info('website_alist_media: indexed %s URLs in %.1fs%s',
                     len(found), time.monotonic() - started,
                     ' (truncated by time budget)' if truncated else '')
        if truncated:
            return self._notify(
                _('%s URLs indexed; scan stopped early (time budget reached).') % len(found))
        return self._notify(_('%s CDN/AList URLs indexed.') % len(found))

    # ----------------------------------------------------------------- check
    @api.model
    def _check_one(self, url, source, timeout=None, session=None):
        """Return (status, http_code, message). Only allowlisted hosts are requested."""
        if source:
            host = host_from_url(url)
            if not is_host_allowed(host, source._allowed_hosts()):
                return 'error', 0, SKIPPED_NOT_ALLOWLISTED
        timeout = timeout or self._setting('check_timeout')
        http = session or requests
        try:
            resp = http.head(url, timeout=timeout, allow_redirects=True)
            if resp.status_code in (403, 405, 501):
                # some CDNs refuse HEAD
                resp = http.get(url, timeout=timeout, allow_redirects=True,
                                stream=True, headers={'Range': 'bytes=0-0'})
                resp.close()
        except requests.exceptions.RequestException as exc:
            return 'error', 0, exc.__class__.__name__
        code = resp.status_code
        if code < 400:
            return 'ok', code, ''
        if code < 500:
            return 'broken', code, f'HTTP {code}'
        return 'error', code, f'HTTP {code}'

    def action_check_links(self):
        """Probe links, oldest-checked first, within a time budget.

        Links not reached in this run stay at the front of the queue for the
        next one (ordering is by last_checked), so a large site rotates through
        its URLs instead of the cron running for an unbounded time.
        """
        self._check_editor_access()
        batch = self._setting('check_batch')
        budget = self._setting('check_time_budget')
        timeout = self._setting('check_timeout')
        threshold = self._setting('fail_threshold')
        links = self or self.sudo().search([], order='last_checked asc nulls first, id',
                                           limit=batch)
        now = fields.Datetime.now()
        started = time.monotonic()
        checked = problems = provisional = 0
        session = requests.Session()
        try:
            for link in links.sudo():
                if budget_exhausted(started, time.monotonic(), budget):
                    _logger.info(
                        'website_alist_media: check time budget (%ss) reached after %s links; '
                        'the rest are queued for the next run.', budget, checked)
                    break
                probe, code, message = self._check_one(
                    link.url, link.source_id, timeout=timeout, session=session)
                status, fail_count, is_provisional = next_link_status(
                    link.status, probe, link.fail_count, threshold,
                    transient=is_transient_failure(probe, code, message))
                if is_provisional:
                    provisional += 1
                    message = _('%(msg)s (failure %(n)s/%(t)s, not flagged yet)') % {
                        'msg': message or probe, 'n': fail_count, 't': threshold}
                link.write({'status': status, 'http_code': code, 'fail_count': fail_count,
                            'last_message': message, 'last_checked': now})
                checked += 1
                if status in ('broken', 'error'):
                    problems += 1
        finally:
            session.close()
        return self._notify(_(
            '%(n)s links checked, %(b)s problems, %(p)s awaiting confirmation.'
        ) % {'n': checked, 'b': problems, 'p': provisional})

    # ------------------------------------------------------------------ cron
    @api.model
    def _cron_scan_and_check(self):
        silent = self.with_context(website_alist_silent=True)
        silent.action_scan_references()
        silent.browse().action_check_links()

    @api.model
    def _notify(self, message):
        if self.env.context.get('website_alist_silent'):
            return True
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {'message': message, 'type': 'info', 'sticky': False,
                       'next': {'type': 'ir.actions.act_window_close'}},
        }


class WebsiteAlistMediaLinkRef(models.Model):
    _name = 'website.alist.media.link.ref'
    _description = 'AList Media URL reference'
    _order = 'res_model, res_id'

    link_id = fields.Many2one('website.alist.media.link', required=True, ondelete='cascade', index=True)
    res_model = fields.Char(required=True, readonly=True)
    res_id = fields.Integer(required=True, readonly=True)
    res_field = fields.Char(readonly=True)
    display_name_ref = fields.Char(string='Record', compute='_compute_display_name_ref')

    def _compute_display_name_ref(self):
        for ref in self:
            label = f'{ref.res_model},{ref.res_id}'
            if ref.res_model in self.env:
                rec = self.env[ref.res_model].sudo().browse(ref.res_id).exists()
                if rec:
                    label = f'{rec._description}: {rec.display_name}'
            ref.display_name_ref = label

    def action_open_record(self):
        self.ensure_one()
        if self.res_model not in self.env:
            raise UserError(_('Model %s is not installed.') % self.res_model)
        return {
            'type': 'ir.actions.act_window',
            'res_model': self.res_model,
            'res_id': self.res_id,
            'view_mode': 'form',
            'target': 'current',
        }
