# -*- coding: utf-8 -*-
{
    'name': 'Website AList Media (MediaDialog)',
    'summary': 'Add an AList tab to Odoo 19 MediaDialog (website editor / HTML fields); insert CDN URLs without filestore.',
    'description': """
Website AList Media
===================
Extends the native Odoo 19 「选择媒体」 MediaDialog with an **AList** tab
(and optional S3-compatible sources) for the **website builder and generic
HTML fields** (page content, blog posts, etc). Selected images/videos become
permanent CDN public URLs inserted directly into the HTML — no binary is
written to the Odoo filestore.

* Backend media sources (AList / S3): base URL, secrets server-only, CDN rewrite
* JSON list/search/resolve controllers (≈5s timeout; tokens never to browser)
* OWL tab via ``media_dialog_extra_tabs`` (html_editor Plugin API, Odoo 19.0)
* 19.0.3.0.0: AList also in "images only" dialogs (image snippet drop, gallery
  Add (multi-select), section background, record cover, grid Add image) and in
  the editor toolbar "replace icon" dialog (image replaces the icon)
* 19.0.4.0.0: upload from the dialog to AList/S3, AList index search,
  thumbnail/resize URL templates (opt-in srcset), lazy + intrinsic size on
  insert, remembered folder, URL usage index + daily link health check,
  env secrets take precedence, compatibility guard
* 19.0.4.1.0: merge of the two 19.0.3.x lines. Keeps the browser-verified
  video path from 19.0.3.0.1 (body ``<video class="o_alist_cdn_video">``,
  section background video via AList, direct-URL ``<video autoplay muted
  loop>`` playback on the public site) on top of 19.0.4.0.0. Secrets are
  now restricted to source managers at field level.
* 19.0.4.1.1: UX — infinite scroll in the AList MediaDialog grid (near-bottom auto loadMore; button kept as 「加载更多…」 fallback); new media sources default page_size 60 (existing sources unchanged; clamp 1–200).
* 19.0.4.3.0: display-area option for AList images (frame ratio, fill, focal
  point) via the official builder option API; CSS only, reversible
* 19.0.4.2.0: link-check pacing (time budgets, clamped settings, failure damping),
  video poster auto-match, warning for non-playable containers, load-order-proof
  background-video patch
* 19.0.4.3.2: uploads never overwrite (auto-rename demo-1.jpg), usage index
  covers Odoo 19 product descriptions (description_ecommerce) and cover images,
  Secret Reference rejects a pasted token, connection test warns on a missing env var

Scope note
----------
This module deliberately does **not** touch ``product.image``, the
``website_sale.shop_product_image`` / ``carousel_product_indicators``
templates, or the product form's 「添加媒体」 CustomMediaDialog flow.
Those are already covered in this environment by the existing
``media_picker`` module. Adding this module's own copy of that same
integration (as an earlier draft of this module did) would have installed
a second ``alist_cdn_url``/``alist_media_kind`` field on ``product.image``
and a second, conflicting xpath ``position="replace"`` on the exact same
storefront templates ``media_picker`` already patches — which on install/
upgrade would very likely raise a view-inheritance "element not found"
error, or at best silently fight with the existing customization. This
module is intentionally scoped to only the general content editor, which
``media_picker`` does not touch, so the two can install side by side.
    """,
    'version': '19.0.4.3.2',
    'category': 'Website/Website',
    'author': 'Custom Development',
    'license': 'LGPL-3',
    'depends': [
        'html_editor',
        'html_builder',
        'website',
        'web',
    ],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/media_source_views.xml',
        'data/ir_cron_data.xml',
    ],
    'assets': {
        # Backend HTML fields (e.g. blog post body, generic html_editor widgets)
        'web.assets_backend': [
            'website_alist_media/static/src/scss/alist_content.scss',
            'website_alist_media/static/src/scss/alist_selector.scss',
            'website_alist_media/static/src/scss/alist_video.scss',
            'website_alist_media/static/src/utils/bg_video_utils.js',
            'website_alist_media/static/src/media_dialog/alist_tab_rules.js',
            'website_alist_media/static/src/media_dialog/alist_selector.js',
            'website_alist_media/static/src/media_dialog/alist_selector.xml',
            'website_alist_media/static/src/media_dialog/alist_media_plugin.js',
            'website_alist_media/static/src/media_dialog/alist_media_dialog_patch.js',
        ],
        # Website builder: AList tab + images-only/icon entry points + BG video dialog
        'website.website_builder_assets': [
            'website_alist_media/static/src/scss/alist_selector.scss',
            'website_alist_media/static/src/scss/alist_video.scss',
            'website_alist_media/static/src/utils/bg_video_utils.js',
            'website_alist_media/static/src/media_dialog/alist_tab_rules.js',
            'website_alist_media/static/src/media_dialog/alist_selector.js',
            'website_alist_media/static/src/media_dialog/alist_selector.xml',
            'website_alist_media/static/src/media_dialog/alist_media_plugin.js',
            'website_alist_media/static/src/media_dialog/alist_media_dialog_patch.js',
            'website_alist_media/static/src/builder/background_video_dialog_patch.js',
            'website_alist_media/static/src/utils/focal_utils.js',
            'website_alist_media/static/src/builder/alist_focal_option.scss',
            'website_alist_media/static/src/builder/alist_focal_option.xml',
            'website_alist_media/static/src/builder/alist_focal_option.js',
            'website_alist_media/static/src/xml/background_video_direct.xml',
            'website_alist_media/static/src/interactions/background_video_direct_patch.js',
        ],
        # Public site + editor iframe: play direct CDN mp4/webm as <video>.
        # Required for pages that already use AList background videos.
        'web.assets_frontend': [
            'website_alist_media/static/src/scss/alist_content.scss',
            'website_alist_media/static/src/scss/alist_video.scss',
            'website_alist_media/static/src/utils/bg_video_utils.js',
            'website_alist_media/static/src/xml/background_video_direct.xml',
            'website_alist_media/static/src/interactions/background_video_direct_patch.js',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
}
