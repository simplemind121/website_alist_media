# 真实数据库测试（需要 Odoo 19 + PostgreSQL）

在 Odoo 容器内对一个**测试库**运行（不要用生产库）：

```bash
odoo -d <测试库> -i website_alist_media --test-enable \
     --test-tags /website_alist_media --stop-after-init --no-http
```

期望结尾出现：`0 failed, 0 error(s) of 21 tests`

升级路径测试：先装旧版本并造数据，再换成新包执行 `-u website_alist_media`（同样加上
`--test-enable --test-tags /website_alist_media`）。
