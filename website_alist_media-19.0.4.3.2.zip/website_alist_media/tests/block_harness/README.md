# 全 block 替换回归测试（可选，Odoo 升级后建议重跑）

对 Odoo 每个 snippet 模板里的每个媒体元素，用真实 DOM（jsdom）重放
`MediaDialog.renderMedia` 的类/样式继承逻辑，检查：

- [A] 原生图片替换的结果与 Odoo 原生行为完全一致（本模块不得改变原生行为）
- [B] AList 替换与原生替换结果一致（仅多出 AList 标记类）
- [C] 显示区域工具只出现在 AList 图片上
- [D] AList 图换成原生图：保持 Odoo 原生行为，且工具仍可用（不产生"孤儿样式"）
- [E] AList 图换 AList 图：调好的画框保留

## 运行

```bash
npm install jsdom@24
# 基础 block
node block_harness.js /path/to/odoo/addons/website/views/snippets
# 官方主题（odoo/design-themes 仓库）或其他 website_* 模块的 views 目录同理
```

## 19.0.4.3.0 实测结果（Odoo 19.0 源码）

| 范围 | 含媒体的模板 | 媒体元素 | 可替换 | Odoo 自身排除 | 问题 |
|---|---|---|---|---|---|
| website 基础 block | 89 | 1256 | 1210 | 46（社交/分享图标） | 0 |
| 全部官方主题（design-themes） | 47 | 396 | 396 | 0 | 0 |
| 其他 website 应用（商城、博客、活动等 11 个） | 54 | 1858 | 1855 | 3 | 0 |
| **合计** | **190** | **3510** | **3461** | **49** | **0** |

局限：这是结构层面的验证（选择器、类、样式、标记在替换时的去留），
不是浏览器渲染测试；视觉效果仍需在真实编辑器中确认。
