/**
 * Per-block replace-media harness for website_alist_media.
 *
 * For every media element in every Odoo 19 website snippet template it
 * replays MediaDialog.renderMedia (class/style carry-over, copied from
 * html_editor 19.0 media_dialog.js) with:
 *   - native IMAGES tab (baseline = what stock Odoo does)
 *   - AList tab as shipped in 19.0.4.2.0 (old lists)
 *   - AList tab as shipped in 19.0.4.3.0 (new lists)
 * and checks invariants. Run: node block_harness.mjs <snippets_dir>
 */
const fs = require("fs");
const path = require("path");
const { JSDOM } = require("jsdom");

// ---- tab definitions, verbatim from odoo 19.0 selectors -------------------
const IMG_EXTRA = ["rounded-circle", "rounded", "img-thumbnail", "shadow", "w-25", "w-50", "w-75", "w-100"];
const TABS_BASE = {
    IMAGES: { cls: ["img", "img-fluid", "o_we_custom_image"], sty: ["transform", "width"], extra: IMG_EXTRA },
    DOCUMENTS: { cls: ["o_file_box"], sty: [], extra: [] },
    ICONS: { cls: ["fa"], sty: ["color", "background-color"], extra: [/^text-\S+$/, /^bg-\S+$/, /^fa-\S+$/] },
    VIDEOS: { cls: ["media_iframe_video"], sty: [], extra: [] },
};
const ALIST_OLD = { cls: ["img", "img-fluid", "o_we_custom_image"], sty: ["transform", "width"], extra: IMG_EXTRA };
const ALIST_NEW = {
    cls: ["img", "img-fluid", "o_we_custom_image", "o_alist_external"],
    sty: ["transform", "width"],
    extra: IMG_EXTRA,
};
const FOCAL_SELECTOR = "img[data-alist-external], img.o_alist_external, img.o_alist_framed";
const REPLACE_SELECTOR = "img, .media_iframe_video, span.fa, i.fa";
const REPLACE_EXCLUDE = "[data-oe-xpath], a[href^='/website/social/'] > i.fa, a[class*='s_share_'] > i.fa";
const MANAGED = ["aspect-ratio", "object-fit", "object-position"];

const matchesAny = (name, list) => list.some((n) => (typeof n === "string" ? n === name : n.test(name)));

// ---- renderMedia replay (html_editor 19.0 media_dialog.js) ----------------
function renderMedia(doc, activeTab, tabs, newEl, media) {
    const initialIconClasses = media.matches("span.fa, i.fa")
        ? [...media.classList].filter((c) => /^fa-/.test(c)) : [];
    newEl.classList.add(...media.classList);
    const style = media.getAttribute("style");
    if (style) { newEl.setAttribute("style", style); }
    for (const other of Object.keys(tabs).filter((k) => k !== activeTab)) {
        for (const p of tabs[other].sty) { newEl.style.removeProperty(p); }
        newEl.classList.remove(...tabs[other].cls);
        const extra = [];
        for (const n of tabs[other].extra) {
            if (typeof n === "string") { extra.push(n); }
            else { for (const c of newEl.classList) { if (n.test(c)) { extra.push(c); } } }
        }
        newEl.classList.remove(...extra.filter((c) => !matchesAny(c, tabs[activeTab].extra)));
    }
    newEl.classList.remove(...initialIconClasses, "o_modified_image_to_save", "oe_edited_link");
    newEl.classList.add(...tabs[activeTab].cls);
    return newEl;
}

function freshImg(doc, alist) {
    const img = doc.createElement("img");
    img.setAttribute("src", alist ? "https://media.example.com/a.jpg" : "/web/image/1");
    if (alist) {
        img.classList.add("img", "img-fluid", "o_we_custom_image", "o_alist_external");
        img.dataset.alistExternal = "1";
        img.setAttribute("loading", "lazy");
    } else {
        img.classList.add("img", "img-fluid", "o_we_custom_image");
    }
    return img;
}

const styleMap = (el) => {
    const m = {};
    for (let i = 0; i < el.style.length; i++) { const p = el.style[i]; m[p] = el.style.getPropertyValue(p); }
    return m;
};
const clsSet = (el) => [...el.classList].sort();

// ---- load snippets --------------------------------------------------------
const dir = process.argv[2];
const files = fs.readdirSync(dir).filter((f) => f.endsWith(".xml")).sort();
const results = { snippets: 0, elements: 0, replaceable: 0, excluded: 0, issues: [], perSnippet: {}, inlineManaged: [] };

for (const file of files) {
    const xml = fs.readFileSync(path.join(dir, file), "utf8");
    // parse as HTML so QWeb t-* attributes are simply ignored attributes
    // <template> content lives in a separate fragment that querySelectorAll
    // cannot see, so turn Odoo's <template> wrappers into plain containers.
    const html = xml
        .replace(/<\?xml[^>]*>/, "")
        .replace(/<template\b/g, "<div data-tpl")
        .replace(/<\/template>/g, "</div>");
    const dom = new JSDOM(`<body>${html}</body>`);
    const doc = dom.window.document;
    const media = [...doc.querySelectorAll("img, .media_iframe_video, span.fa, i.fa")];
    if (!media.length) { continue; }
    results.snippets++;
    const name = file.replace(/\.xml$/, "");
    const snip = results.perSnippet[name] = { elements: 0, replaceable: 0, excluded: 0, ok: 0, issues: [] };

    for (const el of media) {
        results.elements++; snip.elements++;
        if (!el.matches(REPLACE_SELECTOR)) { continue; }
        if (el.matches(REPLACE_EXCLUDE)) { results.excluded++; snip.excluded++; continue; }
        results.replaceable++; snip.replaceable++;
        const tag = `${el.tagName.toLowerCase()}.${[...el.classList].slice(0, 4).join(".")}`;
        const problems = [];

        // record snippets whose ORIGINAL markup carries a managed style inline
        const orig = styleMap(el);
        for (const p of MANAGED) {
            if (orig[p]) { results.inlineManaged.push(`${name}: <${tag}> style ${p}:${orig[p]}`); }
        }

        const tabsNew = { ...TABS_BASE, ALIST: ALIST_NEW };
        const tabsOld = { ...TABS_BASE, ALIST: ALIST_OLD };

        // (A) native Images replacement: 4.3.0 must behave exactly like 4.2.0
        const nativeOld = renderMedia(doc, "IMAGES", tabsOld, freshImg(doc, false), el);
        const nativeNew = renderMedia(doc, "IMAGES", tabsNew, freshImg(doc, false), el);
        if (JSON.stringify(styleMap(nativeOld)) !== JSON.stringify(styleMap(nativeNew))) {
            problems.push(`[A] native Images replace changed by 4.3.0: styles ${JSON.stringify(styleMap(nativeOld))} -> ${JSON.stringify(styleMap(nativeNew))}`);
        }
        if (JSON.stringify(clsSet(nativeOld)) !== JSON.stringify(clsSet(nativeNew))) {
            problems.push(`[A] native Images replace classes changed: ${clsSet(nativeOld)} -> ${clsSet(nativeNew)}`);
        }

        // (B) AList replacement must equal native replacement, except our marker
        const alist = renderMedia(doc, "ALIST", tabsNew, freshImg(doc, true), el);
        const a = clsSet(alist).filter((c) => c !== "o_alist_external");
        const n = clsSet(nativeNew);
        if (JSON.stringify(a) !== JSON.stringify(n)) {
            problems.push(`[B] AList vs native classes differ: alist=${a} native=${n}`);
        }
        if (JSON.stringify(styleMap(alist)) !== JSON.stringify(styleMap(nativeNew))) {
            problems.push(`[B] AList vs native styles differ: alist=${JSON.stringify(styleMap(alist))} native=${JSON.stringify(styleMap(nativeNew))}`);
        }

        // (C) focal tool: present on the AList result, absent on native result
        if (!alist.matches(FOCAL_SELECTOR)) { problems.push("[C] focal option would NOT appear on AList image"); }
        if (nativeNew.matches(FOCAL_SELECTOR)) { problems.push("[C] focal option would appear on a NATIVE image"); }

        // (D) framed AList image -> native: behave like stock Odoo (keep inline
        //     style), but the tool must stay reachable so framing is never orphaned
        const framed = alist.cloneNode(true);
        framed.style.setProperty("aspect-ratio", "16 / 9");
        framed.style.setProperty("object-fit", "cover");
        framed.style.setProperty("object-position", "20% 30%");
        framed.classList.add("o_alist_framed");
        const backToNative = renderMedia(doc, "IMAGES", tabsNew, freshImg(doc, false), framed);
        const dropped = MANAGED.filter((p) => !backToNative.style.getPropertyValue(p));
        if (dropped.length) { problems.push(`[D] native replace dropped styles stock Odoo keeps: ${dropped}`); }
        if (!backToNative.matches(FOCAL_SELECTOR)) { problems.push("[D] framing orphaned: tool unreachable on native image"); }
        if (backToNative.classList.contains("o_alist_external")) { problems.push("[D] AList marker left on native image"); }

        // (E) framed AList -> AList: framing kept
        const again = renderMedia(doc, "ALIST", tabsNew, freshImg(doc, true), framed);
        const lost = MANAGED.filter((p) => !again.style.getPropertyValue(p));
        if (lost.length) { problems.push(`[E] framing lost on AList->AList: ${lost}`); }

        if (problems.length) {
            snip.issues.push({ tag, problems });
            results.issues.push({ snippet: name, tag, problems });
        } else { snip.ok++; }
    }
}
fs.writeFileSync("/tmp/block_results.json", JSON.stringify(results, null, 2));
console.log(`snippets with media: ${results.snippets}`);
console.log(`media elements: ${results.elements} | replaceable: ${results.replaceable} | excluded by Odoo: ${results.excluded}`);
console.log(`elements with issues: ${results.issues.length}`);
console.log(`snippets carrying managed styles inline: ${results.inlineManaged.length}`);
