import assert from "node:assert/strict";
import {
    clampPercent, parseObjectPosition, formatObjectPosition,
    normalizeAspectRatio, ASPECT_PRESETS, MANAGED_STYLES,
} from "./focal_utils.mjs";

let n = 0; const t = (name, fn) => { fn(); n++; console.log("PASS", name); };

t("unset position = CSS default center", () => assert.deepEqual(parseObjectPosition(""), { x: 50, y: 50 }));
t("percent pair", () => assert.deepEqual(parseObjectPosition("20% 80%"), { x: 20, y: 80 }));
t("decimal percent", () => assert.deepEqual(parseObjectPosition("33.3% 66.7%"), { x: 33.3, y: 66.7 }));
t("keywords left top", () => assert.deepEqual(parseObjectPosition("left top"), { x: 0, y: 0 }));
t("vertical-first keywords 'top left'", () => assert.deepEqual(parseObjectPosition("top left"), { x: 0, y: 0 }));
t("'bottom right'", () => assert.deepEqual(parseObjectPosition("bottom right"), { x: 100, y: 100 }));
t("single 'top' -> centered horizontally", () => assert.deepEqual(parseObjectPosition("top"), { x: 50, y: 0 }));
t("single 'right'", () => assert.deepEqual(parseObjectPosition("right"), { x: 100, y: 50 }));
t("px values we don't manage fall back to center", () => assert.deepEqual(parseObjectPosition("10px 20px"), { x: 50, y: 50 }));
t("out-of-range clamped", () => assert.deepEqual(parseObjectPosition("150% -20%"), { x: 100, y: 0 }));
t("garbage input", () => assert.deepEqual(parseObjectPosition("banana split"), { x: 50, y: 50 }));
t("null input", () => assert.deepEqual(parseObjectPosition(null), { x: 50, y: 50 }));
t("format round-trips", () => assert.deepEqual(parseObjectPosition(formatObjectPosition(12.5, 90)), { x: 12.5, y: 90 }));
t("format clamps", () => assert.equal(formatObjectPosition(-5, 250), "0% 100%"));
t("clampPercent garbage -> 50", () => assert.equal(clampPercent("abc"), 50));
t("aspect normalize '16 / 9' == '16/9'", () => assert.equal(normalizeAspectRatio("16 / 9"), "16/9"));
t("aspect 'auto' treated as unset", () => assert.equal(normalizeAspectRatio("auto"), ""));
t("aspect presets all normalized", () => ASPECT_PRESETS.forEach((p) => assert.equal(normalizeAspectRatio(p), p)));
t("reset covers exactly the three managed styles", () =>
    assert.deepEqual(MANAGED_STYLES, ["aspect-ratio", "object-fit", "object-position"]));
console.log(`\n${n} focal tests passed`);
