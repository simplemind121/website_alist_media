/**
 * Mirrors the class/style carry-over steps of Odoo 19 MediaDialog.renderMedia
 * (html_editor media_dialog.js) to prove how display-area framing behaves when
 * an image is replaced.
 */
import assert from "node:assert/strict";

const IMAGES = { mediaSpecificClasses: ["img", "img-fluid", "o_we_custom_image"], mediaSpecificStyles: ["transform", "width"] };
const ALIST = {
    mediaSpecificClasses: ["img", "img-fluid", "o_we_custom_image", "o_alist_external"],
    mediaSpecificStyles: ["transform", "width"],
};
const FOCAL_SELECTOR_CLASSES = ["o_alist_external", "o_alist_framed"];
const tabs = { IMAGES, ALIST };

function el(classes, styles) { return { classes: new Set(classes), styles: new Map(Object.entries(styles || {})) }; }

// steps copied from renderMedia (class add, style copy, other-tab cleanup, active-tab re-add)
function renderMedia(activeTab, newEl, oldMedia) {
    oldMedia.classes.forEach((c) => newEl.classes.add(c));
    oldMedia.styles.forEach((v, k) => newEl.styles.set(k, v));
    for (const other of Object.keys(tabs).filter((k) => k !== activeTab)) {
        tabs[other].mediaSpecificStyles.forEach((p) => newEl.styles.delete(p));
        tabs[other].mediaSpecificClasses.forEach((c) => newEl.classes.delete(c));
    }
    tabs[activeTab].mediaSpecificClasses.forEach((c) => newEl.classes.add(c));
    return newEl;
}

const framed = () => el(["img", "img-fluid", "o_we_custom_image", "o_alist_external", "o_alist_framed", "shadow"],
    { "aspect-ratio": "16 / 9", "object-fit": "cover", "object-position": "20% 30%" });

let n = 0; const t = (name, fn) => { fn(); n++; console.log("PASS", name); };

t("AList -> AList: framing kept (replace keeps your crop)", () => {
    const out = renderMedia("ALIST", el(["img", "o_alist_external"]), framed());
    assert.equal(out.styles.get("object-position"), "20% 30%");
    assert.equal(out.styles.get("aspect-ratio"), "16 / 9");
    assert.ok(out.classes.has("o_alist_external"));
});
t("AList -> native: stock behaviour kept (framing stays) and tool stays reachable", () => {
    const out = renderMedia("IMAGES", el(["img"]), framed());
    assert.equal(out.styles.get("object-position"), "20% 30%", "stock Odoo copies inline style");
    assert.equal(out.classes.has("o_alist_external"), false, "no longer an AList image");
    assert.ok(out.classes.has("o_alist_framed"), "framing marker survives -> tool still reachable");
});
t("native -> native with inline object-fit (theme_treehouse case) is untouched", () => {
    const themeImg = el(["img-fluid", "w-100", "h-100"], { "object-fit": "cover" });
    const out = renderMedia("IMAGES", el(["img"]), themeImg);
    assert.equal(out.styles.get("object-fit"), "cover", "must equal stock Odoo");
    assert.equal(FOCAL_SELECTOR_CLASSES.some((c) => out.classes.has(c)), false, "tool must not appear");
});
t("user classes (shadow) survive either way, as before", () => {
    assert.ok(renderMedia("IMAGES", el(["img"]), framed()).classes.has("shadow"));
    assert.ok(renderMedia("ALIST", el(["img"]), framed()).classes.has("shadow"));
});
t("native -> AList: gets the marker, no stray framing invented", () => {
    const native = el(["img", "img-fluid", "o_we_custom_image"], { width: "50%" });
    const out = renderMedia("ALIST", el(["img"]), native);
    assert.ok(out.classes.has("o_alist_external"));
    assert.equal(out.styles.has("object-position"), false);
});
console.log(`\n${n} replace carry-over tests passed`);
