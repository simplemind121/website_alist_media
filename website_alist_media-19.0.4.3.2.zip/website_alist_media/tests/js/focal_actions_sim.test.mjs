/**
 * Runs the four builder actions of alist_focal_option.js against a fake element
 * whose `style` behaves like CSSStyleDeclaration (set/remove/read), with the
 * action bodies copied verbatim from the shipped file.
 */
import assert from "node:assert/strict";
import { FRAMED_CLASS, formatObjectPosition, MANAGED_STYLES, normalizeAspectRatio, parseObjectPosition } from "./focal_utils.mjs";

function fakeEl(initial = {}) {
    const props = new Map(Object.entries(initial));
    const camel = (p) => p.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
    const style = {
        setProperty: (p, v) => props.set(p, String(v)),
        removeProperty: (p) => props.delete(p),
        get aspectRatio() { return props.get("aspect-ratio") || ""; },
        get objectFit() { return props.get("object-fit") || ""; },
        get objectPosition() { return props.get("object-position") || ""; },
        get width() { return props.get("width") || ""; },
    };
    const classes = new Set();
    const classList = { add: (c) => classes.add(c), remove: (c) => classes.delete(c), contains: (c) => classes.has(c) };
    return { style, props, camel, classList };
}
const currentPosition = (el) => parseObjectPosition(el.style.objectPosition);
const ensureCover = (el) => { if (!el.style.objectFit) { el.style.setProperty("object-fit", "cover"); } };
const markFramed = (el) => el.classList.add(FRAMED_CLASS);
const Aspect = {
    apply({ editingElement: el, value }) {
        const ratio = normalizeAspectRatio(value);
        if (!ratio) { el.style.removeProperty("aspect-ratio"); return; }
        el.style.setProperty("aspect-ratio", ratio.replace("/", " / "));
        ensureCover(el);
        markFramed(el);
    },
    isApplied: ({ editingElement: el, value }) => normalizeAspectRatio(el.style.aspectRatio) === normalizeAspectRatio(value),
};
const Preset = {
    apply({ editingElement: el, value }) { const [x, y] = String(value).split(/\s+/); el.style.setProperty("object-position", formatObjectPosition(x, y)); ensureCover(el); markFramed(el); },
    isApplied({ editingElement: el, value }) { const [x, y] = String(value).split(/\s+/).map(Number); const p = currentPosition(el); return p.x === x && p.y === y; },
};
const Axis = {
    getValue: ({ editingElement: el, params: { mainParam: a } }) => String(currentPosition(el)[a === "y" ? "y" : "x"]),
    apply({ editingElement: el, params: { mainParam: a }, value }) { const p = currentPosition(el); if (a === "y") { p.y = value; } else { p.x = value; } el.style.setProperty("object-position", formatObjectPosition(p.x, p.y)); ensureCover(el); markFramed(el); },
};
const Fit = {
    apply({ editingElement: el, value }) { el.style.setProperty("object-fit", value); markFramed(el); },
    isApplied: ({ editingElement: el, value }) => el.style.objectFit === value,
};
const Reset = { apply({ editingElement: el }) { for (const p of MANAGED_STYLES) { el.style.removeProperty(p); } el.classList.remove(FRAMED_CLASS); } };

let n = 0; const t = (name, fn) => { fn(); n++; console.log("PASS", name); };

t("ratio sets aspect-ratio AND cover (never stretches)", () => {
    const el = fakeEl(); Aspect.apply({ editingElement: el, value: "16/9" });
    assert.equal(el.style.aspectRatio, "16 / 9"); assert.equal(el.style.objectFit, "cover");
});
t("ratio keeps an explicit contain chosen by the user", () => {
    const el = fakeEl({ "object-fit": "contain" }); Aspect.apply({ editingElement: el, value: "1/1" });
    assert.equal(el.style.objectFit, "contain");
});
t("Auto removes only the ratio", () => {
    const el = fakeEl({ "aspect-ratio": "4 / 3", "object-fit": "cover", "object-position": "10% 10%" });
    Aspect.apply({ editingElement: el, value: "" });
    assert.equal(el.style.aspectRatio, ""); assert.equal(el.style.objectFit, "cover"); assert.equal(el.style.objectPosition, "10% 10%");
});
t("ratio isApplied survives browser normalisation '16 / 9'", () =>
    assert.equal(Aspect.isApplied({ editingElement: fakeEl({ "aspect-ratio": "16 / 9" }), value: "16/9" }), true));
t("preset top-left writes 0% 0% + cover", () => {
    const el = fakeEl(); Preset.apply({ editingElement: el, value: "0 0" });
    assert.equal(el.style.objectPosition, "0% 0%"); assert.equal(el.style.objectFit, "cover");
});
t("preset isApplied matches only its own point", () => {
    const el = fakeEl({ "object-position": "50% 100%" });
    assert.equal(Preset.isApplied({ editingElement: el, value: "50 100" }), true);
    assert.equal(Preset.isApplied({ editingElement: el, value: "50 50" }), false);
});
t("center preset active on an untouched image (CSS default)", () =>
    assert.equal(Preset.isApplied({ editingElement: fakeEl(), value: "50 50" }), true));
t("axis x changes x, keeps y", () => {
    const el = fakeEl({ "object-position": "10% 80%" });
    Axis.apply({ editingElement: el, params: { mainParam: "x" }, value: "35" });
    assert.equal(el.style.objectPosition, "35% 80%");
});
t("axis y changes y, keeps x", () => {
    const el = fakeEl({ "object-position": "10% 80%" });
    Axis.apply({ editingElement: el, params: { mainParam: "y" }, value: "5" });
    assert.equal(el.style.objectPosition, "10% 5%");
});
t("axis getValue reads back what apply wrote", () => {
    const el = fakeEl(); Axis.apply({ editingElement: el, params: { mainParam: "y" }, value: "72" });
    assert.equal(Axis.getValue({ editingElement: el, params: { mainParam: "y" } }), "72");
    assert.equal(Axis.getValue({ editingElement: el, params: { mainParam: "x" } }), "50");
});
t("axis clamps slider garbage", () => {
    const el = fakeEl(); Axis.apply({ editingElement: el, params: { mainParam: "x" }, value: "999" });
    assert.equal(el.style.objectPosition, "100% 50%");
});
t("reset removes the 3 managed props and NOTHING else", () => {
    const el = fakeEl({ "aspect-ratio": "1 / 1", "object-fit": "cover", "object-position": "0% 0%", width: "50%" });
    Reset.apply({ editingElement: el });
    assert.equal(el.style.aspectRatio, ""); assert.equal(el.style.objectFit, ""); assert.equal(el.style.objectPosition, "");
    assert.equal(el.style.width, "50%", "native Size option value must survive reset");
});
t("every write marks the image as framed", () => {
    for (const [act, args] of [[Aspect, { value: "4/3" }], [Preset, { value: "0 0" }], [Fit, { value: "contain" }],
        [Axis, { params: { mainParam: "x" }, value: "10" }]]) {
        const el = fakeEl(); act.apply({ editingElement: el, ...args });
        assert.ok(el.classList.contains(FRAMED_CLASS));
    }
});
t("Auto ratio on an untouched image does not mark it", () => {
    const el = fakeEl(); Aspect.apply({ editingElement: el, value: "" });
    assert.equal(el.classList.contains(FRAMED_CLASS), false);
});
t("fit action sets value and isApplied reads it", () => {
    const el = fakeEl(); Fit.apply({ editingElement: el, value: "contain" });
    assert.equal(el.style.objectFit, "contain");
    assert.equal(Fit.isApplied({ editingElement: el, value: "contain" }), true);
    assert.equal(Fit.isApplied({ editingElement: el, value: "cover" }), false);
});
t("reset removes the framed marker", () => {
    const el = fakeEl(); Preset.apply({ editingElement: el, value: "0 0" }); Reset.apply({ editingElement: el });
    assert.equal(el.classList.contains(FRAMED_CLASS), false);
});
console.log(`\n${n} focal action tests passed`);
