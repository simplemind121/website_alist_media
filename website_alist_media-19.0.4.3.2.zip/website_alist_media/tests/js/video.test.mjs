// Tests the REAL shipped JS (copied by run.sh), not a Python mirror.
import assert from "node:assert/strict";
import {
    isDirectMediaVideoUrl,
    extractBackgroundVideoSrc,
    mergeVisibleTabs,
    mergeExtraTabsWithAList,
} from "./bg_video_utils.mjs";
import {
    sanitizeAListVideoElements,
    sanitizeAListVideosIn,
    shouldAppendAListTab,
} from "./alist_tab_rules.mjs";

// --- minimal DOM stand-ins -------------------------------------------------
class ClassList {
    constructor(list = []) { this.s = new Set(list); }
    add(...c) { c.forEach((x) => this.s.add(x)); }
    remove(...c) { c.forEach((x) => this.s.delete(x)); }
    contains(c) { return this.s.has(c); }
    get list() { return [...this.s].sort(); }
}
function el(tag, { classes = [], attrs = {}, dataset = {}, children = [] } = {}) {
    const a = { ...attrs };
    return {
        tagName: tag,
        classList: new ClassList(classes),
        dataset: { ...dataset },
        getAttribute: (k) => (k in a ? a[k] : null),
        hasAttribute: (k) => k in a,
        setAttribute: (k, v) => { a[k] = v; },
        get src() { return a.src || ""; },
        querySelector(sel) { return children.find((c) => c.tagName.toLowerCase() === sel) || null; },
        querySelectorAll() { return children.filter((c) => c.tagName === "VIDEO"); },
        _attrs: a,
    };
}

// --- direct URL detection (BG playback switch) -------------------------------
assert.equal(isDirectMediaVideoUrl("https://media.example.com/b2/a/demo.mp4"), true);
assert.equal(isDirectMediaVideoUrl("https://media.example.com/b2/a/demo.MP4?x=1#t"), true);
assert.equal(isDirectMediaVideoUrl("https://media.example.com/b2/a/demo.webm"), true);
assert.equal(isDirectMediaVideoUrl("https://www.youtube.com/embed/abc.mp4"), false);
assert.equal(isDirectMediaVideoUrl("//player.vimeo.com/video/528686125"), false);
assert.equal(isDirectMediaVideoUrl("about:blank"), false);
assert.equal(isDirectMediaVideoUrl(""), false);
assert.equal(isDirectMediaVideoUrl(null), false);

// --- BG save payload -> URL ----------------------------------------------------
assert.equal(extractBackgroundVideoSrc(el("VIDEO", { attrs: { src: "https://cdn/x.mp4" } })), "https://cdn/x.mp4");
assert.equal(
    extractBackgroundVideoSrc(el("DIV", { children: [el("IFRAME", { attrs: { src: "//player.vimeo.com/video/1" } })] })),
    "//player.vimeo.com/video/1"
);
assert.equal(extractBackgroundVideoSrc(null), "");

// --- tab merging used by the BG dialog -------------------------------------------
assert.deepEqual(mergeVisibleTabs(["VIDEO_BACKGROUND"], ["ALIST"]), ["VIDEO_BACKGROUND", "ALIST"]);
assert.deepEqual(mergeVisibleTabs(["ALIST"], ["ALIST"]), ["ALIST"]);
const base = [{ id: "VIDEO_BACKGROUND" }];
const merged = mergeExtraTabsWithAList(base, { id: "ALIST" });
assert.equal(merged.length, 2);
assert.equal(base.length, 1, "input must not be mutated");
assert.equal(mergeExtraTabsWithAList(merged, { id: "ALIST" }).length, 2);

// BG dialog is not "onlyImages": our images-only patch must NOT add a 2nd AList tab
assert.equal(
    shouldAppendAListTab(
        { visibleTabs: ["VIDEO_BACKGROUND", "ALIST"], extraTabs: merged },
        ["VIDEO_BACKGROUND", "ALIST"]
    ),
    false
);

// --- body video class hygiene ------------------------------------------------------
const v = el("VIDEO", {
    classes: ["o_alist_cdn_video", "img", "img-fluid", "o_we_custom_image", "mx-auto", "rounded"],
    attrs: { src: "https://cdn/demo.mp4" },
});
sanitizeAListVideoElements([v]);
assert.deepEqual(v.classList.list, ["img-fluid", "mx-auto", "o_alist_cdn_video", "rounded"]);
assert.equal(v.hasAttribute("controls"), true);
assert.equal(v.hasAttribute("playsinline"), true);
assert.equal(v.dataset.alistExternal, "1");
// idempotent
sanitizeAListVideoElements([v]);
assert.deepEqual(v.classList.list, ["img-fluid", "mx-auto", "o_alist_cdn_video", "rounded"]);
// stock video untouched
const stock = el("VIDEO", { classes: ["img", "foo"] });
sanitizeAListVideoElements([stock]);
assert.deepEqual(stock.classList.list, ["foo", "img"]);
// images untouched
const img = el("IMG", { classes: ["img", "o_we_custom_image"], dataset: { alistExternal: "1" } });
sanitizeAListVideoElements([img]);
assert.deepEqual(img.classList.list, ["img", "o_we_custom_image"]);
// root / {root} payload forms
const v2 = el("VIDEO", { classes: ["o_alist_cdn_video", "img"] });
sanitizeAListVideosIn({ root: el("DIV", { children: [v2] }) });
assert.equal(v2.classList.contains("img"), false);
sanitizeAListVideosIn(undefined); // must not throw
sanitizeAListVideosIn({});

console.log("video.test.mjs: all assertions passed");

// --- 19.0.4.2.0: poster matching + unplayable containers -------------------
import {
    baseName,
    findPosterItem,
    isLikelyUnplayable,
    NON_WEB_VIDEO_EXTENSIONS,
} from "./alist_tab_rules.mjs";

const folder = [
    { name: "sub", is_dir: true, ref: "/v/sub" },
    { name: "demo.mp4", media_type: "video", ref: "/v/demo.mp4" },
    { name: "demo.jpg", media_type: "image", ref: "/v/demo.jpg" },
    { name: "clip.webm", media_type: "video", ref: "/v/clip.webm" },
    { name: "clip-poster.png", media_type: "image", ref: "/v/clip-poster.png" },
    { name: "lonely.mp4", media_type: "video", ref: "/v/lonely.mp4" },
    { name: "DEMO.PNG", media_type: "image", ref: "/v/DEMO.PNG" },
];

// same base name wins
assert.equal(findPosterItem(folder, folder[1]).ref, "/v/demo.jpg");
// "-poster" suffix fallback
assert.equal(findPosterItem(folder, folder[3]).ref, "/v/clip-poster.png");
// no candidate -> null (never guesses an unrelated image)
assert.equal(findPosterItem(folder, folder[5]), null);
// never returns a folder or the video itself
assert.equal(findPosterItem([folder[0], folder[1]], folder[1]), null);
// defensive inputs
assert.equal(findPosterItem(null, folder[1]), null);
assert.equal(findPosterItem(folder, null), null);
assert.equal(findPosterItem(folder, { name: "" }), null);

assert.equal(baseName("A.Movie.Name.MP4"), "a.movie.name");

// unplayable containers
for (const ext of NON_WEB_VIDEO_EXTENSIONS) {
    assert.equal(isLikelyUnplayable(`film${ext}`), true, ext);
    assert.equal(isLikelyUnplayable(`film${ext.toUpperCase()}`), true, ext);
}
for (const ok of ["a.mp4", "a.webm", "a.mov", "a.m4v", "a.ogv", "a.jpg"]) {
    assert.equal(isLikelyUnplayable(ok), false, ok);
}
assert.equal(isLikelyUnplayable(null), false);
assert.equal(isLikelyUnplayable("mkv.mp4"), false, "extension must be at the end");

console.log("video.test.mjs: 19.0.4.2.0 poster/unplayable assertions passed");

// --- grid thumbnail fallback (sibling cover image) ------------------------
function thumbFor(item, items) {
    if (item.preview_url) { return item.preview_url; }
    if (item.is_dir || item.media_type !== "video") { return null; }
    const poster = findPosterItem(items, item);
    return (poster && poster.preview_url) || null;
}
const grid = [
    { name: "demo.mp4", media_type: "video", ref: "/v/demo.mp4" },
    { name: "demo.jpg", media_type: "image", ref: "/v/demo.jpg", preview_url: "https://cdn/x/demo.jpg?w=320" },
    { name: "nocover.mp4", media_type: "video", ref: "/v/nocover.mp4" },
    { name: "withthumb.mp4", media_type: "video", ref: "/v/wt.mp4", preview_url: "https://cdn/thumb.jpg" },
    { name: "pic.png", media_type: "image", ref: "/v/pic.png", preview_url: "https://cdn/pic.png?w=320" },
    { name: "sub", is_dir: true, ref: "/v/sub" },
];
assert.equal(thumbFor(grid[0], grid), "https://cdn/x/demo.jpg?w=320", "video uses sibling cover");
assert.equal(thumbFor(grid[2], grid), null, "no cover -> icon fallback");
assert.equal(thumbFor(grid[3], grid), "https://cdn/thumb.jpg", "AList thumb still wins");
assert.equal(thumbFor(grid[4], grid), "https://cdn/pic.png?w=320", "images unchanged");
assert.equal(thumbFor(grid[5], grid), null, "folders never get a thumbnail");
console.log("video.test.mjs: grid thumbnail fallback assertions passed");
