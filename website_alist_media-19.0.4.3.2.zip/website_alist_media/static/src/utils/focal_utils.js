/** @odoo-module **/

/**
 * Pure helpers for the AList image "display area" option (19.0.4.3.0).
 * No Odoo imports so they can be unit-tested outside Odoo.
 *
 * Why CSS and not cropping: Odoo's crop/filter tools refuse cross-origin
 * images (canvas would be tainted). A focal point expressed with
 * `object-position` + `object-fit` + `aspect-ratio` changes only what is
 * shown, never the file, and is fully reversible.
 */

const KEYWORDS = { left: 0, top: 0, center: 50, right: 100, bottom: 100 };

export function clampPercent(value) {
    const n = Number.parseFloat(value);
    if (!Number.isFinite(n)) {
        return 50;
    }
    return Math.round(Math.min(100, Math.max(0, n)) * 10) / 10;
}

function tokenToPercent(token) {
    if (token in KEYWORDS) {
        return KEYWORDS[token];
    }
    if (/^-?\d+(\.\d+)?%$/.test(token)) {
        return clampPercent(token);
    }
    return null; // px or anything else we do not manage
}

/**
 * Parse a CSS `object-position` value into {x, y} percentages.
 * Unset / unparsable values fall back to the CSS default (center).
 */
export function parseObjectPosition(value) {
    const tokens = String(value || "").trim().toLowerCase().split(/\s+/).filter(Boolean);
    if (!tokens.length) {
        return { x: 50, y: 50 };
    }
    if (tokens.length === 1) {
        const t = tokens[0];
        if (t === "top" || t === "bottom") {
            return { x: 50, y: KEYWORDS[t] };
        }
        const x = tokenToPercent(t);
        return { x: x === null ? 50 : x, y: 50 };
    }
    let [a, b] = tokens;
    // "top left" is valid CSS: vertical keyword first
    if ((a === "top" || a === "bottom") && (b === "left" || b === "right" || b === "center")) {
        [a, b] = [b, a];
    }
    const x = tokenToPercent(a);
    const y = tokenToPercent(b);
    return { x: x === null ? 50 : x, y: y === null ? 50 : y };
}

export function formatObjectPosition(x, y) {
    return `${clampPercent(x)}% ${clampPercent(y)}%`;
}

/** Normalise an aspect-ratio value for comparison: "16 / 9" == "16/9". */
export function normalizeAspectRatio(value) {
    const v = String(value || "").trim().toLowerCase().replace(/\s+/g, "");
    return v === "auto" ? "" : v;
}

export const ASPECT_PRESETS = ["", "16/9", "4/3", "1/1", "3/4"];
export const FIT_VALUES = ["cover", "contain"];

/**
 * Class added whenever the option writes framing. Keeps the tool reachable on an
 * image that inherited framing through a replacement (Odoo copies classes and
 * inline style onto the replacing image), without ever stripping styles that
 * stock Odoo would keep.
 */
export const FRAMED_CLASS = "o_alist_framed";

/** Styles managed by the option, cleared together by "reset". */
export const MANAGED_STYLES = ["aspect-ratio", "object-fit", "object-position"];
