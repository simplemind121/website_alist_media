/** @odoo-module **/

import { BuilderAction } from "@html_builder/core/builder_action";
import { BaseOptionComponent, useDomState } from "@html_builder/core/utils";
import { after, IMAGE_TOOL } from "@html_builder/utils/option_sequence";
import { Plugin } from "@html_editor/plugin";
import { withSequence } from "@html_editor/utils/resource";
import { registry } from "@web/core/registry";
import {
    FRAMED_CLASS,
    formatObjectPosition,
    MANAGED_STYLES,
    normalizeAspectRatio,
    parseObjectPosition,
} from "../utils/focal_utils";

/**
 * "Display area" option for images inserted from AList (19.0.4.3.0).
 *
 * Scope: only images this module inserted (data-alist-external or
 * the o_alist_external class).
 * Native images and every other element are untouched.
 *
 * Mechanism: inline CSS only (aspect-ratio, object-fit, object-position).
 * The file is never modified, nothing goes to the server, and "Reset" removes
 * exactly the three properties this option manages. Built on the official
 * Odoo 19 builder option API (builder_options / builder_actions); no private
 * method is patched.
 */

// data-alist-external is set on every AList image, but Odoo's HTML sanitizer
// only keeps allow-listed data-* attributes, so in sanitized HTML fields it can
// be stripped on save. The class marker (19.0.4.3.0+) always survives.
//
// o_alist_framed: an image that got framing from this tool keeps the tool even
// after being replaced by a native image (Odoo copies classes + inline style to
// the replacement, and we deliberately do not strip them, to stay identical to
// stock behaviour). So framing is never orphaned without a way to edit it.
const SELECTOR = "img[data-alist-external], img.o_alist_external, img.o_alist_framed";

function currentPosition(el) {
    return parseObjectPosition(el.style.objectPosition);
}

/** A focal point / fixed ratio only shows its effect when the image is cropped. */
function ensureCover(el) {
    if (!el.style.objectFit) {
        el.style.setProperty("object-fit", "cover");
    }
}

function markFramed(el) {
    el.classList.add(FRAMED_CLASS);
}

export class AlistFocalOption extends BaseOptionComponent {
    static template = "website_alist_media.AlistFocalOption";
    static selector = SELECTOR;

    setup() {
        super.setup();
        this.state = useDomState((el) => ({
            hasRatio: !!normalizeAspectRatio(el.style.aspectRatio),
            fit: el.style.objectFit || "",
            position: currentPosition(el),
        }));
    }
}

/** Fixed frame ratio. "" removes it; any ratio also switches to cover so the
 *  image is cropped instead of stretched. */
export class AlistAspectAction extends BuilderAction {
    static id = "alistAspect";
    apply({ editingElement: el, value }) {
        const ratio = normalizeAspectRatio(value);
        if (!ratio) {
            el.style.removeProperty("aspect-ratio");
            return;
        }
        el.style.setProperty("aspect-ratio", ratio.replace("/", " / "));
        ensureCover(el);
        markFramed(el);
    }
    isApplied({ editingElement: el, value }) {
        return normalizeAspectRatio(el.style.aspectRatio) === normalizeAspectRatio(value);
    }
}

/** Nine-point presets: actionValue is "x y" in percent. */
export class AlistFocalPresetAction extends BuilderAction {
    static id = "alistFocalPreset";
    apply({ editingElement: el, value }) {
        const [x, y] = String(value).split(/\s+/);
        el.style.setProperty("object-position", formatObjectPosition(x, y));
        ensureCover(el);
        markFramed(el);
    }
    isApplied({ editingElement: el, value }) {
        const [x, y] = String(value).split(/\s+/).map(Number);
        const pos = currentPosition(el);
        return pos.x === x && pos.y === y;
    }
}

/** Fine adjustment of one axis; mainParam is "x" or "y". */
export class AlistFocalAxisAction extends BuilderAction {
    static id = "alistFocalAxis";
    getValue({ editingElement: el, params: { mainParam: axis } }) {
        return String(currentPosition(el)[axis === "y" ? "y" : "x"]);
    }
    apply({ editingElement: el, params: { mainParam: axis }, value }) {
        const pos = currentPosition(el);
        if (axis === "y") {
            pos.y = value;
        } else {
            pos.x = value;
        }
        el.style.setProperty("object-position", formatObjectPosition(pos.x, pos.y));
        ensureCover(el);
        markFramed(el);
    }
}

/** Fill mode (cover / contain). Custom action instead of the built-in
 *  styleAction so that it also marks the image as framed. */
export class AlistFitAction extends BuilderAction {
    static id = "alistFit";
    apply({ editingElement: el, value }) {
        el.style.setProperty("object-fit", value);
        markFramed(el);
    }
    isApplied({ editingElement: el, value }) {
        return el.style.objectFit === value;
    }
}

/** Remove exactly what this option manages; nothing else on the element. */
export class AlistFocalResetAction extends BuilderAction {
    static id = "alistFocalReset";
    apply({ editingElement: el }) {
        for (const prop of MANAGED_STYLES) {
            el.style.removeProperty(prop);
        }
        el.classList.remove(FRAMED_CLASS);
    }
    isApplied() {
        return false;
    }
}

class AlistFocalOptionPlugin extends Plugin {
    static id = "alistFocalOption";
    resources = {
        builder_options: [withSequence(after(IMAGE_TOOL), AlistFocalOption)],
        builder_actions: {
            AlistAspectAction,
            AlistFitAction,
            AlistFocalPresetAction,
            AlistFocalAxisAction,
            AlistFocalResetAction,
        },
    };
}

const websitePlugins = registry.category("website-plugins");
if (!websitePlugins.contains(AlistFocalOptionPlugin.id)) {
    websitePlugins.add(AlistFocalOptionPlugin.id, AlistFocalOptionPlugin);
}

globalThis.__websiteAlistMedia = {
    ...(globalThis.__websiteAlistMedia || {}),
    focalOption: true,
};
