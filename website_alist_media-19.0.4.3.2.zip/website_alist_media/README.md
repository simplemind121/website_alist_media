# Website AList Media — Odoo 19 MediaDialog 扩展（网站编辑器 / 通用 HTML 字段）

> **当前版本 19.0.4.1.1（合并版 + UX 小补丁）**：B 线（19.0.4.0.0）的可靠性能力 + A 线（19.0.3.0.1）经浏览器实测的视频功能。
> 覆盖：网站编辑器/博客正文插入图片和视频、仅图片入口（图库添加、图片拖入、区块背景图、封面、网格加图、图标替换）、**区块背景视频（Videos + AList 并列）**、前台 CDN 直链背景视频以 `<video autoplay muted loop playsinline>` 播放。
> 部署：用配套的 `deploy_website_alist_media.sh`（自动备份、可回滚、支持 `--target staging`）。验收：`TEST_PLAN.md` 第 0 节。变更详情：`CHANGELOG.md`。

在原生「选择媒体」对话框中增加 **AList** 标签页（并支持 S3 兼容源）。选中的图片/视频以 **CDN 直链**
插入**网站构建器 / 博客正文 / 任意 HTML 字段编辑器**，**不写入 filestore**。

> **与 `media_picker` 的关系（重要）**：本模块 v19.0.2.0.0 起**刻意不再触碰**商品图相关的一切
> （`product.image` 字段、`website_sale.shop_product_image` / `carousel_product_indicators`
> 店面模板、商品表单「添加媒体」CustomMediaDialog）。这部分你现网已经由 `media_picker`
> （历史上由 `product_external_media` 合并而来）实现并验证过。本模块只覆盖 `media_picker`
> **没有**覆盖的场景：网站编辑器插入图片、博客正文插入图片等通用 HTML 富文本编辑场景。
> 两者功能不重叠，理论上可以同时安装。

## 早期草稿版本的问题（已修复，仅作记录）

最初这个模块的草稿版本还额外做了一份「商品添加媒体」集成：给 `product.image` 加了
`alist_cdn_url` / `alist_media_kind` 字段，并对 `website_sale.shop_product_image` /
`carousel_product_indicators` 做了 `position="replace"` 的 xpath 继承。这**和你现网的
`media_picker` 几乎是同一件事、改的是同一批字段名和同一批模板节点**：

- 两个模块的 `product.image` 都想加名字完全相同的字段；
- 两个模块都对同一个 xpath 节点做 `replace`——如果 `media_picker` 先把那个节点整个替换掉，
  这个模块的 xpath 在安装/升级时会因为找不到节点而报错（`Element '...' cannot be located`），
  即使侥幸不报错也会互相打架、渲染错乱。

所以这一版**直接删除**了那部分代码（`models/product_image.py`、
`views/product_image_views.xml`、`views/website_sale_templates.xml`、
`static/src/media_dialog/custom_media_dialog_patch.js`、
`static/src/media_dialog/x2many_media_viewer_patch.js`，以及控制器里专门配合它们的
`/website_alist_media/create_url_attachments` 接口），`depends` 里也去掉了不再需要的
`website_sale`。商品图片这块请继续用你现有的 `media_picker`。

---

## 安装步骤

1. 将 `website_alist_media/` 放入 Odoo `addons_path`。
2. 更新应用列表，安装 **Website AList Media (MediaDialog)**。
3. 以管理员打开：**网站 → AList 媒体 → 媒体源**（网站应用顶部菜单栏），新建来源：
   - 类型：`AList` 或 `S3 Compatible`
   - API Base URL、Token（或 `secret_ref` 环境变量名）
   - **CDN / Public Base URL**（永久公网域名）
   - AList 默认 `CDN Strip Path Prefix = /d`
4. 点 **Test Connection**，状态应为 Connected。
5. **网站编辑器 / 博客正文等通用 HTML 字段**：插入/替换媒体 → 「选择媒体」应能看到 **AList**
   标签；选图插入 `<img src="https://cdn...">`。

生产环境建议用 `secret_ref`（如 `WEBSITE_ALIST_TOKEN_MAIN`），不要把 token 写进数据库字段。

---

## Odoo 19 调研结论（MediaDialog 扩展点）

来源：`odoo/odoo` 分支 **19.0**（GitHub raw / 上游文件）。

### 核心符号

| 符号 | 文件 | 作用 |
|------|------|------|
| `media_dialog_extra_tabs` | `addons/html_editor/static/src/main/media/media_plugin.js` | Editor **resource**；`MediaPlugin.openMediaDialog` 把它传给 `MediaDialog` 的 `extraTabs` |
| `MediaDialog` | `.../media_dialog/media_dialog.js` | `addTabs()` 末尾：`this.props.extraTabs.forEach((tab) => this.addTab(tab))` |
| `VideoPlugin` / `FilePlugin` | `video_plugin.js` / `file_plugin.js` | **官方范例**：在 `resources = { media_dialog_extra_tabs: { id, title, Component, sequence } }` 注册标签 |
| `Component.createElements(selectedMedia, { orm })` | 各 Selector 静态方法 | `MediaDialog.renderMedia` 调用来生成插入 DOM |
| `website-plugins` registry | `addons/website/static/src/builder/website_builder.js` | 网站构建器插件集 |
| `MAIN_PLUGINS` | `@html_editor/plugin_sets` | 后端 HTML 字段编辑器插件列表 |

### 本模块注册方式

1. **`AListMediaPlugin`** — 通过 `media_dialog_extra_tabs` 资源 + 追加到 `MAIN_PLUGINS`
   （后端 HTML 字段）+ 注册到 `website-plugins` registry（网站构建器）。
2. `AListSelector.createElements`：图片 → `<img src="https://cdn..." class="img img-fluid
   o_we_custom_image" data-alist-external="1">`；视频文件 → `<video controls playsinline
   src="https://cdn...">`。**不**调用上传服务，**不**创建 `ir.attachment`（这条路径完全不涉及
   `product.image` 或商品表单）。
3. 服务端 `/website_alist_media/resolve` 做 AList `raw_url` → CDN 重写（去掉配置的 `/d` 前缀）
   并做主机 allowlist（SSRF）。

**注意**：`media_dialog_extra_tabs` / `MAIN_PLUGINS` / `website-plugins` 都是 Odoo 内部实现细节，
不是公开稳定 API，Odoo 小版本升级时命名或结构可能变化。本模块没有商品页那份代码那么深地扎进私有
组件内部状态（`this.state.activeTab` 等），风险明显更低，但仍建议先在测试库验证「选择媒体」弹窗
里确实出现了 AList 标签，再上生产。

---

## 功能概览

| 能力 | 说明 |
|------|------|
| 多来源 | `website.alist.media.source`：`alist` \| `s3` |
| 密钥 | `token` / `s3_secret_key` 或 `secret_ref` 环境变量；JSON **永不**返回密钥 |
| 超时 | HTTP 约 **5s**；简易断路器 |
| CDN | `rewrite_url_to_cdn` + `cdn_strip_path_prefix`（默认 `/d`） |
| SSRF | 仅允许来源 base / CDN / 额外 trusted_domains |
| 权限 | 配置：AList Media Sources Manager / 系统管理员；浏览：网站设计师 |

### 控制器

- `POST /website_alist_media/sources`
- `POST /website_alist_media/list`
- `POST /website_alist_media/search`
- `POST /website_alist_media/resolve`

---

## 已知缺口 / 限制

1. **不覆盖商品图片**：这是刻意的（见上），商品图片继续用 `media_picker`。
2. **S3**：优先 `boto3`；无 boto3 时仅能对公开桶做 ListObjects XML 回退。
3. **搜索**：AList 侧为根目录列表后的文件名过滤（非完整远端索引 API）。

---

## 测试

```bash
cd website_alist_media && python3 -m unittest tests.test_cdn_utils -v
```

覆盖：`normalize_path`、`rewrite_url_to_cdn`、host allowlist、`guess_media_type`。

---

## 依赖模块

- `html_editor` — MediaDialog / Plugin
- `html_builder` — 网站构建器插件集
- `website` — 菜单、设计师组、`website-plugins`
- `web` — OWL / RPC

**不**依赖、也**不**修改 `media_picker` 或 `website_sale` 的任何模型/模板。

版本：**19.0.3.0.0**

---

## 19.0.3.0.0 更新：入口覆盖补全

诊断发现 Odoo 19 的 `MediaDialog.addTabs()` 在「仅图片模式」（`onlyImages`）下会提前返回，
自定义标签全部不加载。已对照 odoo/odoo 19.0 源码逐个核实入口并补全：

| 入口 | 19.0.2 | 19.0.3 |
|------|--------|--------|
| 正文插图 / 替换已有图（含图文混排、轮播） | ✅ | ✅ |
| Image 积木拖入 | ❌ | ✅ 仅图片 |
| 相册「添加图片」 | ❌ | ✅ 仅图片，支持多选 |
| 区块背景图 / 博客封面 / 网格添加图片 | ❌ | ✅ 仅图片 |
| 编辑器工具栏「替换图标」 | ❌ | ✅ 图片可替换图标 |
| 星级评分 / 手风琴自定义图标 | ❌ | ❌ 刻意排除（只接受图标 class） |
| 二进制图片字段 / 视频背景 / 社交图标 | ❌ | ❌ 刻意排除 |

实现：`alist_media_dialog_patch.js`（patch MediaDialog.addTabs 与 IconPlugin），
判定逻辑独立在 `alist_tab_rules.js`，由 `tests/js/` 覆盖。插件注册改为防重复。
测试清单见 `TESTING.md`。
