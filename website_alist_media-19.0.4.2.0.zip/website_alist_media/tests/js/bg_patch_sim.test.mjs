/**
 * Simulates the load-order handling of background_video_dialog_patch.js
 * against a minimal copy of Odoo's Registry UPDATE semantics (web/core/registry.js).
 */
import assert from "node:assert/strict";

class MiniRegistry {
    constructor() { this.content = {}; this.listeners = []; }
    contains(k) { return k in this.content; }
    get(k) { return this.content[k]; }
    add(k, v) { this.content[k] = v; this.listeners.forEach((cb) => cb({ detail: { operation: "add", key: k, value: v } })); }
    addEventListener(_ev, cb) { this.listeners.push(cb); }
}

const STOCK_PLUGIN_ID = "websiteBackgroundVideoPlugin";

// same control flow as the shipped patch file
function install(registry, marker) {
    const patched = [];
    function patchBackgroundVideoPlugin(PluginClass) {
        if (!PluginClass || PluginClass.__websiteAlistMediaPatched) { return; }
        PluginClass.__websiteAlistMediaPatched = true;
        patched.push(PluginClass);
        marker.bgVideoPatch = true;
    }
    if (registry.contains(STOCK_PLUGIN_ID)) {
        patchBackgroundVideoPlugin(registry.get(STOCK_PLUGIN_ID));
    } else {
        marker.bgVideoPatch = "pending";
        registry.addEventListener("UPDATE", (ev) => {
            const { operation, key, value } = ev.detail || {};
            if (operation === "add" && key === STOCK_PLUGIN_ID) { patchBackgroundVideoPlugin(value); }
        });
    }
    return patched;
}

let n = 0; const t = (name, fn) => { fn(); n++; console.log("PASS", name); };

t("stock plugin already registered (today's asset order) -> patched immediately", () => {
    const reg = new MiniRegistry(); const marker = {};
    class P {}
    reg.add(STOCK_PLUGIN_ID, P);
    const patched = install(reg, marker);
    assert.deepEqual(patched, [P]);
    assert.equal(marker.bgVideoPatch, true);
});

t("our file evaluated FIRST (future asset reorder) -> patched when registered", () => {
    const reg = new MiniRegistry(); const marker = {};
    const patched = install(reg, marker);
    assert.deepEqual(patched, [], "nothing to patch yet");
    assert.equal(marker.bgVideoPatch, "pending", "state visible to testers");
    class P {}
    reg.add(STOCK_PLUGIN_ID, P);
    assert.deepEqual(patched, [P], "patched on registration instead of silently skipped");
    assert.equal(marker.bgVideoPatch, true);
});

t("unrelated plugins registered later do not trigger the patch", () => {
    const reg = new MiniRegistry(); const marker = {};
    const patched = install(reg, marker);
    class Other {}
    reg.add("someOtherPlugin", Other);
    assert.deepEqual(patched, []);
    assert.equal(marker.bgVideoPatch, "pending");
});

t("double registration (force re-add) patches only once", () => {
    const reg = new MiniRegistry(); const marker = {};
    const patched = install(reg, marker);
    class P {}
    reg.add(STOCK_PLUGIN_ID, P);
    reg.add(STOCK_PLUGIN_ID, P);
    assert.deepEqual(patched, [P]);
});

console.log(`\n${n} bg-patch load-order tests passed`);
