# -*- coding: utf-8 -*-
"""Pure helpers added in 19.0.4.0.0 (no Odoo imports; unit-testable).

- upload filename / target path validation
- thumbnail + resize URL templates, srcset building
- CDN URL extraction for the reference index / link health check
"""
from __future__ import annotations

import os
import re
import unicodedata
from urllib.parse import urlparse

from .cdn_utils import normalize_path

MAX_FILENAME_LEN = 150
_UNSAFE_CHARS = re.compile(r'[^\w.\- ]+', re.UNICODE)
_MULTI_WS = re.compile(r'\s+')


class ValidationFailure(ValueError):
    """User-facing validation error (message is safe to display)."""


def sanitize_upload_filename(name: str, allowed_exts: tuple) -> str:
    """Return a safe basename or raise ValidationFailure.

    Keeps unicode letters (Chinese names allowed), strips path components,
    control chars and anything outside [word . - space]. Extension must be in
    allowed_exts (lowercase, with dot).
    """
    raw = os.path.basename((name or '').replace('\\', '/')).strip()
    raw = unicodedata.normalize('NFC', raw)
    raw = ''.join(ch for ch in raw if unicodedata.category(ch)[0] != 'C')
    if not raw or raw in ('.', '..'):
        raise ValidationFailure('Empty or invalid file name.')
    stem, ext = os.path.splitext(raw)
    ext = ext.lower()
    if not ext or ext not in tuple(e.lower() for e in allowed_exts):
        raise ValidationFailure(f'File type "{ext or "(none)"}" is not allowed.')
    stem = _UNSAFE_CHARS.sub('_', stem)
    stem = _MULTI_WS.sub(' ', stem).strip(' ._')
    if not stem:
        stem = 'file'
    stem = stem[: MAX_FILENAME_LEN - len(ext)]
    return stem + ext


def build_upload_path(folder: str, filename: str, root_path: str) -> str:
    """Join folder + filename; the folder must be inside root_path.

    Unlike listing (where normalize_path silently clamps to root), an upload
    into an unexpected folder is refused outright.
    """
    raw = (folder or root_path or '/').replace('\\', '/')
    if '..' in raw.split('/'):
        raise ValidationFailure('Upload folder must not contain "..".')
    requested = normalize_path(raw, '/')
    root = normalize_path(root_path or '/', '/')
    if root != '/' and not (requested == root or requested.startswith(root + '/')):
        raise ValidationFailure('Upload folder is outside the configured root path.')
    if '/' in filename or '\\' in filename:
        raise ValidationFailure('Invalid file name.')
    return (requested.rstrip('/') or '') + '/' + filename


def render_url_template(template: str, url: str, width: int | None = None) -> str:
    """Render a resize/thumbnail URL template.

    Placeholders: {url} full URL, {origin} scheme://host, {path} path+query,
    {width} integer width. Empty template -> original URL.
    Example (Cloudflare): {origin}/cdn-cgi/image/width={width},format=auto{path}
    """
    if not template or not url:
        return url
    parsed = urlparse(url)
    origin = f'{parsed.scheme}://{parsed.netloc}' if parsed.scheme and parsed.netloc else ''
    path = parsed.path or '/'
    if parsed.query:
        path = f'{path}?{parsed.query}'
    try:
        return template.format(url=url, origin=origin, path=path, width=int(width or 0))
    except (KeyError, IndexError, ValueError):
        # Misconfigured template: never break insertion, fall back to original.
        return url


def parse_widths(csv_text: str, default=(480, 960, 1600)) -> tuple:
    out = []
    for part in (csv_text or '').split(','):
        part = part.strip()
        if part.isdigit() and 16 <= int(part) <= 8000:
            out.append(int(part))
    return tuple(sorted(set(out))) or tuple(default)


def build_srcset(url: str, template: str, widths) -> str:
    """'u1 480w, u2 960w' or '' when template missing/invalid."""
    if not template or not url:
        return ''
    entries = []
    for w in widths:
        rendered = render_url_template(template, url, w)
        if rendered == url:
            return ''  # template failed to render -> no srcset at all
        entries.append(f'{rendered} {w}w')
    return ', '.join(entries)


# URLs inside HTML attributes, CSS url(...), JSON-escaped text. Stops at quote,
# whitespace, <, >, ), backslash, &quot;
_URL_RE = re.compile(r'https?://[^\s"\'<>()\\]+', re.IGNORECASE)


def extract_urls_for_hosts(text: str, hosts: set) -> set:
    """Return the set of absolute URLs in ``text`` whose host is in ``hosts``."""
    if not text or not hosts:
        return set()
    hosts = {h.lower() for h in hosts if h}
    found = set()
    for match in _URL_RE.findall(text):
        url = match.replace('&amp;', '&').rstrip('.,;')
        if url.endswith('&quot'):
            url = url[: -len('&quot')]
        host = (urlparse(url).hostname or '').lower()
        if host in hosts:
            found.add(url)
    return found


def secret_storage_mode(token: str | None, secret_ref: str | None, s3_secret: str | None = None) -> str:
    """'env' | 'database' | 'mixed' | 'none' (for the security warning)."""
    in_db = bool((token or '').strip() or (s3_secret or '').strip())
    in_env = bool((secret_ref or '').strip())
    if in_db and in_env:
        return 'mixed'
    if in_db:
        return 'database'
    if in_env:
        return 'env'
    return 'none'


# ---------------------------------------------------------------------------
# 19.0.4.2.0 — link-check pacing / stability helpers (pure, unit-tested)
# ---------------------------------------------------------------------------

#: Hard ceilings so a bad config parameter can never make the cron run forever.
LIMITS = {
    'check_batch': (1, 200, 2000),          # (min, default, max)
    'check_timeout': (1, 5, 30),
    'check_time_budget': (5, 120, 1800),    # seconds for the HTTP checking phase
    'scan_time_budget': (5, 120, 1800),     # seconds for the content scan phase
    'fail_threshold': (1, 2, 10),           # consecutive failures before flagging
}


def clamp_setting(name: str, raw_value) -> int:
    """Clamp an ir.config_parameter value into the safe range for `name`."""
    low, default, high = LIMITS[name]
    try:
        value = int(str(raw_value).strip())
    except (TypeError, ValueError, AttributeError):
        return default
    return max(low, min(value, high))


def budget_exhausted(started_at: float, now: float, budget_s: int) -> bool:
    """True when the phase has used up its time budget (monotonic seconds)."""
    if budget_s <= 0:
        return False
    return (now - started_at) >= budget_s


def next_link_status(previous_status: str, probe_status: str,
                     fail_count: int, threshold: int) -> tuple:
    """Decide the stored status after one probe, damping transient CDN blips.

    A single failed probe does not flag a link: the failure is counted and the
    previous status kept until `threshold` consecutive failures. A success
    always clears the counter immediately.

    :returns: (status, fail_count, provisional) where `provisional` is True when
              a failure was recorded but not yet flagged.
    """
    if probe_status == 'ok':
        return 'ok', 0, False
    new_count = max(0, fail_count) + 1
    if new_count >= max(1, threshold):
        return probe_status, new_count, False
    # not yet convinced: keep whatever we knew before (unchecked stays unchecked)
    return previous_status or 'unchecked', new_count, True
