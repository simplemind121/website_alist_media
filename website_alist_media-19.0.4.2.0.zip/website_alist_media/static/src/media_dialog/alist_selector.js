/** @odoo-module **/

import { Component, onMounted, onWillUnmount, useRef, useState } from "@odoo/owl";
import { _t } from "@web/core/l10n/translation";
import { rpc } from "@web/core/network/rpc";
import { browser } from "@web/core/browser/browser";
import { useService } from "@web/core/utils/hooks";
import { KeepLast } from "@web/core/utils/concurrency";
import {
    filterItems,
    findPosterItem,
    isLikelyUnplayable,
} from "./alist_tab_rules";
import {
    DIRECT_VIDEO_EXTENSIONS,
    isDirectMediaVideoUrl,
    urlPathLower,
} from "@website_alist_media/utils/bg_video_utils";

const LAST_FOLDER_KEY = "website_alist_media.last_folder";
const DIMENSION_PROBE_TIMEOUT_MS = 3000;

/** Probe natural size of an image URL; resolves null on error/timeout. */
export function probeImageSize(url, timeoutMs = DIMENSION_PROBE_TIMEOUT_MS) {
    return new Promise((resolve) => {
        const img = new Image();
        const timer = setTimeout(() => resolve(null), timeoutMs);
        img.onload = () => {
            clearTimeout(timer);
            resolve(img.naturalWidth && img.naturalHeight
                ? { width: img.naturalWidth, height: img.naturalHeight }
                : null);
        };
        img.onerror = () => {
            clearTimeout(timer);
            resolve(null);
        };
        img.src = url;
    });
}

function readLastFolders() {
    try {
        return JSON.parse(browser.localStorage.getItem(LAST_FOLDER_KEY) || "{}") || {};
    } catch {
        return {};
    }
}

function writeLastFolder(sourceId, path) {
    try {
        const all = readLastFolders();
        all[sourceId] = path;
        browser.localStorage.setItem(LAST_FOLDER_KEY, JSON.stringify(all));
    } catch {
        // storage unavailable (private mode): feature silently disabled
    }
}

/**
 * True when an AList list/resolve item (or its CDN URL) is a direct video file.
 * Prefer media_type from the API; fall back to extension on name/url/ref.
 * (19.0.3.0.1, browser-verified: body video B1 PASS.)
 * @param {object} media
 * @returns {boolean}
 */
export function isAListVideoMedia(media) {
    if (!media || typeof media !== "object") {
        return false;
    }
    if (media.media_type === "video") {
        return true;
    }
    if (media.media_type === "image") {
        return false;
    }
    const candidates = [media.name, media.url, media.ref, media.preview_url];
    for (const c of candidates) {
        if (c && isDirectMediaVideoUrl(String(c))) {
            return true;
        }
        if (c && typeof c === "string") {
            const lower = urlPathLower(c);
            if (DIRECT_VIDEO_EXTENSIONS.some((ext) => lower.endsWith(ext))) {
                return true;
            }
        }
    }
    return false;
}

/**
 * AList / S3 tab for Odoo 19 MediaDialog.
 * createElements builds <img>/<video> with CDN URLs — no ir.attachment binary.
 */
export class AListSelector extends Component {
    static template = "website_alist_media.AListSelector";
    // Keep "img" so ImageSelector cleanup does not strip classes from AList images.
    // VIDEO nodes get o_alist_cdn_video only in createElements; the renderMedia
    // patch strips forced img-* classes from those videos afterward.
    static mediaSpecificClasses = ["img", "img-fluid", "o_we_custom_image"];
    static mediaSpecificStyles = ["transform", "width"];
    static mediaExtraClasses = [
        "rounded-circle",
        "rounded",
        "img-thumbnail",
        "shadow",
        "w-25",
        "w-50",
        "w-75",
        "w-100",
    ];
    static tagNames = ["IMG", "VIDEO"];
    static props = {
        "*": true,
    };

    setup() {
        this.notification = useService("notification");
        this.keepLast = new KeepLast();
        this.fileInputRef = useRef("fileInput");
        this.gridRef = useRef("mediaGrid");
        this._onGridScroll = null;
        this.state = useState({
            sources: [],
            sourceId: null,
            path: "/",
            pathStack: [],
            items: [],
            total: 0,
            page: 1,
            perPage: 60,
            needle: "",
            searchMode: null, // 'remote' | 'local' after a search
            loading: true,
            error: null,
            uploading: false,
            uploadProgress: "",
        });
        // Non-blocking: the dialog opens immediately, the tab fills in when
        // AList answers (and shows a retry button if it doesn't).
        onMounted(() => {
            this.initialLoad();
            this._bindInfiniteScroll();
        });
        onWillUnmount(() => this._unbindInfiniteScroll());
    }

    // ------------------------------------------------------------- getters
    /**
     * Images-only mode: gallery add, image drop, background image, cover,
     * icon replace. ``alistOnlyImages`` is set by our MediaDialog patch;
     * ``onlyImages`` is accepted too (prop name used by the 3.0.x branch).
     */
    /**
     * Grid thumbnail for one item.
     *
     * AList only returns a ``thumb`` for drivers that have one (network drives);
     * an S3/B2 backed source returns none for videos. In that case fall back to a
     * sibling cover image with the same base name (demo.mp4 -> demo.jpg), the
     * same convention used for the inserted <video poster>. No extra request:
     * that image is already listed in this folder.
     */
    thumbFor(item) {
        if (item.preview_url) {
            return item.preview_url;
        }
        if (item.is_dir || item.media_type !== "video") {
            return null;
        }
        return this.posterThumbs.get(item.ref) || null;
    }

    /** ref -> sibling cover thumbnail, rebuilt only when the listing changes. */
    get posterThumbs() {
        const items = this.state.items || [];
        const key = `${this.state.sourceId}|${this.state.path}|${items.length}`;
        if (this._posterThumbsKey !== key) {
            const map = new Map();
            for (const it of items) {
                if (it.is_dir || it.media_type !== "video") {
                    continue;
                }
                const poster = findPosterItem(items, it);
                if (poster && poster.preview_url) {
                    map.set(it.ref, poster.preview_url);
                }
            }
            this._posterThumbs = map;
            this._posterThumbsKey = key;
        }
        return this._posterThumbs;
    }

    /** Template helper: flag containers browsers cannot play (.mkv, .avi …). */
    isUnplayable(item) {
        return !item.is_dir && item.media_type === "video" && isLikelyUnplayable(item.name);
    }

    get onlyImages() {
        return !!(this.props.alistOnlyImages || this.props.onlyImages);
    }

    /** Background-video picker: folders + direct video files only (3.0.x BG path). */
    get videosOnly() {
        return !this.onlyImages && !!(this.props.videosOnly || this.props.isForBgVideo);
    }

    get visibleItems() {
        if (this.videosOnly) {
            return (this.state.items || []).filter(
                (item) => item.is_dir || isAListVideoMedia(item)
            );
        }
        return filterItems(this.state.items, this.onlyImages);
    }

    get currentSource() {
        return this.state.sources.find((s) => s.id === this.state.sourceId) || null;
    }

    get canUpload() {
        return !!(this.currentSource && this.currentSource.upload_enabled);
    }

    get uploadAccept() {
        const src = this.currentSource;
        if (!src) {
            return "";
        }
        if (this.videosOnly) {
            return (src.video_extensions || []).join(",");
        }
        const exts = [...(src.image_extensions || [])];
        if (!this.onlyImages) {
            exts.push(...(src.video_extensions || []));
        }
        return exts.join(",");
    }

    get selectedRefs() {
        return (this.props.selectedMedia[this.props.id] || []).map((m) => m.ref);
    }

    // -------------------------------------------------------------- loading
    async initialLoad() {
        this.state.loading = true;
        this.state.error = null;
        await this.loadSources();
        if (this.state.sourceId) {
            await this.fetchList();
        } else {
            this.state.loading = false;
        }
    }

    async retry() {
        await this.initialLoad();
    }

    restoreFolder(src) {
        const saved = readLastFolders()[src.id];
        // server clamps any path outside root, so a stale value is harmless
        return saved || src.root_path || "/";
    }

    async loadSources() {
        try {
            const result = await rpc("/website_alist_media/sources", {});
            const sources = result.sources || [];
            this.state.sources = sources;
            if (sources.length) {
                const src = sources[0];
                this.state.sourceId = src.id;
                this.state.path = this.restoreFolder(src);
                this.state.perPage = src.page_size || 60;
            }
        } catch (err) {
            this.state.error = _t("Could not load media sources.");
            console.error(err);
        }
    }

    async onSourceChange(ev) {
        const id = parseInt(ev.target.value, 10);
        const src = this.state.sources.find((s) => s.id === id);
        this.state.sourceId = id;
        this.state.path = src ? this.restoreFolder(src) : "/";
        this.state.pathStack = [];
        this.state.page = 1;
        this.state.perPage = src ? (src.page_size || 60) : 60;
        this.state.needle = "";
        await this.fetchList();
    }

    async fetchList() {
        if (!this.state.sourceId) {
            return;
        }
        this.state.loading = true;
        this.state.error = null;
        const payload = {
            source_id: this.state.sourceId,
            path: this.state.path,
            page: this.state.page,
            per_page: this.state.perPage,
            query: this.state.needle || null,
        };
        try {
            const result = await this.keepLast.add(rpc("/website_alist_media/list", payload));
            if (result.error) {
                this.state.error = result.error;
                this.state.items = [];
                this.props.errorMessages?.(result.error);
            } else {
                this.state.items = result.items || [];
                this.state.total = result.total || 0;
                this.state.searchMode = this.state.needle ? result.search_mode || null : null;
                if (!this.state.needle) {
                    this.state.path = result.path || this.state.path;
                    writeLastFolder(this.state.sourceId, this.state.path);
                }
                this.props.errorMessages?.(null);
            }
        } catch (err) {
            this.state.error = _t("Failed to list media. The AList server may be unreachable.");
            console.error(err);
        } finally {
            this.state.loading = false;
        }
    }

    async onSearch(ev) {
        this.state.needle = ev.target.value || "";
        this.state.page = 1;
        await this.fetchList();
    }

    async clearSearch() {
        this.state.needle = "";
        this.state.page = 1;
        await this.fetchList();
    }

    async openDir(item) {
        if (!item.is_dir) {
            return;
        }
        this.state.pathStack.push(this.state.path);
        this.state.path = item.ref;
        this.state.page = 1;
        this.state.needle = "";
        await this.fetchList();
    }

    async goUp() {
        const prev = this.state.pathStack.pop();
        if (prev !== undefined) {
            this.state.path = prev;
        } else {
            // restored folder: go to its parent
            const parts = this.state.path.split("/").filter(Boolean);
            parts.pop();
            this.state.path = "/" + parts.join("/");
        }
        this.state.page = 1;
        await this.fetchList();
    }

    get canGoUp() {
        const root = (this.currentSource && this.currentSource.root_path) || "/";
        const norm = (p) => "/" + (p || "/").split("/").filter(Boolean).join("/");
        return this.state.pathStack.length > 0 || norm(this.state.path) !== norm(root);
    }

    async loadMore() {
        if (this.state.loading || this.state.items.length >= this.state.total) {
            return;
        }
        this.state.page += 1;
        this.state.loading = true;
        try {
            const result = await rpc("/website_alist_media/list", {
                source_id: this.state.sourceId,
                path: this.state.path,
                page: this.state.page,
                per_page: this.state.perPage,
                query: this.state.needle || null,
            });
            if (!result.error) {
                this.state.items = [...this.state.items, ...(result.items || [])];
                this.state.total = result.total || this.state.total;
            } else {
                // Roll back page so a later retry / scroll does not skip a page.
                this.state.page = Math.max(1, this.state.page - 1);
            }
        } catch (err) {
            this.state.page = Math.max(1, this.state.page - 1);
            console.error(err);
        } finally {
            this.state.loading = false;
        }
    }

    /**
     * Poster for a video: a sibling image with the same base name in the current
     * folder (demo.mp4 -> demo.jpg / demo-poster.png). Best effort: any failure
     * just means no poster, never a failed insertion.
     */
    async _resolvePoster(videoItem) {
        const posterItem = findPosterItem(this.state.items, videoItem);
        if (!posterItem) {
            return null;
        }
        try {
            const res = await rpc("/website_alist_media/resolve", {
                source_id: this.state.sourceId,
                item_ref: posterItem.ref,
            });
            return res && !res.error ? res.url || null : null;
        } catch {
            return null;
        }
    }

    // ------------------------------------------------------ infinite scroll
    _bindInfiniteScroll() {
        const el = this.gridRef.el;
        if (!el || this._onGridScroll) {
            return;
        }
        this._onGridScroll = () => this._maybeLoadMoreOnScroll();
        el.addEventListener("scroll", this._onGridScroll, { passive: true });
    }

    _unbindInfiniteScroll() {
        const el = this.gridRef.el;
        if (el && this._onGridScroll) {
            el.removeEventListener("scroll", this._onGridScroll);
        }
        this._onGridScroll = null;
    }

    _maybeLoadMoreOnScroll() {
        const el = this.gridRef.el;
        if (!el || this.state.loading) {
            return;
        }
        if (this.state.items.length >= this.state.total) {
            return;
        }
        // Near bottom of the scrollable .o_alist_media_grid (120–200px band).
        const threshold = 160;
        if (el.scrollTop + el.clientHeight >= el.scrollHeight - threshold) {
            this.loadMore();
        }
    }

    // ------------------------------------------------------------ selection
    isSelected(item) {
        return this.selectedRefs.includes(item.ref);
    }

    async onClickItem(item) {
        if (item.is_dir) {
            await this.openDir(item);
            return;
        }
        const isVideo = isAListVideoMedia(item);
        const isImage = item.media_type === "image";
        if (this.onlyImages && !isImage) {
            this.notification.add(_t("This dialog only accepts images."), {
                type: "warning",
            });
            return;
        }
        if (this.videosOnly && !isVideo) {
            this.notification.add(_t("This dialog only accepts videos."), {
                type: "warning",
            });
            return;
        }
        if (!isImage && !isVideo) {
            return;
        }
        if (isVideo && isLikelyUnplayable(item.name)) {
            this.notification.add(
                _t(
                    "%(name)s is in a container most browsers cannot play. " +
                        "Convert it to MP4 or WebM for the website.",
                    { name: item.name }
                ),
                { type: "warning" }
            );
        }
        const mediaId = `${this.state.sourceId}:${item.ref}`;
        // Multi-select (image gallery "Add"): clicking a selected item unselects it
        // without another resolve round-trip.
        if (this.props.multiSelect && this.isSelected(item)) {
            this.props.selectMedia({ id: mediaId, ref: item.ref });
            return;
        }
        let resolved;
        try {
            resolved = await rpc("/website_alist_media/resolve", {
                source_id: this.state.sourceId,
                item_ref: item.ref,
            });
        } catch {
            this.notification.add(_t("Could not resolve media URL."), { type: "danger" });
            return;
        }
        if (resolved.error) {
            this.notification.add(resolved.error, { type: "danger" });
            return;
        }
        if (isVideo) {
            resolved.poster = await this._resolvePoster(item);
        }
        this.props.selectMedia(this.toMedia(item, resolved, mediaId));
        if (!this.props.multiSelect) {
            await this.props.save();
        }
    }

    toMedia(item, resolved, mediaId) {
        // 3.0.1 typing rule: trust the server, else detect video by extension
        // so e.g. demo.mp4 never degrades into an <img>.
        let mediaType = resolved.media_type;
        if (!mediaType || mediaType === "unknown") {
            mediaType = isAListVideoMedia({ ...item, ...resolved }) ? "video" : item.media_type;
        }
        return {
            ...item,
            source_id: this.state.sourceId,
            mediaType: "alist",
            url: resolved.url,
            media_type: mediaType,
            name: resolved.name || item.name,
            preview_url: resolved.preview_url || resolved.url,
            srcset: resolved.srcset || null,
            poster: resolved.poster || null,
            sizes: resolved.sizes || null,
            id: mediaId,
        };
    }

    // --------------------------------------------------------------- upload
    triggerUpload() {
        this.fileInputRef.el?.click();
    }

    async onFilesChosen(ev) {
        const files = [...(ev.target.files || [])];
        ev.target.value = "";
        if (!files.length || !this.canUpload) {
            return;
        }
        const src = this.currentSource;
        const maxBytes = (src.upload_max_mb || 20) * 1024 * 1024;
        this.state.uploading = true;
        let done = 0;
        let lastOk = null;
        try {
            for (const file of files) {
                this.state.uploadProgress = `${done + 1}/${files.length}: ${file.name}`;
                if (file.size > maxBytes) {
                    this.notification.add(
                        _t("%(name)s is larger than %(max)s MB.", { name: file.name, max: src.upload_max_mb }),
                        { type: "warning" }
                    );
                    continue;
                }
                const form = new FormData();
                form.append("source_id", String(this.state.sourceId));
                form.append("folder", this.state.path);
                form.append("ufile", file, file.name);
                form.append("csrf_token", globalThis.odoo?.csrf_token || "");
                let result;
                try {
                    const resp = await fetch("/website_alist_media/upload", {
                        method: "POST",
                        body: form,
                        credentials: "same-origin",
                    });
                    result = await resp.json();
                } catch {
                    result = { error: _t("Network error during upload.") };
                }
                if (result.error) {
                    this.notification.add(`${file.name}: ${result.error}`, { type: "danger" });
                    continue;
                }
                done += 1;
                lastOk = result;
            }
        } finally {
            this.state.uploading = false;
            this.state.uploadProgress = "";
        }
        if (done) {
            this.notification.add(_t("%(n)s file(s) uploaded to AList.", { n: done }), {
                type: "success",
            });
            this.state.needle = "";
            this.state.page = 1;
            await this.fetchList();
            // single upload in single-select mode: pre-select it for convenience
            if (done === 1 && lastOk && !this.props.multiSelect && lastOk.ref) {
                const item = this.state.items.find((i) => i.ref === lastOk.ref);
                const okType = this.onlyImages
                    ? lastOk.media_type === "image"
                    : this.videosOnly
                      ? isAListVideoMedia({ ...item, ...lastOk })
                      : true;
                if (item && okType) {
                    this.props.selectMedia(
                        this.toMedia(item, lastOk, `${this.state.sourceId}:${lastOk.ref}`)
                    );
                }
            }
        }
    }

    // ------------------------------------------------------ element builder
    /**
     * Called by MediaDialog.renderMedia — insert CDN URL elements, no filestore.
     * Adds loading=lazy, intrinsic width/height (limits layout shift) and srcset
     * when the source enables it.
     */
    static async createElements(selectedMedia) {
        return Promise.all(
            selectedMedia.map(async (media) => {
                const url = media.url;
                if (isAListVideoMedia(media)) {
                    // 19.0.3.0.1 element (browser-verified, B1 PASS). Do NOT use
                    // media_iframe_video: that class is for YT/Vimeo iframe
                    // wrappers; website.media_video would try to rebuild an iframe.
                    const videoEl = document.createElement("video");
                    videoEl.setAttribute("controls", "controls");
                    videoEl.setAttribute("playsinline", "playsinline");
                    videoEl.setAttribute("preload", "metadata");
                    videoEl.src = url;
                    videoEl.classList.add("o_alist_cdn_video", "img-fluid");
                    videoEl.dataset.alistExternal = "1";
                    if (media.poster) {
                        videoEl.setAttribute("poster", media.poster);
                    }
                    if (media.name) {
                        videoEl.setAttribute("title", media.name);
                    }
                    return videoEl;
                }
                const imageEl = document.createElement("img");
                imageEl.src = url;
                imageEl.alt = (media.name || "").replace(/\.[a-z0-9]+$/i, "");
                imageEl.setAttribute("loading", "lazy");
                imageEl.classList.add("img", "img-fluid", "o_we_custom_image");
                if (media.srcset) {
                    imageEl.setAttribute("srcset", media.srcset);
                    imageEl.setAttribute("sizes", media.sizes || "100vw");
                }
                const size = await probeImageSize(url);
                if (size) {
                    imageEl.setAttribute("width", String(size.width));
                    imageEl.setAttribute("height", String(size.height));
                }
                // Mark as external so save pipelines can skip binary upload
                imageEl.dataset.alistExternal = "1";
                return imageEl;
            })
        );
    }
}
