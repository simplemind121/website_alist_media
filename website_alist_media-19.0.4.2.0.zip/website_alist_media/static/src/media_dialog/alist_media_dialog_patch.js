/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { MediaDialog } from "@html_editor/main/media/media_dialog/media_dialog";
import { IconPlugin } from "@html_editor/main/media/icon_plugin";
import {
    ALIST_TAB_ID,
    findAListTab,
    sanitizeAListVideoElements,
    shouldAppendAListTab,
} from "./alist_tab_rules";

/**
 * Coverage extension for Odoo 19.0 (verified against odoo/odoo 19.0 source).
 *
 * 1) MediaDialog.addTabs() returns early when props.onlyImages is set, before
 *    extraTabs are added. Entry points affected (all pass onlyImages: true):
 *      - Image snippet drop            html_builder image_snippet_option_plugin
 *      - Image gallery "Add images"    website image_gallery_option_plugin (multiImages)
 *      - Section background image      html_builder background_image_option_plugin
 *      - Blog/record cover image       website cover_properties_option_plugin
 *      - Grid "Add image" element      website add_element_option_plugin
 *    We append the AList tab afterwards, images only.
 *
 * 2) The editor toolbar "replace icon" dialog (html_editor IconPlugin.openIconDialog)
 *    opens MediaDialog directly with visibleTabs ["ICONS"] and no extraTabs.
 *    We add AList there and let an image replace the icon element.
 *
 * Deliberately NOT covered (would break native behaviour):
 *    - Rating / accordion custom-icon pickers: they only read `className` of the
 *      chosen element and apply it to <i> icons; an image cannot be used.
 *    - Binary image fields (data-oe-type="image"): external URLs don't belong
 *      in binary fields; product images are handled by media_picker.
 *    - Video background dialog here: it is handled separately by
 *      builder/background_video_dialog_patch.js (Videos + AList, videos only).
 *
 * 3) renderMedia: strip image-only classes forced onto AList <video> nodes
 *    (19.0.3.0.1 behaviour, browser-verified).
 */

// ---- Compatibility guard (stage 4) -------------------------------------
// We patch private Odoo methods. If a future Odoo build renames/removes them,
// skip the patch (native behaviour kept) and report it instead of crashing
// the editor. Testers: check __websiteAlistMedia.compat in the console.
const compat = {
    mediaDialogAddTabs: typeof MediaDialog?.prototype?.addTabs === "function",
    mediaDialogAddTab: typeof MediaDialog?.prototype?.addTab === "function",
    mediaDialogRenderMedia: typeof MediaDialog?.prototype?.renderMedia === "function",
    iconOpenDialog: typeof IconPlugin?.prototype?.openIconDialog === "function",
    iconOnSave: typeof IconPlugin?.prototype?.onSaveIcon === "function",
};
const dialogPatchOk = compat.mediaDialogAddTabs && compat.mediaDialogAddTab;
const iconPatchOk = compat.iconOpenDialog && compat.iconOnSave;
if (!dialogPatchOk || !iconPatchOk) {
    console.warn(
        "[website_alist_media] Odoo internals changed; some AList entry points are disabled.",
        compat
    );
}

if (dialogPatchOk && !MediaDialog.__websiteAlistMediaPatched) {
    MediaDialog.__websiteAlistMediaPatched = true;

    patch(MediaDialog.prototype, {
        addTabs() {
            super.addTabs(...arguments);
            const existingIds = this.notebookPages.map((page) => page.id);
            if (!shouldAppendAListTab(this.props, existingIds)) {
                return;
            }
            const tab = findAListTab(this.props.extraTabs);
            this.addTab(tab, {
                alistOnlyImages: true,
                multiSelect: this.props.multiImages,
            });
        },
    });
}

if (compat.mediaDialogRenderMedia && !MediaDialog.__websiteAlistMediaRenderPatched) {
    MediaDialog.__websiteAlistMediaRenderPatched = true;

    patch(MediaDialog.prototype, {
        async renderMedia(selectedMedia) {
            const elements = await super.renderMedia(...arguments);
            return sanitizeAListVideoElements(elements);
        },
    });
}

if (iconPatchOk && !IconPlugin.__websiteAlistMediaPatched) {
    IconPlugin.__websiteAlistMediaPatched = true;

    patch(IconPlugin.prototype, {
        openIconDialog() {
            const alistTab =
                typeof this.getResource === "function"
                    ? findAListTab(this.getResource("media_dialog_extra_tabs"))
                    : null;
            if (!alistTab || typeof this.getTargetedIcon !== "function") {
                // AList plugin not active in this editor: keep native behaviour.
                return super.openIconDialog(...arguments);
            }
            const selectedIcon = this.getTargetedIcon();
            if (!selectedIcon) {
                return;
            }
            this.dependencies.dialog.addDialog(MediaDialog, {
                visibleTabs: ["ICONS", ALIST_TAB_ID],
                extraTabs: [{ ...alistTab, props: { ...(alistTab.props || {}), alistOnlyImages: true } }],
                media: selectedIcon,
                save: (el) => this.onSaveIcon(el, selectedIcon),
            });
        },

        onSaveIcon(icon, prevIcon) {
            // Native onSaveIcon copies attributes onto the old <i>; that only works
            // icon -> icon. When an AList image was chosen, swap the element.
            if (icon && prevIcon && icon.tagName !== prevIcon.tagName) {
                prevIcon.replaceWith(icon);
                this.dependencies.history.addStep();
                return;
            }
            return super.onSaveIcon(...arguments);
        },
    });
}

// Diagnostic marker for testers (browser console: __websiteAlistMedia)
globalThis.__websiteAlistMedia = {
    ...(globalThis.__websiteAlistMedia || {}),
    version: "19.0.4.2.0",
    renderPatch: compat.mediaDialogRenderMedia,
    dialogPatch: dialogPatchOk,
    iconPatch: iconPatchOk,
    compat,
};
