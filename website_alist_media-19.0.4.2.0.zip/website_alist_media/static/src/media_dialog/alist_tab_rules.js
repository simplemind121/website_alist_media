/** @odoo-module **/

/**
 * Pure decision rules for where the AList tab may appear.
 * No Odoo imports on purpose, so the logic can be unit-tested outside Odoo.
 *
 * Verified against odoo/odoo 19.0:
 *   html_editor/static/src/main/media/media_dialog/media_dialog.js  (addTabs)
 *   html_editor/static/src/main/media/icon_plugin.js                (openIconDialog)
 */

export const ALIST_TAB_ID = "ALIST";

/**
 * True when the media node sits inside a binary image *field*
 * (data-oe-field / data-oe-type = "image"). MediaDialog auto-enables
 * "only images" for these. We never offer AList there: such fields store
 * binary data, an external URL would be downloaded into the filestore or
 * rejected, and product images are media_picker's job.
 */
export function isInsideImageField(media) {
    const parent = media && media.parentElement;
    if (!parent || !parent.dataset) {
        return false;
    }
    return parent.dataset.oeField === "image" || parent.dataset.oeType === "image";
}

/**
 * Decide whether the MediaDialog patch must append the AList tab after the
 * native addTabs() ran.
 *
 * @param {Object} props           MediaDialog props
 * @param {string[]} existingTabIds tab ids already added by native addTabs()
 * @returns {boolean}
 */
export function shouldAppendAListTab(props, existingTabIds) {
    if (!props) {
        return false;
    }
    if (existingTabIds.includes(ALIST_TAB_ID)) {
        return false; // native path already added it
    }
    if (props.noImages) {
        return false;
    }
    // Only the explicit caller-requested "only images" mode is missing AList
    // (native addTabs returns early before extraTabs). Auto-detected image
    // fields are deliberately excluded.
    if (!props.onlyImages) {
        return false;
    }
    if (isInsideImageField(props.media)) {
        return false;
    }
    if (props.visibleTabs && !props.visibleTabs.includes(ALIST_TAB_ID)) {
        return false; // caller restricted tabs explicitly (e.g. video background)
    }
    const extraTabs = props.extraTabs || [];
    return extraTabs.some((tab) => tab && tab.id === ALIST_TAB_ID);
}

/**
 * Find the AList tab definition in an extraTabs / resource list.
 */
export function findAListTab(tabs) {
    return (tabs || []).find((tab) => tab && tab.id === ALIST_TAB_ID) || null;
}

/**
 * Filter AList listing items. In images-only mode, videos and other files are
 * hidden, folders are kept for navigation.
 */
export function filterItems(items, onlyImages) {
    if (!onlyImages) {
        return items || [];
    }
    return (items || []).filter((item) => item.is_dir || item.media_type === "image");
}

// ---------------------------------------------------------------------------
// Body-video class hygiene (ported verbatim from 19.0.3.0.1, browser-verified).
// Stock MediaDialog.renderMedia always merges the active tab's
// mediaSpecificClasses; AList must keep "img" in that list for its <img>
// inserts, but those image classes must not land on body videos.
// ---------------------------------------------------------------------------

/** Image-only classes that must not remain on AList CDN ``<video>`` nodes. */
export const IMAGE_ONLY_CLASSES = ["img", "o_we_custom_image", "media_iframe_video"];

/**
 * Normalize AList CDN video elements after stock renderMedia class merging.
 * Idempotent; non-AList videos are left untouched.
 * @param {HTMLElement[]} elements
 * @returns {HTMLElement[]}
 */
export function sanitizeAListVideoElements(elements) {
    for (const el of elements || []) {
        if (!el || el.tagName !== "VIDEO") {
            continue;
        }
        const looksAList =
            el.classList.contains("o_alist_cdn_video") ||
            el.dataset?.alistExternal === "1";
        if (!looksAList) {
            // Leave stock / non-AList videos alone if any appear.
            continue;
        }
        el.classList.remove(...IMAGE_ONLY_CLASSES);
        el.classList.add("o_alist_cdn_video", "img-fluid");
        if (!el.hasAttribute("controls")) {
            el.setAttribute("controls", "controls");
        }
        if (!el.hasAttribute("playsinline")) {
            el.setAttribute("playsinline", "playsinline");
        }
        el.dataset.alistExternal = "1";
    }
    return elements;
}

/**
 * Sanitize every AList video below ``root`` (editor normalize / save hooks).
 * Accepts an element or a ``{ root }`` payload so it works with either
 * handler signature.
 */
export function sanitizeAListVideosIn(rootOrPayload) {
    const root =
        rootOrPayload && rootOrPayload.querySelectorAll
            ? rootOrPayload
            : rootOrPayload && rootOrPayload.root;
    if (!root || typeof root.querySelectorAll !== "function") {
        return;
    }
    const nodes = [...root.querySelectorAll("video.o_alist_cdn_video, video[data-alist-external='1']")];
    if (root.tagName === "VIDEO") {
        nodes.push(root);
    }
    sanitizeAListVideoElements(nodes);
}

// ---------------------------------------------------------------------------
// 19.0.4.2.0 — poster matching + non-playable container hints (pure helpers)
// ---------------------------------------------------------------------------

/** Containers browsers cannot play natively (mirrors cdn_utils.NON_WEB_VIDEO_EXT). */
export const NON_WEB_VIDEO_EXTENSIONS = [
    ".mkv", ".avi", ".wmv", ".flv", ".rmvb", ".rm", ".3gp", ".mpg", ".mpeg", ".ts",
];

/** File name without its extension, lowercased. */
export function baseName(name) {
    return String(name || "").replace(/\.[a-z0-9]+$/i, "").toLowerCase();
}

/**
 * A video in one of these containers is listed (the source may have opted in)
 * but will not play in a browser. The tab warns instead of silently inserting
 * a dead player.
 */
export function isLikelyUnplayable(name) {
    const lower = String(name || "").toLowerCase();
    return NON_WEB_VIDEO_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

/**
 * Find a poster image for `videoItem` among the items of the same folder:
 * an image with the same base name (demo.mp4 -> demo.jpg / demo-poster.png).
 * Returns the matching item or null. Never picks a folder or a video.
 */
export function findPosterItem(items, videoItem) {
    const base = baseName(videoItem && videoItem.name);
    if (!base) {
        return null;
    }
    const candidates = (items || []).filter(
        (it) => it && !it.is_dir && it.media_type === "image" && it.ref !== (videoItem || {}).ref
    );
    return (
        candidates.find((it) => baseName(it.name) === base) ||
        candidates.find((it) => baseName(it.name) === `${base}-poster`) ||
        null
    );
}
