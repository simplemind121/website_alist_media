/** @odoo-module **/

/**
 * Module-only patch: section Background Video MediaDialog.
 *
 * Stock ``WebsiteBackgroundVideoPlugin.loadReplaceBackgroundVideo`` (Odoo 19
 * ``website/.../background_option_plugin.js``):
 *   - passes ``visibleTabs: ["VIDEO_BACKGROUND"]`` → AList never appears
 *   - passes its own ``extraTabs: [VIDEO_BACKGROUND]`` which *replaces*
 *     ``media_dialog_extra_tabs`` from resources (so AList from AListMediaPlugin
 *     is dropped even without visibleTabs)
 *   - save does ``media.querySelector("iframe").src`` → crashes / empty for
 *     AList ``<video src=CDN>``
 *
 * We patch the registered plugin class prototype (class is not exported) to:
 *   1. merge ALIST into extraTabs + visibleTabs
 *   2. extract CDN URL from video / iframe / wrappers
 */

import { _t } from "@web/core/l10n/translation";
import { registry } from "@web/core/registry";
import { patch } from "@web/core/utils/patch";
import { VideoSelector } from "@html_editor/main/media/media_dialog/video_selector";
import { AListSelector } from "@website_alist_media/media_dialog/alist_selector";
import {
    extractBackgroundVideoSrc,
    mergeExtraTabsWithAList,
    mergeVisibleTabs,
} from "@website_alist_media/utils/bg_video_utils";

/** Same Vimeo sample ids as stock WebsiteBackgroundVideoPlugin. */
const BG_VIMEO_PREVIEW_IDS = [
    "528686125",
    "430330731",
    "509869821",
    "397142251",
    "763851966",
    "486931161",
    "1092009120",
    "728584384",
    "865314310",
    "511727912",
    "466830211",
];

function buildVideoBackgroundTab() {
    return {
        id: "VIDEO_BACKGROUND",
        title: _t("Videos"),
        Component: VideoSelector,
        props: {
            isForBgVideo: true,
            vimeoPreviewIds: BG_VIMEO_PREVIEW_IDS,
        },
    };
}

function buildAListBgTab() {
    return {
        id: "ALIST",
        title: _t("AList"),
        Component: AListSelector,
        sequence: 40,
        props: {
            // BG picker should list CDN videos (dirs + video files only)
            videosOnly: true,
            isForBgVideo: true,
        },
    };
}

const websitePlugins = registry.category("website-plugins");
const STOCK_PLUGIN_ID = "websiteBackgroundVideoPlugin";

/**
 * The stock plugin is registered by website's own asset file. Asset order puts
 * it before this module today, but relying on that makes the AList background
 * video tab disappear silently if the order ever changes. So: patch now when it
 * is already there, otherwise patch as soon as it is registered.
 */
function patchBackgroundVideoPlugin(PluginClass) {
    if (!PluginClass || PluginClass.__websiteAlistMediaPatched) {
        return;
    }
    PluginClass.__websiteAlistMediaPatched = true;
    applyPatch(PluginClass);
    globalThis.__websiteAlistMedia = {
        ...(globalThis.__websiteAlistMedia || {}),
        bgVideoPatch: true,
    };
}

function applyPatch(WebsiteBackgroundVideoPlugin) {
    patch(WebsiteBackgroundVideoPlugin.prototype, {
        /**
         * Open MediaDialog with Videos + AList; resolve CDN or embed URL.
         * @override
         */
        loadReplaceBackgroundVideo() {
            return new Promise((resolve) => {
                const extraTabs = mergeExtraTabsWithAList(
                    [buildVideoBackgroundTab()],
                    buildAListBgTab()
                );
                const visibleTabs = mergeVisibleTabs(["VIDEO_BACKGROUND"], ["ALIST"]);
                const onClose = this.dependencies.media.openMediaDialog({
                    extraTabs,
                    visibleTabs,
                    save: (media) => {
                        resolve(extractBackgroundVideoSrc(media));
                    },
                });
                // User dismissed without picking → resolve undefined (stock behavior)
                onClose.then(resolve);
            });
        },
    });
}

if (websitePlugins.contains(STOCK_PLUGIN_ID)) {
    patchBackgroundVideoPlugin(websitePlugins.get(STOCK_PLUGIN_ID));
} else {
    // Registered later in this bundle (or a future asset reorder): wait for it.
    globalThis.__websiteAlistMedia = {
        ...(globalThis.__websiteAlistMedia || {}),
        bgVideoPatch: "pending",
    };
    websitePlugins.addEventListener("UPDATE", (ev) => {
        const { operation, key, value } = ev.detail || {};
        if (operation === "add" && key === STOCK_PLUGIN_ID) {
            patchBackgroundVideoPlugin(value);
        }
    });
}
