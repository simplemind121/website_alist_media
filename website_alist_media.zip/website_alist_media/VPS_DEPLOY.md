# website_alist_media — VPS 部署

请使用配套脚本，不要再手工解压/执行 odoo 命令：

```bash
# 两个文件放同一目录（脚本 + website_alist_media.zip）
sudo bash deploy_website_alist_media.sh --target staging   # 先 staging
sudo bash deploy_website_alist_media.sh                    # 再生产 prod-odoo
sudo bash deploy_website_alist_media.sh --rollback         # 回滚（数据库+模块目录）
```

脚本会：从容器挂载识别 addons/配置 → 校验包内版本与关键文件 → 拒绝降级 →
在包上跑离线单元测试 → 检查 Odoo 内部代码锚点 → 备份数据库与旧模块 →
自动选择 -i / -u → 核对数据库版本 → 重启并等待健康检查 → 扫描启动日志。

部署后浏览器 Ctrl+Shift+R 强刷，再按 `TEST_PLAN.md` 第 0 节验收。
