/** @odoo-module **/

/**
 * Module-only patch: play direct CDN mp4/webm as ``<video autoplay muted loop
 * playsinline>`` while keeping stock iframe path for YouTube / Vimeo embeds.
 *
 * Stock ``BackgroundVideo.appendBgVideo`` always renders
 * ``website.background.video`` (iframe). data-bg-video-src from AList is a
 * bare CDN file URL — iframes cannot play that reliably.
 */

import { patch } from "@web/core/utils/patch";
import { BackgroundVideo } from "@website/interactions/video/background_video";
import { isDirectMediaVideoUrl } from "@website_alist_media/utils/bg_video_utils";

patch(BackgroundVideo.prototype, {
    /**
     * @override
     */
    appendBgVideo() {
        if (isDirectMediaVideoUrl(this.videoSrc)) {
            this._appendDirectBgVideo();
            return;
        }
        return super.appendBgVideo(...arguments);
    },

    /**
     * Render native HTML5 video for CDN / direct media URLs.
     * Reuses ``.o_bg_video_iframe`` class so stock ``adjustIframe`` sizing works.
     */
    _appendDirectBgVideo() {
        const oldContainer =
            this.bgVideoContainer || this.el.querySelector(":scope > .o_bg_video_container");
        oldContainer?.remove();

        this.renderAt(
            "website_alist_media.background.video.direct",
            {
                videoSrc: this.videoSrc,
                iframeID: this.iframeID,
            },
            this.el,
            "afterbegin"
        );

        this.bgVideoContainer = this.el.querySelector(":scope > .o_bg_video_container");
        this.iframeEl = this.bgVideoContainer.querySelector(".o_bg_video_iframe");

        const onReady = () => {
            this.bgVideoContainer.querySelector(".o_bg_video_loading")?.remove();
            this.adjustIframe();
            // Autoplay: muted+playsinline already set; nudge play() for stubborn browsers
            if (this.iframeEl && typeof this.iframeEl.play === "function") {
                this.iframeEl.play().catch(() => {});
            }
        };

        this.addListener(this.iframeEl, "loadeddata", onReady, { once: true });
        // Some CDNs fire canplay before loadeddata; also handle already-cached
        if (this.iframeEl && this.iframeEl.readyState >= 2) {
            onReady();
        } else {
            this.adjustIframe();
        }
    },
});
