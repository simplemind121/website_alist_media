/** @odoo-module **/

/**
 * Helpers for AList CDN background / body video (module-only; no Odoo core edits).
 * Mirrored by tests/test_bg_video_utils.py for unit coverage.
 */

/** Common direct-file extensions treated as native HTML5 video. */
export const DIRECT_VIDEO_EXTENSIONS = [
    ".mp4",
    ".webm",
    ".ogg",
    ".ogv",
    ".mov",
    ".m4v",
    ".mkv",
    ".avi",
];

const EMBED_HOST_RE =
    /(youtube\.com|youtu\.be|youtube-nocookie\.com|vimeo\.com|player\.vimeo\.com|dailymotion\.com|instagram\.com)/i;

/**
 * Path-only extension of a URL (query/hash stripped).
 * @param {string} src
 * @returns {string}
 */
export function urlPathLower(src) {
    if (!src || typeof src !== "string") {
        return "";
    }
    try {
        const noHash = src.split("#")[0];
        const path = noHash.split("?")[0];
        return path.toLowerCase();
    } catch {
        return String(src).toLowerCase();
    }
}

/**
 * True when src looks like a direct media file (CDN mp4/webm/…) rather than
 * a YouTube/Vimeo/Dailymotion embed URL.
 * @param {string} src
 * @returns {boolean}
 */
export function isDirectMediaVideoUrl(src) {
    if (!src || typeof src !== "string") {
        return false;
    }
    const trimmed = src.trim();
    if (!trimmed || trimmed === "about:blank") {
        return false;
    }
    if (EMBED_HOST_RE.test(trimmed)) {
        return false;
    }
    const path = urlPathLower(trimmed);
    return DIRECT_VIDEO_EXTENSIONS.some((ext) => path.endsWith(ext));
}

/**
 * Extract a background-video src string from a MediaDialog save payload
 * (DOM element produced by VideoSelector or AListSelector.createElements).
 *
 * Stock Odoo only did ``media.querySelector("iframe").src`` — that breaks
 * for AList ``<video src=CDN>``.
 *
 * @param {HTMLElement|null|undefined} media
 * @returns {string}
 */
export function extractBackgroundVideoSrc(media) {
    if (!media) {
        return "";
    }
    if (media.tagName === "VIDEO") {
        return media.getAttribute("src") || media.src || "";
    }
    if (media.tagName === "IFRAME") {
        return media.getAttribute("src") || media.src || "";
    }
    const iframe = media.querySelector?.("iframe");
    if (iframe) {
        return iframe.getAttribute("src") || iframe.src || "";
    }
    const video = media.querySelector?.("video");
    if (video) {
        return video.getAttribute("src") || video.src || "";
    }
    // Fallback: data attributes used by stock iframe-video wrappers
    if (media.dataset?.oeExpression) {
        return media.dataset.oeExpression;
    }
    if (media.dataset?.src) {
        return media.dataset.src;
    }
    return "";
}

/**
 * Merge visibleTabs so AList appears alongside VIDEO_BACKGROUND (and any
 * other ids the caller already requested).
 * @param {string[]|undefined|null} visibleTabs
 * @param {string[]} extraIds
 * @returns {string[]}
 */
export function mergeVisibleTabs(visibleTabs, extraIds = ["ALIST"]) {
    const base = Array.isArray(visibleTabs) ? [...visibleTabs] : [];
    for (const id of extraIds) {
        if (id && !base.includes(id)) {
            base.push(id);
        }
    }
    return base;
}

/**
 * Ensure an AList tab descriptor is present in extraTabs (by id).
 * Does not mutate the input array.
 * @param {Array<{id: string}>|undefined|null} extraTabs
 * @param {{id: string, title: string, Component: *, sequence?: number, props?: object}} alistTab
 * @returns {Array}
 */
export function mergeExtraTabsWithAList(extraTabs, alistTab) {
    const tabs = Array.isArray(extraTabs) ? [...extraTabs] : [];
    if (!alistTab || !alistTab.id) {
        return tabs;
    }
    if (tabs.some((t) => t && t.id === alistTab.id)) {
        return tabs;
    }
    tabs.push(alistTab);
    return tabs;
}
