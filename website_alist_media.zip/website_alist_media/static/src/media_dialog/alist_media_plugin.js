/** @odoo-module **/

import { Plugin } from "@html_editor/plugin";
import { _t } from "@web/core/l10n/translation";
import { registry } from "@web/core/registry";
import { MAIN_PLUGINS } from "@html_editor/plugin_sets";
import { AListSelector } from "./alist_selector";
import { sanitizeAListVideosIn } from "./alist_tab_rules";

/**
 * Odoo 19 html_editor Plugin that registers the AList MediaDialog tab via
 * the official ``media_dialog_extra_tabs`` resource (same pattern as VideoPlugin /
 * FilePlugin in odoo/odoo 19.0).
 *
 * @see addons/html_editor/static/src/main/media/video_plugin.js
 * @see addons/html_editor/static/src/main/media/media_plugin.js
 */
export class AListMediaPlugin extends Plugin {
    static id = "alist_media";

    /** @type {import("plugins").EditorResources} */
    resources = {
        media_dialog_extra_tabs: {
            id: "ALIST",
            title: _t("AList"),
            Component: this.componentForMediaDialog,
            sequence: 40,
        },
        // Defence in depth for body videos: the "Replace" flow can re-apply the
        // old <img>'s classes after renderMedia. Re-sanitize AList <video>s on
        // normalize and before save. Idempotent; unknown resource names are
        // simply ignored by the editor, so this cannot break older builds.
        normalize_handlers: (root) => sanitizeAListVideosIn(root),
        clean_for_save_handlers: (payload) => sanitizeAListVideosIn(payload),
    };

    get componentForMediaDialog() {
        return AListSelector;
    }
}

// Backend / HTML fields: ensure plugin is in MAIN_PLUGINS
if (!MAIN_PLUGINS.includes(AListMediaPlugin)) {
    MAIN_PLUGINS.push(AListMediaPlugin);
}

// Website builder: registry.category("website-plugins")
// Guarded: the file is listed in two asset bundles; never add the key twice.
// (Duplicate classes in the plugin list are harmless — the editor dedupes them
// with a Set in sortPlugins — but a duplicate registry key would throw.)
const websitePlugins = registry.category("website-plugins");
if (!websitePlugins.contains(AListMediaPlugin.id)) {
    websitePlugins.add(AListMediaPlugin.id, AListMediaPlugin);
}

globalThis.__websiteAlistMedia = {
    ...(globalThis.__websiteAlistMedia || {}),
    pluginRegistered: true,
};
