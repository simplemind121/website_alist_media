# -*- coding: utf-8 -*-
"""Reference index + link health check for AList/CDN URLs (19.0.4.0.0).

- scan: finds every CDN/AList URL used in website content and records where
  (model / record / field). Answers "is this file still used anywhere?"
  before deleting it in AList.
- check: HEAD (fallback ranged GET) each indexed URL, flags broken ones
  (file deleted/moved in AList, CDN misconfigured).

Read-only towards content: never modifies the scanned records.
"""
import logging

import requests

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from .cdn_utils import host_from_url, is_host_allowed
from .media_utils import extract_urls_for_hosts

_logger = logging.getLogger(__name__)

CHECK_TIMEOUT = 5
DEFAULT_CHECK_BATCH = 200
MAX_ROWS_PER_TARGET = 20000

# (model, field). Skipped automatically when the model/field is absent.
SCAN_TARGETS = (
    ('ir.ui.view', 'arch_db'),
    ('blog.post', 'content'),
    ('website.page', 'arch_db'),
    ('product.template', 'website_description'),
    ('product.public.category', 'website_description'),
    ('event.event', 'description'),
    ('slide.channel', 'description'),
    ('hr.job', 'description'),
)


class WebsiteAlistMediaLink(models.Model):
    _name = 'website.alist.media.link'
    _description = 'AList Media URL usage & health'
    _order = 'status_sequence, ref_count desc, url'
    _rec_name = 'url'

    url = fields.Char(required=True, index=True, readonly=True)
    source_id = fields.Many2one('website.alist.media.source', ondelete='cascade', readonly=True)
    ref_ids = fields.One2many('website.alist.media.link.ref', 'link_id', string='Used in', readonly=True)
    ref_count = fields.Integer(readonly=True)
    status = fields.Selection([
        ('unchecked', 'Not checked'),
        ('ok', 'OK'),
        ('broken', 'Broken (4xx)'),
        ('error', 'Error (5xx / network)'),
    ], default='unchecked', readonly=True, index=True)
    status_sequence = fields.Integer(compute='_compute_status_sequence', store=True)
    http_code = fields.Integer(readonly=True)
    last_checked = fields.Datetime(readonly=True)
    last_message = fields.Char(readonly=True)

    _url_unique = models.Constraint('UNIQUE(url)', 'URL must be unique.')

    @api.depends('status')
    def _compute_status_sequence(self):
        order = {'broken': 0, 'error': 1, 'unchecked': 2, 'ok': 3}
        for rec in self:
            rec.status_sequence = order.get(rec.status, 9)

    def _check_editor_access(self):
        if not (self.env.su or self.env.user.has_group('website.group_website_designer')):
            raise UserError(_('Only website designers can run the media link scan/check.'))

    # ------------------------------------------------------------------ scan
    @api.model
    def _source_hosts(self):
        """{host: source} for CDN/base hosts of active sources."""
        mapping = {}
        for source in self.env['website.alist.media.source'].sudo().search([]):
            for url in (source.cdn_base_url, source.base_url):
                host = host_from_url(url or '')
                if host and host not in mapping:
                    mapping[host] = source
        return mapping

    @api.model
    def _iter_target_rows(self, model_name, field_name, hosts):
        """Yield (res_id, text) rows containing any host. Raw SQL on the column
        (cast to text) so translated jsonb fields are covered in all languages."""
        if model_name not in self.env:
            return
        Model = self.env[model_name]
        field = Model._fields.get(field_name)
        if not field or not field.store or not field.column_type:
            return
        table, column = Model._table, field.name
        clauses = ' OR '.join([f'"{column}"::text ILIKE %s'] * len(hosts))
        params = [f'%{h}%' for h in hosts]
        query = f'SELECT id, "{column}"::text FROM "{table}" WHERE {clauses} LIMIT {MAX_ROWS_PER_TARGET}'
        self.env.cr.execute(query, params)
        yield from self.env.cr.fetchall()

    @api.model
    def action_scan_references(self):
        """Rebuild the reference index. Safe to run anytime (read-only on content)."""
        self._check_editor_access()
        host_map = self._source_hosts()
        if not host_map:
            return self._notify(_('No media source with a CDN/base URL configured.'))
        hosts = set(host_map)
        found = {}  # url -> set((model, res_id, field))
        for model_name, field_name in SCAN_TARGETS:
            for res_id, text in self._iter_target_rows(model_name, field_name, hosts):
                for url in extract_urls_for_hosts(text, hosts):
                    found.setdefault(url, set()).add((model_name, res_id, field_name))

        Ref = self.env['website.alist.media.link.ref'].sudo()
        Link = self.sudo()
        existing = {link.url: link for link in Link.search([])}
        Ref.search([]).unlink()
        for url, refs in found.items():
            link = existing.pop(url, None)
            source = host_map.get(host_from_url(url))
            if not link:
                link = Link.create({'url': url, 'source_id': source.id if source else False})
            Ref.create([{
                'link_id': link.id, 'res_model': m, 'res_id': rid, 'res_field': f,
            } for (m, rid, f) in refs])
            link.ref_count = len(refs)
        # URLs no longer referenced anywhere: keep the row (history) with count 0
        for link in existing.values():
            link.ref_count = 0
        _logger.info('website_alist_media: indexed %s URLs', len(found))
        return self._notify(_('%s CDN/AList URLs indexed.') % len(found))

    # ----------------------------------------------------------------- check
    @api.model
    def _check_one(self, url, source):
        """Return (status, http_code, message). Only allowlisted hosts are requested."""
        if source:
            host = host_from_url(url)
            if not is_host_allowed(host, source._allowed_hosts()):
                return 'error', 0, 'Host not allowlisted (skipped)'
        try:
            resp = requests.head(url, timeout=CHECK_TIMEOUT, allow_redirects=True)
            if resp.status_code in (403, 405, 501):
                # some CDNs refuse HEAD
                resp = requests.get(url, timeout=CHECK_TIMEOUT, allow_redirects=True,
                                    stream=True, headers={'Range': 'bytes=0-0'})
                resp.close()
        except requests.exceptions.RequestException as exc:
            return 'error', 0, exc.__class__.__name__
        code = resp.status_code
        if code < 400:
            return 'ok', code, ''
        if code < 500:
            return 'broken', code, f'HTTP {code}'
        return 'error', code, f'HTTP {code}'

    def action_check_links(self):
        self._check_editor_access()
        links = self or self.sudo().search([], order='last_checked asc nulls first, id',
                                           limit=DEFAULT_CHECK_BATCH)
        now = fields.Datetime.now()
        for link in links.sudo():
            status, code, message = self._check_one(link.url, link.source_id)
            link.write({'status': status, 'http_code': code,
                        'last_message': message, 'last_checked': now})
        broken = len(links.filtered(lambda l: l.status in ('broken', 'error')))
        return self._notify(_('%(n)s links checked, %(b)s problems.') % {'n': len(links), 'b': broken})

    # ------------------------------------------------------------------ cron
    @api.model
    def _cron_scan_and_check(self):
        silent = self.with_context(website_alist_silent=True)
        silent.action_scan_references()
        silent.browse().action_check_links()

    @api.model
    def _notify(self, message):
        if self.env.context.get('website_alist_silent'):
            return True
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {'message': message, 'type': 'info', 'sticky': False,
                       'next': {'type': 'ir.actions.act_window_close'}},
        }


class WebsiteAlistMediaLinkRef(models.Model):
    _name = 'website.alist.media.link.ref'
    _description = 'AList Media URL reference'
    _order = 'res_model, res_id'

    link_id = fields.Many2one('website.alist.media.link', required=True, ondelete='cascade', index=True)
    res_model = fields.Char(required=True, readonly=True)
    res_id = fields.Integer(required=True, readonly=True)
    res_field = fields.Char(readonly=True)
    display_name_ref = fields.Char(string='Record', compute='_compute_display_name_ref')

    def _compute_display_name_ref(self):
        for ref in self:
            label = f'{ref.res_model},{ref.res_id}'
            if ref.res_model in self.env:
                rec = self.env[ref.res_model].sudo().browse(ref.res_id).exists()
                if rec:
                    label = f'{rec._description}: {rec.display_name}'
            ref.display_name_ref = label

    def action_open_record(self):
        self.ensure_one()
        if self.res_model not in self.env:
            raise UserError(_('Model %s is not installed.') % self.res_model)
        return {
            'type': 'ir.actions.act_window',
            'res_model': self.res_model,
            'res_id': self.res_id,
            'view_mode': 'form',
            'target': 'current',
        }
