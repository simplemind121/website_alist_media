# -*- coding: utf-8 -*-
from urllib.parse import urlparse

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from . import alist_client
from . import s3_client
from .cdn_utils import (
    DEFAULT_IMAGE_EXT,
    DEFAULT_VIDEO_EXT,
    collect_allowed_hosts,
    host_from_url,
    is_host_allowed,
    parse_extensions,
)
from .media_utils import (
    ValidationFailure,
    build_srcset,
    build_upload_path,
    parse_widths,
    render_url_template,
    sanitize_upload_filename,
    secret_storage_mode,
)


class WebsiteAlistMediaSource(models.Model):
    """Configured AList / S3 media source for the MediaDialog AList tab.

    Secrets (token / S3 keys) are server-only: never returned by JSON controllers.
    """
    _name = 'website.alist.media.source'
    _description = 'AList / S3 Media Source'
    _order = 'sequence, id'

    name = fields.Char(required=True)
    active = fields.Boolean(default=True)
    sequence = fields.Integer(default=10)
    source_type = fields.Selection([
        ('alist', 'AList'),
        ('s3', 'S3 Compatible (B2/R2/MinIO)'),
    ], required=True, default='alist')

    base_url = fields.Char(
        string='API Base URL',
        help='AList base URL (https://one.example.com) or S3 API endpoint. Server-side only.',
    )
    token = fields.Char(
        groups='website_alist_media.group_website_alist_media_manager,base.group_system',
        string='Token / Access Key',
        help='AList token or S3 access key. Prefer secret_ref for production. Never sent to browser.',
    )
    secret_ref = fields.Char(
        groups='website_alist_media.group_website_alist_media_manager,base.group_system',
        string='Secret Reference (env)',
        help='Environment variable name for the token/access key. '
             'S3 secret key is read from secret_ref+"_SECRET" or ACCESS→SECRET swap.',
    )
    s3_secret_key = fields.Char(
        groups='website_alist_media.group_website_alist_media_manager,base.group_system',
        string='S3 Secret Key',
        help='Optional plaintext secret (prefer env via secret_ref). Server-only.',
    )
    root_path = fields.Char(string='Root Path', default='/')
    cdn_base_url = fields.Char(
        string='CDN / Public Base URL',
        help='Permanent public CDN origin, e.g. https://media.example.com (no trailing slash).',
    )
    cdn_strip_path_prefix = fields.Char(
        string='CDN Strip Path Prefix',
        default='/d',
        help='Path prefix stripped when rewriting AList /d/... URLs onto the CDN (default /d).',
    )
    trusted_domains = fields.Text(
        string='Extra Trusted Domains',
        help='One host per line. Resolved URLs must match configured source/CDN hosts '
             '(or these extras). SSRF protection.',
    )
    image_extensions = fields.Char(
        string='Image Extensions',
        default='.jpg,.jpeg,.png,.webp,.gif,.bmp,.svg',
    )
    video_extensions = fields.Char(
        string='Video Extensions',
        default='.mp4,.webm,.mov,.m4v,.ogv,.ogg',
    )
    page_size = fields.Integer(
        default=60,
        help='Items per page in the MediaDialog AList grid (server clamps 1–200). '
             'New sources default to 60; existing sources keep their stored value.',
    )

    # S3-specific
    s3_endpoint = fields.Char(string='S3 Endpoint')
    s3_bucket = fields.Char(string='S3 Bucket')
    s3_region = fields.Char(string='S3 Region', default='auto')
    s3_prefix = fields.Char(string='S3 Prefix')

    # --- 19.0.4.0.0 -------------------------------------------------------
    search_mode = fields.Selection([
        ('remote', 'AList search index (all sub-folders)'),
        ('local', 'Current folder only'),
    ], default='remote', required=True,
        help='Remote search needs the AList search index enabled; if it fails the '
             'tab automatically falls back to the current folder.')
    thumbnail_url_template = fields.Char(
        string='Thumbnail URL Template',
        help='Optional. Used for grid previews only. Placeholders: {url} {origin} {path} {width}. '
             'Cloudflare example: {origin}/cdn-cgi/image/width={width},format=auto{path}',
    )
    enable_srcset = fields.Boolean(
        string='Responsive images (srcset)',
        help='Add srcset to inserted images. Requires Resize URL Template and a CDN that resizes.',
    )
    resize_url_template = fields.Char(
        string='Resize URL Template',
        help='Used to build srcset. Same placeholders as the thumbnail template.',
    )
    srcset_widths = fields.Char(string='srcset Widths', default='480,960,1600')
    upload_enabled = fields.Boolean(
        string='Allow upload from editor',
        help='Website designers can upload new images/videos into the current AList folder '
             'from the media dialog. Files go to AList/S3, never to the Odoo filestore.',
    )
    upload_max_mb = fields.Integer(string='Max upload size (MB)', default=20)
    secret_storage = fields.Selection([
        ('env', 'Environment variable (recommended)'),
        ('database', 'Stored in database'),
        ('mixed', 'Both (environment wins)'),
        ('none', 'No credentials'),
    ], compute='_compute_secret_storage')
    # ---------------------------------------------------------------------

    state = fields.Selection([
        ('untested', 'Not Tested'),
        ('ok', 'Connected'),
        ('error', 'Error'),
    ], default='untested', readonly=True, copy=False)
    last_test_message = fields.Char(readonly=True, copy=False)
    last_test_date = fields.Datetime(readonly=True, copy=False)

    @api.depends('token', 'secret_ref', 's3_secret_key')
    def _compute_secret_storage(self):
        for rec in self:
            rec.secret_storage = secret_storage_mode(rec.token, rec.secret_ref, rec.s3_secret_key)

    @api.constrains('upload_max_mb')
    def _check_upload_max(self):
        for rec in self:
            if rec.upload_max_mb < 1 or rec.upload_max_mb > 500:
                raise ValidationError(_('Max upload size must be between 1 and 500 MB.'))

    @api.constrains('base_url', 'cdn_base_url', 's3_endpoint')
    def _check_urls(self):
        for rec in self:
            for field_name in ('base_url', 'cdn_base_url', 's3_endpoint'):
                val = rec[field_name]
                if not val:
                    continue
                parsed = urlparse(val if '://' in val else 'https://' + val)
                if parsed.scheme not in ('http', 'https') or not parsed.netloc:
                    raise ValidationError(_('%s must be an absolute http(s) URL.') % field_name)

    def _allowed_hosts(self):
        self.ensure_one()
        return collect_allowed_hosts(
            self.base_url,
            self.cdn_base_url,
            self.s3_endpoint,
            extra_domains_text=self.trusted_domains or '',
        )

    def assert_url_allowed(self, url):
        """Raise if URL host is not in the configured allowlist (SSRF)."""
        self.ensure_one()
        host = host_from_url(url)
        if not is_host_allowed(host, self._allowed_hosts()):
            raise UserError(_(
                'Resolved URL host %(host)s is not allowlisted for source "%(name)s".'
            ) % {'host': host or '(empty)', 'name': self.name})

    def _client_module(self):
        self.ensure_one()
        if self.source_type == 's3':
            return s3_client
        return alist_client

    def action_test_connection(self):
        self.ensure_one()
        client = self._client_module()
        result = client.health(self)
        if result.get('status') == 'ok':
            self.write({
                'state': 'ok',
                'last_test_message': _('Connection successful (%s ms).') % result.get('latency_ms', '?'),
                'last_test_date': fields.Datetime.now(),
            })
        else:
            self.write({
                'state': 'error',
                'last_test_message': result.get('message') or _('Connection failed.'),
                'last_test_date': fields.Datetime.now(),
            })

    def list_media(self, path='/', page=1, per_page=None, query=None):
        self.ensure_one()
        client = self._client_module()
        per_page = per_page or self.page_size or 60
        if query:
            return client.search(self, query, page=page, per_page=per_page, path=path)
        return client.list_dir(self, path=path, page=page, per_page=per_page)

    def resolve_media(self, item_ref):
        self.ensure_one()
        client = self._client_module()
        result = client.resolve(self, item_ref)
        self.assert_url_allowed(result['url'])
        if self.enable_srcset and result.get('media_type') == 'image':
            srcset = build_srcset(
                result['url'], self.resize_url_template or '', parse_widths(self.srcset_widths),
            )
            if srcset:
                result['srcset'] = srcset
                result['sizes'] = '100vw'
        return result

    def _public_capabilities(self):
        """Non-secret settings the browser tab needs."""
        self.ensure_one()
        image_ext = parse_extensions(self.image_extensions, DEFAULT_IMAGE_EXT)
        video_ext = parse_extensions(self.video_extensions, DEFAULT_VIDEO_EXT)
        return {
            'upload_enabled': bool(self.upload_enabled),
            'upload_max_mb': self.upload_max_mb or 20,
            'image_extensions': list(image_ext),
            'video_extensions': list(video_ext),
            'search_mode': self.search_mode or 'remote',
        }

    def upload_media(self, folder, filename, fileobj, content_type, size):
        """Validate then upload to AList/S3. Returns the resolved media dict."""
        self.ensure_one()
        if not self.upload_enabled:
            raise UserError(_('Uploading is disabled for this media source.'))
        max_bytes = (self.upload_max_mb or 20) * 1024 * 1024
        if size is None or size <= 0:
            raise UserError(_('Empty file.'))
        if size > max_bytes:
            raise UserError(_('File is larger than %s MB.') % (self.upload_max_mb or 20))
        allowed = parse_extensions(self.image_extensions, DEFAULT_IMAGE_EXT) + \
            parse_extensions(self.video_extensions, DEFAULT_VIDEO_EXT)
        try:
            safe_name = sanitize_upload_filename(filename, allowed)
            target = build_upload_path(folder, safe_name, self.root_path or '/')
        except ValidationFailure as exc:
            raise UserError(str(exc))
        client = self._client_module()
        client.upload(self, target, fileobj, content_type, size)
        return self.resolve_media(target)
