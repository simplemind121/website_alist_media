# -*- coding: utf-8 -*-
"""Thin AList HTTP client (server-side only). Tokens never leave the worker."""
from __future__ import annotations

import logging
import os
import time

import requests

from urllib.parse import quote

from .media_utils import render_url_template
from .cdn_utils import (
    DEFAULT_IMAGE_EXT,
    DEFAULT_VIDEO_EXT,
    guess_media_type,
    normalize_path,
    parse_extensions,
    rewrite_url_to_cdn,
)

_logger = logging.getLogger(__name__)

REQUEST_TIMEOUT = 5
CACHE_TTL = 20
UPLOAD_TIMEOUT = 120
THUMB_WIDTH = 320
BREAKER_FAILURE_THRESHOLD = 3
BREAKER_COOLDOWN = 30

_breaker_failures = {}
_breaker_open_until = {}
_list_cache = {}


class AlistError(Exception):
    """Safe-to-show connectivity/API error (never includes secrets)."""


def _type_hint(entry):
    """AList type hint for guess_media_type: integer ``type`` or a MIME field."""
    if not isinstance(entry, dict):
        return None
    for key in ('type', 'content_type', 'mime'):
        val = entry.get(key)
        if val not in (None, ''):
            return val
    return None


def _breaker_check(source_id):
    open_until = _breaker_open_until.get(source_id)
    if open_until and time.monotonic() < open_until:
        raise AlistError(
            "This AList connection failed recently and is temporarily disabled. "
            "Please try again in a few seconds."
        )


def _breaker_record_success(source_id):
    _breaker_failures.pop(source_id, None)
    _breaker_open_until.pop(source_id, None)


def _breaker_record_failure(source_id):
    now = time.monotonic()
    failures = [t for t in _breaker_failures.get(source_id, []) if now - t < 60]
    failures.append(now)
    _breaker_failures[source_id] = failures
    if len(failures) >= BREAKER_FAILURE_THRESHOLD:
        _breaker_open_until[source_id] = now + BREAKER_COOLDOWN


def _token_for(source):
    """Env (secret_ref) first, DB field only as fallback (19.0.4: precedence flipped)."""
    ref = (getattr(source, 'secret_ref', None) or '').strip()
    if ref:
        env_val = (os.environ.get(ref) or '').strip()
        if env_val:
            return env_val
    token = (getattr(source, 'token', None) or '').strip()
    return token or None


def _request(source, method, api_path, json_body):
    source_id = source.id or 0
    _breaker_check(source_id)
    base = (source.base_url or '').rstrip('/')
    if not base:
        raise AlistError('AList base_url is not configured.')
    url = base + api_path
    headers = {'Content-Type': 'application/json'}
    token = _token_for(source)
    if token:
        headers['Authorization'] = token
    try:
        resp = requests.request(
            method, url, json=json_body, headers=headers, timeout=REQUEST_TIMEOUT,
        )
    except requests.exceptions.Timeout:
        _breaker_record_failure(source_id)
        raise AlistError(f'Connection to AList timed out after {REQUEST_TIMEOUT}s.')
    except requests.exceptions.RequestException as exc:
        _breaker_record_failure(source_id)
        raise AlistError(f'Could not reach AList: {exc}')
    if resp.status_code != 200:
        _breaker_record_failure(source_id)
        raise AlistError(f'AList returned HTTP {resp.status_code}.')
    try:
        payload = resp.json()
    except ValueError:
        _breaker_record_failure(source_id)
        raise AlistError('AList returned an unexpected (non-JSON) response.')
    if payload.get('code') != 200:
        _breaker_record_failure(source_id)
        raise AlistError(payload.get('message') or 'AList API error.')
    _breaker_record_success(source_id)
    return payload.get('data') or {}


def _maybe_cdn(source, url):
    if not url or not getattr(source, 'cdn_base_url', None):
        return url
    return rewrite_url_to_cdn(
        url,
        source.cdn_base_url,
        getattr(source, 'cdn_strip_path_prefix', None) or '/d',
    )


def _exts(source):
    return (
        parse_extensions(getattr(source, 'image_extensions', None), DEFAULT_IMAGE_EXT),
        parse_extensions(getattr(source, 'video_extensions', None), DEFAULT_VIDEO_EXT),
    )


def list_dir(source, path='/', page=1, per_page=30, use_cache=True):
    root = source.root_path or '/'
    path = normalize_path(path, root)
    page = max(1, int(page or 1))
    per_page = max(1, min(int(per_page or source.page_size or 60), 200))
    source_id = source.id or 0
    cache_key = (source_id, path, page, per_page)
    if use_cache:
        cached = _list_cache.get(cache_key)
        if cached and time.monotonic() - cached[0] < CACHE_TTL:
            return cached[1]

    data = _request(source, 'POST', '/api/fs/list', {
        'path': path,
        'page': page,
        'per_page': per_page,
        'refresh': False,
    })
    image_ext, video_ext = _exts(source)
    items = []
    for entry in data.get('content') or []:
        name = entry.get('name') or ''
        is_dir = bool(entry.get('is_dir'))
        full = path.rstrip('/') + '/' + name if path != '/' else '/' + name
        media_type = 'unknown' if is_dir else guess_media_type(
            name, image_ext, video_ext, content_type=_type_hint(entry),
        )
        sign = entry.get('sign')
        if sign is not None:
            sign = str(sign)
        thumb = entry.get('thumb') or entry.get('thumbnail')
        preview = None
        if isinstance(thumb, str) and thumb.startswith(('http://', 'https://')):
            preview = _maybe_cdn(source, thumb)
        elif media_type == 'image':
            base = (source.base_url or '').rstrip('/')
            q = f'?sign={sign}' if sign else ''
            preview = _maybe_cdn(source, f'{base}/d{full}{q}') if base else None
        if preview and media_type == 'image':
            preview = render_url_template(
                getattr(source, 'thumbnail_url_template', None) or '', preview, THUMB_WIDTH,
            )
        items.append({
            'ref': full,
            'name': name,
            'is_dir': is_dir,
            'media_type': media_type,
            'size': entry.get('size'),
            'preview_url': preview,
            'sign': sign,
        })
    result = {
        'items': items,
        'total': int(data.get('total') or len(items)),
        'page': page,
        'per_page': per_page,
        'path': path,
    }
    _list_cache[cache_key] = (time.monotonic(), result)
    return result


def _local_search(source, query, path, page, per_page):
    """Fallback: filename filter over the current folder (first 200 entries)."""
    listed = list_dir(source, path=path, page=1, per_page=200)
    q = (query or '').strip().lower()
    filtered = [i for i in listed['items'] if q in (i.get('name') or '').lower()]
    start = (page - 1) * per_page
    return {
        'items': filtered[start:start + per_page],
        'total': len(filtered),
        'page': page,
        'per_page': per_page,
        'path': listed.get('path'),
        'search_mode': 'local',
    }


def search(source, query, page=1, per_page=30, path=None):
    """Search inside ``path`` (default root) and all sub-folders.

    Uses AList /api/fs/search (needs the AList search index). When the index is
    disabled or the call fails, falls back to filtering the current folder and
    reports search_mode='local' so the UI can say so.
    """
    query = (query or '').strip()
    root = source.root_path or '/'
    path = normalize_path(path or root, root)
    page = max(1, int(page or 1))
    per_page = max(1, min(int(per_page or 60), 200))
    if not query:
        return list_dir(source, path=path, page=page, per_page=per_page)
    if (getattr(source, 'search_mode', None) or 'remote') == 'local':
        return _local_search(source, query, path, page, per_page)
    try:
        data = _request(source, 'POST', '/api/fs/search', {
            'parent': path,
            'keywords': query,
            'scope': 0,
            'page': page,
            'per_page': per_page,
            'password': '',
        })
    except AlistError as exc:
        _logger.info('AList search unavailable, falling back to local filter: %s', exc)
        return _local_search(source, query, path, page, per_page)

    image_ext, video_ext = _exts(source)
    root_norm = normalize_path(root, '/')
    items = []
    for entry in data.get('content') or []:
        parent = entry.get('parent') or '/'
        name = entry.get('name') or ''
        full = normalize_path(parent.rstrip('/') + '/' + name, '/')
        # never expose results outside the configured root
        if root_norm != '/' and not (full == root_norm or full.startswith(root_norm + '/')):
            continue
        is_dir = bool(entry.get('is_dir'))
        media_type = 'unknown' if is_dir else guess_media_type(
            name, image_ext, video_ext, content_type=_type_hint(entry),
        )
        preview = None
        if media_type == 'image':
            base = (source.base_url or '').rstrip('/')
            preview = _maybe_cdn(source, f'{base}/d{full}') if base else None
            if preview:
                preview = render_url_template(
                    getattr(source, 'thumbnail_url_template', None) or '', preview, THUMB_WIDTH,
                )
        items.append({
            'ref': full,
            'name': name,
            'is_dir': is_dir,
            'media_type': media_type,
            'size': entry.get('size'),
            'preview_url': preview,
            'sign': None,
            'parent': parent,
        })
    return {
        'items': items,
        'total': int(data.get('total') or len(items)),
        'page': page,
        'per_page': per_page,
        'path': path,
        'search_mode': 'remote',
    }


def resolve(source, item_ref):
    root = source.root_path or '/'
    path = normalize_path(item_ref, root)
    data = _request(source, 'POST', '/api/fs/get', {'path': path})
    raw_url = data.get('raw_url') or data.get('url')
    if not raw_url:
        raise AlistError('AList did not return a raw_url for this file.')
    raw_url = _maybe_cdn(source, raw_url)
    name = data.get('name') or os.path.basename(path)
    image_ext, video_ext = _exts(source)
    media_type = guess_media_type(name, image_ext, video_ext, content_type=_type_hint(data))
    return {
        'url': raw_url,
        'media_type': media_type,
        'name': name,
        'ref': path,
        'preview_url': raw_url if media_type == 'image' else None,
    }


def health(source):
    t0 = time.monotonic()
    try:
        root = normalize_path(source.root_path or '/', source.root_path or '/')
        _request(source, 'POST', '/api/fs/list', {
            'path': root, 'page': 1, 'per_page': 1, 'refresh': False,
        })
        return {'status': 'ok', 'latency_ms': int((time.monotonic() - t0) * 1000)}
    except AlistError as exc:
        return {
            'status': 'down',
            'latency_ms': int((time.monotonic() - t0) * 1000),
            'message': str(exc),
        }


def invalidate_cache(source_id, path=None):
    for key in list(_list_cache):
        if key[0] == source_id and (path is None or key[1] == path):
            _list_cache.pop(key, None)


def upload(source, target_path, fileobj, content_type, size):
    """Stream a file to AList via PUT /api/fs/put. target_path is already validated."""
    source_id = source.id or 0
    _breaker_check(source_id)
    base = (source.base_url or '').rstrip('/')
    if not base:
        raise AlistError('AList base_url is not configured.')
    headers = {
        'File-Path': quote(target_path, safe='/'),
        'Content-Type': content_type or 'application/octet-stream',
        'As-Task': 'false',
    }
    if size is not None:
        headers['Content-Length'] = str(int(size))
    token = _token_for(source)
    if token:
        headers['Authorization'] = token
    try:
        resp = requests.put(base + '/api/fs/put', data=fileobj, headers=headers, timeout=UPLOAD_TIMEOUT)
    except requests.exceptions.Timeout:
        _breaker_record_failure(source_id)
        raise AlistError(f'Upload to AList timed out after {UPLOAD_TIMEOUT}s.')
    except requests.exceptions.RequestException as exc:
        _breaker_record_failure(source_id)
        raise AlistError(f'Could not reach AList: {exc}')
    if resp.status_code != 200:
        _breaker_record_failure(source_id)
        raise AlistError(f'AList returned HTTP {resp.status_code} on upload.')
    try:
        payload = resp.json()
    except ValueError:
        raise AlistError('AList returned an unexpected (non-JSON) response on upload.')
    if payload.get('code') != 200:
        raise AlistError(payload.get('message') or 'AList rejected the upload.')
    _breaker_record_success(source_id)
    folder = target_path.rsplit('/', 1)[0] or '/'
    invalidate_cache(source_id, folder)
    # AList caches directory listings server-side; force a refresh on next list
    try:
        _request(source, 'POST', '/api/fs/list', {'path': folder, 'page': 1, 'per_page': 1, 'refresh': True})
    except AlistError:
        pass
    return {'ref': target_path}
