#!/bin/bash
# Node >= 18. Runs pure-logic tests on the REAL shipped JS (no Odoo needed).
set -e
cd "$(dirname "$0")"
cp ../../static/src/media_dialog/alist_tab_rules.js ./alist_tab_rules.mjs
cp ../../static/src/utils/bg_video_utils.js ./bg_video_utils.mjs
trap 'rm -f ./alist_tab_rules.mjs ./bg_video_utils.mjs' EXIT
node rules.test.mjs
node dialog_sim.test.mjs
node video.test.mjs
