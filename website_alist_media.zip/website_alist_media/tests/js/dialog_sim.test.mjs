import assert from "node:assert/strict";
import { shouldAppendAListTab, findAListTab, ALIST_TAB_ID } from "./alist_tab_rules.mjs";

// ---- verbatim logic from odoo 19.0 media_dialog.js (addTab/addTabs), Components stubbed
const TABS = { IMAGES: { id: "IMAGES", sequence: 10 }, ICONS: { id: "ICONS", sequence: 20, Component: { initFonts: () => [], tagNames: ["SPAN","I"] } } };
class NativeDialog {
  constructor(props){ this.props = { extraTabs: [], ...props }; this.selectedMedia={}; this.notebookPages=[]; this.initialIconClasses=[]; this.addTabs(); }
  selectMedia(){}
  addTab(tab, additionalProps = {}) {
    if (this.props.visibleTabs && !this.props.visibleTabs.includes(tab.id)) return;
    this.selectedMedia[tab.id] = [];
    this.notebookPages.push({ ...tab, props: { ...tab.props, ...additionalProps, id: tab.id } });
  }
  addTabs() {
    const onlyImages = this.props.onlyImages || (this.props.media && this.props.media.parentElement &&
      (this.props.media.parentElement.dataset.oeField === "image" || this.props.media.parentElement.dataset.oeType === "image"));
    if (!this.props.noImages) this.addTab(TABS.IMAGES, { multiSelect: this.props.multiImages });
    if (onlyImages) return;
    const addIcons = !this.props.visibleTabs || this.props.visibleTabs.includes(TABS.ICONS.id);
    if (addIcons) this.addTab(TABS.ICONS, { fonts: [] });
    this.props.extraTabs.forEach((tab) => this.addTab(tab));
  }
}
// ---- our patch, same body as alist_media_dialog_patch.js
class PatchedDialog extends NativeDialog {
  addTabs() {
    super.addTabs();
    const existingIds = this.notebookPages.map((p) => p.id);
    if (!shouldAppendAListTab(this.props, existingIds)) return;
    this.addTab(findAListTab(this.props.extraTabs), { alistOnlyImages: true, multiSelect: this.props.multiImages });
  }
}
const ALIST = { id: "ALIST", title: "AList" };
const resource = [ALIST, { id: "VIDEOS" }, { id: "DOCUMENTS" }];
const ids = (d) => d.notebookPages.map((p) => p.id);
const page = (d, id) => d.notebookPages.find((p) => p.id === id);
let n=0; const t=(name,fn)=>{fn();n++;console.log("PASS",name);};

t("BEFORE patch: gallery Add has only IMAGES (reproduces Grok finding)", () =>
  assert.deepEqual(ids(new NativeDialog({ onlyImages:true, multiImages:true, extraTabs:resource })), ["IMAGES"]));
t("AFTER patch: gallery Add = IMAGES + ALIST, multiSelect on, images-only", () => {
  const d = new PatchedDialog({ onlyImages:true, multiImages:true, extraTabs:resource });
  assert.deepEqual(ids(d), ["IMAGES","ALIST"]);
  assert.equal(page(d,"ALIST").props.multiSelect, true);
  assert.equal(page(d,"ALIST").props.alistOnlyImages, true);
});
t("AFTER patch: normal replace unchanged, exactly one ALIST", () => {
  const d = new PatchedDialog({ extraTabs:resource });
  assert.deepEqual(ids(d), ["IMAGES","ICONS","ALIST","VIDEOS","DOCUMENTS"]);
  assert.equal(page(d,"ALIST").props.alistOnlyImages, undefined);
});
t("AFTER patch: binary image field stays IMAGES only", () =>
  assert.deepEqual(ids(new PatchedDialog({ media:{parentElement:{dataset:{oeType:"image"}}}, extraTabs:resource })), ["IMAGES"]));
t("AFTER patch: video background dialog untouched", () =>
  assert.deepEqual(ids(new PatchedDialog({ visibleTabs:["VIDEO_BACKGROUND"], extraTabs:[{id:"VIDEO_BACKGROUND"}] })), ["VIDEO_BACKGROUND"]));
t("AFTER patch: rating/accordion icon picker untouched (ICONS only)", () =>
  assert.deepEqual(ids(new PatchedDialog({ visibleTabs:["ICONS"], extraTabs:resource })), ["ICONS"]));
t("Icon toolbar dialog (patched openIconDialog props) = ICONS + ALIST images-only", () => {
  const extraTabs = [{ ...ALIST, props: { alistOnlyImages: true } }];
  const d = new PatchedDialog({ visibleTabs:["ICONS", ALIST_TAB_ID], extraTabs, media:{ tagName:"I", parentElement:{dataset:{}} } });
  assert.deepEqual(ids(d), ["ICONS","ALIST"]);
  assert.equal(page(d,"ALIST").props.alistOnlyImages, true);
});
// onSaveIcon swap
t("onSaveIcon: image replaces <i>, icon->icon falls through", () => {
  const calls=[]; const prev={tagName:"I", replaceWith:(el)=>calls.push(["replace",el.tagName])};
  const onSaveIcon=(icon,prevIcon,sup)=>{ if(icon&&prevIcon&&icon.tagName!==prevIcon.tagName){prevIcon.replaceWith(icon);calls.push(["step"]);return;} return sup(); };
  onSaveIcon({tagName:"IMG"}, prev, ()=>calls.push(["native"]));
  onSaveIcon({tagName:"I"}, prev, ()=>calls.push(["native"]));
  assert.deepEqual(calls, [["replace","IMG"],["step"],["native"]]);
});
console.log(`\n${n} simulation tests passed`);
