import assert from "node:assert/strict";
import { shouldAppendAListTab, isInsideImageField, filterItems, findAListTab, ALIST_TAB_ID } from "./alist_tab_rules.mjs";

const ALIST = { id: "ALIST", title: "AList" };
const extra = [ALIST, { id: "VIDEOS" }];
const imageFieldMedia = { parentElement: { dataset: { oeType: "image" } } };
const normalMedia = { parentElement: { dataset: {} } };
let n = 0; const t = (name, fn) => { fn(); n++; console.log("PASS", name); };

// entry points from Odoo 19 source
t("s_image drop (onlyImages)", () => assert.equal(shouldAppendAListTab({ onlyImages: true, extraTabs: extra }, ["IMAGES"]), true));
t("gallery Add (onlyImages + multiImages)", () => assert.equal(shouldAppendAListTab({ onlyImages: true, multiImages: true, extraTabs: extra }, ["IMAGES"]), true));
t("background image (onlyImages, node=section)", () => assert.equal(shouldAppendAListTab({ onlyImages: true, media: normalMedia, extraTabs: extra }, ["IMAGES"]), true));
t("grid add image (onlyImages+noDocuments)", () => assert.equal(shouldAppendAListTab({ onlyImages: true, noDocuments: true, extraTabs: extra }, ["IMAGES"]), true));
t("normal replace: native already added AList -> no duplicate", () => assert.equal(shouldAppendAListTab({ extraTabs: extra }, ["IMAGES","ICONS","ALIST"]), false));
t("normal dialog without onlyImages -> patch does nothing", () => assert.equal(shouldAppendAListTab({ extraTabs: extra }, ["IMAGES","ICONS"]), false));
t("binary image field auto-onlyImages -> excluded", () => assert.equal(shouldAppendAListTab({ media: imageFieldMedia, extraTabs: extra }, ["IMAGES"]), false));
t("explicit onlyImages but inside image field -> excluded", () => assert.equal(shouldAppendAListTab({ onlyImages: true, media: imageFieldMedia, extraTabs: extra }, ["IMAGES"]), false));
t("noImages -> excluded", () => assert.equal(shouldAppendAListTab({ onlyImages: true, noImages: true, extraTabs: extra }, []), false));
t("video background visibleTabs -> excluded", () => assert.equal(shouldAppendAListTab({ onlyImages: true, visibleTabs: ["VIDEO_BACKGROUND"], extraTabs: extra }, []), false));
t("editor without AList plugin (no resource) -> no-op", () => assert.equal(shouldAppendAListTab({ onlyImages: true, extraTabs: [] }, ["IMAGES"]), false));
t("extraTabs undefined -> no crash", () => assert.equal(shouldAppendAListTab({ onlyImages: true }, ["IMAGES"]), false));
t("null props -> no crash", () => assert.equal(shouldAppendAListTab(null, []), false));
t("isInsideImageField oeField", () => assert.equal(isInsideImageField({ parentElement: { dataset: { oeField: "image" } } }), true));
t("isInsideImageField detached node", () => assert.equal(isInsideImageField({ parentElement: null }), false));
t("filter images-only keeps dirs+images", () => assert.deepEqual(
  filterItems([{is_dir:true,ref:"a"},{media_type:"image",ref:"b"},{media_type:"video",ref:"c"},{media_type:"other",ref:"d"}], true).map(i=>i.ref), ["a","b"]));
t("filter normal mode keeps all", () => assert.equal(filterItems([{media_type:"video"},{media_type:"image"}], false).length, 2));
t("findAListTab", () => { assert.equal(findAListTab(extra), ALIST); assert.equal(findAListTab(undefined), null); });
console.log(`\n${n} tests passed`);
