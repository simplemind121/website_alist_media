// Tests the REAL shipped JS (copied by run.sh), not a Python mirror.
import assert from "node:assert/strict";
import {
    isDirectMediaVideoUrl,
    extractBackgroundVideoSrc,
    mergeVisibleTabs,
    mergeExtraTabsWithAList,
} from "./bg_video_utils.mjs";
import {
    sanitizeAListVideoElements,
    sanitizeAListVideosIn,
    shouldAppendAListTab,
} from "./alist_tab_rules.mjs";

// --- minimal DOM stand-ins -------------------------------------------------
class ClassList {
    constructor(list = []) { this.s = new Set(list); }
    add(...c) { c.forEach((x) => this.s.add(x)); }
    remove(...c) { c.forEach((x) => this.s.delete(x)); }
    contains(c) { return this.s.has(c); }
    get list() { return [...this.s].sort(); }
}
function el(tag, { classes = [], attrs = {}, dataset = {}, children = [] } = {}) {
    const a = { ...attrs };
    return {
        tagName: tag,
        classList: new ClassList(classes),
        dataset: { ...dataset },
        getAttribute: (k) => (k in a ? a[k] : null),
        hasAttribute: (k) => k in a,
        setAttribute: (k, v) => { a[k] = v; },
        get src() { return a.src || ""; },
        querySelector(sel) { return children.find((c) => c.tagName.toLowerCase() === sel) || null; },
        querySelectorAll() { return children.filter((c) => c.tagName === "VIDEO"); },
        _attrs: a,
    };
}

// --- direct URL detection (BG playback switch) -------------------------------
assert.equal(isDirectMediaVideoUrl("https://media.051288888.xyz/b2/a/demo.mp4"), true);
assert.equal(isDirectMediaVideoUrl("https://media.051288888.xyz/b2/a/demo.MP4?x=1#t"), true);
assert.equal(isDirectMediaVideoUrl("https://media.051288888.xyz/b2/a/demo.webm"), true);
assert.equal(isDirectMediaVideoUrl("https://www.youtube.com/embed/abc.mp4"), false);
assert.equal(isDirectMediaVideoUrl("//player.vimeo.com/video/528686125"), false);
assert.equal(isDirectMediaVideoUrl("about:blank"), false);
assert.equal(isDirectMediaVideoUrl(""), false);
assert.equal(isDirectMediaVideoUrl(null), false);

// --- BG save payload -> URL ----------------------------------------------------
assert.equal(extractBackgroundVideoSrc(el("VIDEO", { attrs: { src: "https://cdn/x.mp4" } })), "https://cdn/x.mp4");
assert.equal(
    extractBackgroundVideoSrc(el("DIV", { children: [el("IFRAME", { attrs: { src: "//player.vimeo.com/video/1" } })] })),
    "//player.vimeo.com/video/1"
);
assert.equal(extractBackgroundVideoSrc(null), "");

// --- tab merging used by the BG dialog -------------------------------------------
assert.deepEqual(mergeVisibleTabs(["VIDEO_BACKGROUND"], ["ALIST"]), ["VIDEO_BACKGROUND", "ALIST"]);
assert.deepEqual(mergeVisibleTabs(["ALIST"], ["ALIST"]), ["ALIST"]);
const base = [{ id: "VIDEO_BACKGROUND" }];
const merged = mergeExtraTabsWithAList(base, { id: "ALIST" });
assert.equal(merged.length, 2);
assert.equal(base.length, 1, "input must not be mutated");
assert.equal(mergeExtraTabsWithAList(merged, { id: "ALIST" }).length, 2);

// BG dialog is not "onlyImages": our images-only patch must NOT add a 2nd AList tab
assert.equal(
    shouldAppendAListTab(
        { visibleTabs: ["VIDEO_BACKGROUND", "ALIST"], extraTabs: merged },
        ["VIDEO_BACKGROUND", "ALIST"]
    ),
    false
);

// --- body video class hygiene ------------------------------------------------------
const v = el("VIDEO", {
    classes: ["o_alist_cdn_video", "img", "img-fluid", "o_we_custom_image", "mx-auto", "rounded"],
    attrs: { src: "https://cdn/demo.mp4" },
});
sanitizeAListVideoElements([v]);
assert.deepEqual(v.classList.list, ["img-fluid", "mx-auto", "o_alist_cdn_video", "rounded"]);
assert.equal(v.hasAttribute("controls"), true);
assert.equal(v.hasAttribute("playsinline"), true);
assert.equal(v.dataset.alistExternal, "1");
// idempotent
sanitizeAListVideoElements([v]);
assert.deepEqual(v.classList.list, ["img-fluid", "mx-auto", "o_alist_cdn_video", "rounded"]);
// stock video untouched
const stock = el("VIDEO", { classes: ["img", "foo"] });
sanitizeAListVideoElements([stock]);
assert.deepEqual(stock.classList.list, ["foo", "img"]);
// images untouched
const img = el("IMG", { classes: ["img", "o_we_custom_image"], dataset: { alistExternal: "1" } });
sanitizeAListVideoElements([img]);
assert.deepEqual(img.classList.list, ["img", "o_we_custom_image"]);
// root / {root} payload forms
const v2 = el("VIDEO", { classes: ["o_alist_cdn_video", "img"] });
sanitizeAListVideosIn({ root: el("DIV", { children: [v2] }) });
assert.equal(v2.classList.contains("img"), false);
sanitizeAListVideosIn(undefined); // must not throw
sanitizeAListVideosIn({});

console.log("video.test.mjs: all assertions passed");
