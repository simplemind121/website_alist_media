# -*- coding: utf-8 -*-
"""MEDIUM tests: need an Odoo 19 database, no external network (AList/HTTP mocked).

Run inside the Odoo container, e.g.:
  odoo -d <test_db> -i website_alist_media --test-enable \
       --test-tags /website_alist_media --stop-after-init --no-http
"""
import io
from unittest import mock

from odoo.exceptions import UserError, ValidationError
from odoo.tests import TransactionCase, new_test_user, tagged

from ..models import alist_client

CDN = 'https://media.example.com'


@tagged('post_install', '-at_install', 'website_alist_media')
class TestAlistMediaMedium(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.source = cls.env['website.alist.media.source'].create({
            'name': 'Test AList',
            'source_type': 'alist',
            'base_url': 'https://one.example.com',
            'cdn_base_url': CDN,
            'root_path': '/media',
            'upload_enabled': True,
            'upload_max_mb': 1,
        })
        cls.designer = new_test_user(cls.env, login='wam_designer',
                                     groups='base.group_user,website.group_website_designer')
        cls.plain_user = new_test_user(cls.env, login='wam_plain', groups='base.group_user')

    # ---------------------------------------------------------------- source
    def test_secret_storage_warning(self):
        self.assertEqual(self.source.secret_storage, 'none')
        self.source.token = 'abc'
        self.assertEqual(self.source.secret_storage, 'database')
        self.source.secret_ref = 'WAM_ENV'
        self.assertEqual(self.source.secret_storage, 'mixed')
        self.source.token = False
        self.assertEqual(self.source.secret_storage, 'env')

    def test_upload_max_constraint(self):
        with self.assertRaises(ValidationError):
            self.source.upload_max_mb = 0
            self.source.flush_recordset()

    def test_public_capabilities_has_no_secrets(self):
        self.source.token = 'SECRET'
        caps = self.source._public_capabilities()
        self.assertNotIn('SECRET', repr(caps))
        self.assertTrue(caps['upload_enabled'])
        self.assertIn('.jpg', caps['image_extensions'])

    def test_resolve_srcset_opt_in(self):
        fake = {'url': CDN + '/media/a.jpg', 'media_type': 'image', 'name': 'a.jpg', 'ref': '/media/a.jpg'}
        with mock.patch.object(alist_client, 'resolve', return_value=dict(fake)):
            self.assertNotIn('srcset', self.source.resolve_media('/media/a.jpg'))
            self.source.write({'enable_srcset': True,
                               'resize_url_template': '{origin}/cdn-cgi/image/width={width}{path}',
                               'srcset_widths': '480,960'})
            res = self.source.resolve_media('/media/a.jpg')
        self.assertIn('480w', res['srcset'])
        self.assertEqual(res['sizes'], '100vw')

    def test_resolve_rejects_foreign_host(self):
        bad = {'url': 'https://evil.example.org/a.jpg', 'media_type': 'image', 'name': 'a.jpg', 'ref': '/media/a.jpg'}
        with mock.patch.object(alist_client, 'resolve', return_value=bad):
            with self.assertRaises(UserError):
                self.source.resolve_media('/media/a.jpg')

    # ---------------------------------------------------------------- upload
    def _upload(self, **kw):
        args = dict(folder='/media/2026', filename='a.jpg', fileobj=io.BytesIO(b'x'),
                    content_type='image/jpeg', size=1)
        args.update(kw)
        return self.source.upload_media(**args)

    def test_upload_happy_path(self):
        resolved = {'url': CDN + '/media/2026/a.jpg', 'media_type': 'image', 'name': 'a.jpg', 'ref': '/media/2026/a.jpg'}
        with mock.patch.object(alist_client, 'upload', return_value={'ref': '/media/2026/a.jpg'}) as up, \
                mock.patch.object(alist_client, 'resolve', return_value=resolved):
            res = self._upload()
        self.assertEqual(up.call_args.args[1], '/media/2026/a.jpg')
        self.assertEqual(res['url'], CDN + '/media/2026/a.jpg')

    def test_upload_never_creates_attachment(self):
        before = self.env['ir.attachment'].search_count([])
        resolved = {'url': CDN + '/media/a.jpg', 'media_type': 'image', 'name': 'a.jpg', 'ref': '/media/a.jpg'}
        with mock.patch.object(alist_client, 'upload', return_value={}), \
                mock.patch.object(alist_client, 'resolve', return_value=resolved):
            self._upload(folder='/media')
        self.assertEqual(self.env['ir.attachment'].search_count([]), before)

    def test_upload_disabled(self):
        self.source.upload_enabled = False
        with self.assertRaises(UserError):
            self._upload()

    def test_upload_too_big(self):
        with self.assertRaises(UserError):
            self._upload(size=2 * 1024 * 1024)

    def test_upload_bad_extension(self):
        with self.assertRaises(UserError):
            self._upload(filename='shell.php')

    def test_upload_outside_root(self):
        with mock.patch.object(alist_client, 'upload') as up:
            with self.assertRaises(UserError):
                self._upload(folder='/private')
            with self.assertRaises(UserError):
                self._upload(folder='/media/../private')
        up.assert_not_called()

    # --------------------------------------------------------- link index
    def _make_view(self, url):
        return self.env['ir.ui.view'].create({
            'name': 'wam test view',
            'type': 'qweb',
            'key': 'website_alist_media.wam_test_view',
            'arch': f'<t t-name="website_alist_media.wam_test_view"><div>'
                    f'<img src="{url}"/><section style="background-image: url({CDN}/bg.jpg)"/>'
                    f'<img src="https://other.example.net/x.jpg"/></div></t>',
        })

    def test_scan_indexes_references(self):
        view = self._make_view(CDN + '/media/a.jpg')
        Link = self.env['website.alist.media.link'].with_context(website_alist_silent=True)
        Link.action_scan_references()
        links = Link.search([('url', 'in', [CDN + '/media/a.jpg', CDN + '/bg.jpg'])])
        self.assertEqual(len(links), 2)
        ref = links.filtered(lambda l: l.url.endswith('/a.jpg')).ref_ids
        self.assertEqual((ref.res_model, ref.res_id), ('ir.ui.view', view.id))
        self.assertFalse(Link.search([('url', 'like', 'other.example.net')]))

    def test_scan_is_read_only_on_content(self):
        view = self._make_view(CDN + '/media/a.jpg')
        arch_before = view.arch_db
        self.env['website.alist.media.link'].with_context(website_alist_silent=True).action_scan_references()
        self.assertEqual(view.arch_db, arch_before)

    def test_rescan_zeroes_removed_references(self):
        view = self._make_view(CDN + '/media/a.jpg')
        Link = self.env['website.alist.media.link'].with_context(website_alist_silent=True)
        Link.action_scan_references()
        view.unlink()
        Link.action_scan_references()
        link = Link.search([('url', '=', CDN + '/media/a.jpg')])
        self.assertEqual(link.ref_count, 0)

    def test_check_links_statuses(self):
        Link = self.env['website.alist.media.link'].with_context(website_alist_silent=True)
        ok = Link.create({'url': CDN + '/ok.jpg', 'source_id': self.source.id})
        gone = Link.create({'url': CDN + '/gone.jpg', 'source_id': self.source.id})
        foreign = Link.create({'url': 'https://evil.example.org/x.jpg', 'source_id': self.source.id})

        def fake_head(url, **kw):
            return mock.Mock(status_code=404 if 'gone' in url else 200)

        with mock.patch('odoo.addons.website_alist_media.models.media_link.requests.head',
                        side_effect=fake_head) as head:
            (ok | gone | foreign).action_check_links()
        self.assertEqual(ok.status, 'ok')
        self.assertEqual(gone.status, 'broken')
        self.assertEqual(gone.http_code, 404)
        self.assertEqual(foreign.status, 'error')  # never requested (SSRF guard)
        requested = [c.args[0] for c in head.call_args_list]
        self.assertNotIn('https://evil.example.org/x.jpg', requested)

    def test_scan_requires_designer(self):
        Link = self.env['website.alist.media.link'].with_user(self.plain_user)
        with self.assertRaises(Exception):  # AccessError (no ACL) or UserError (guard)
            Link.with_context(website_alist_silent=True).action_scan_references()
        # designer allowed
        self.env['website.alist.media.link'].with_user(self.designer).with_context(
            website_alist_silent=True).action_scan_references()

    def test_cron_runs(self):
        cron = self.env.ref('website_alist_media.cron_website_alist_media_links')
        self.assertTrue(cron.active)
        with mock.patch('odoo.addons.website_alist_media.models.media_link.requests.head',
                        return_value=mock.Mock(status_code=200)):
            self.env['website.alist.media.link'].sudo()._cron_scan_and_check()

    # ------------------------------------------------------ 19.0.4.1.0 merge
    def test_designer_cannot_read_secrets(self):
        """Secrets are field-restricted: a website designer may read the source
        record (for the dialog) but never token / s3_secret_key / secret_ref."""
        from odoo.exceptions import AccessError
        self.source.write({'token': 'SECRET', 's3_secret_key': 'S3SECRET', 'secret_ref': 'WAM_ENV'})
        as_designer = self.source.with_user(self.designer)
        data = as_designer.read(['name', 'root_path'])[0]
        self.assertEqual(data['name'], 'Test AList')
        for fname in ('token', 's3_secret_key', 'secret_ref'):
            with self.assertRaises(AccessError):
                as_designer.read([fname])
        # computed status is still visible without exposing the value
        self.assertIn(as_designer.secret_storage, ('env', 'mixed', 'database', 'none'))

    def test_alist_integer_type_hint(self):
        """AList returns integer ``type``; unknown files must not crash the list."""
        payload = {'content': [
            {'name': 'notes.txt', 'is_dir': False, 'type': 4},
            {'name': 'clip', 'is_dir': False, 'type': 2},
            {'name': 'movie.mkv', 'is_dir': False, 'type': 2},
        ], 'total': 3}
        with mock.patch.object(alist_client, '_request', return_value=payload):
            alist_client.invalidate_cache(self.source.id)
            data = self.source.list_media(path='/media', page=1, per_page=30)
        types = {i['name']: i['media_type'] for i in data['items']}
        self.assertEqual(types['notes.txt'], 'unknown')
        self.assertEqual(types['clip'], 'video')
        self.assertEqual(types['movie.mkv'], 'unknown')
