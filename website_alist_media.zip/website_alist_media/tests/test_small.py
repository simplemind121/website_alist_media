# -*- coding: utf-8 -*-
"""SMALL tests (hermetic, no Odoo, no network). Run:
    cd website_alist_media && python3 -m unittest tests.test_small -v
Loads models/cdn_utils, media_utils, alist_client as a throwaway package so the
relative imports work without an Odoo registry.
"""
import importlib.util
import os
import sys
import types
import unittest
from unittest import mock

_MODELS = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'models'))
_PKG = '_wam_small_models'


def _load(name):
    full = f'{_PKG}.{name}'
    if full in sys.modules:
        return sys.modules[full]
    spec = importlib.util.spec_from_file_location(full, os.path.join(_MODELS, name + '.py'))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[full] = mod
    spec.loader.exec_module(mod)
    return mod


if _PKG not in sys.modules:
    pkg = types.ModuleType(_PKG)
    pkg.__path__ = [_MODELS]
    sys.modules[_PKG] = pkg
cdn_utils = _load('cdn_utils')
mu = _load('media_utils')
ac = _load('alist_client')


class FakeSource:
    def __init__(self, **kw):
        self.id = kw.pop('id', 1)
        defaults = dict(base_url='https://one.example.com', token='', secret_ref='',
                        root_path='/media', cdn_base_url='https://media.example.com',
                        cdn_strip_path_prefix='/d', image_extensions='', video_extensions='',
                        page_size=30, thumbnail_url_template='', search_mode='remote')
        defaults.update(kw)
        self.__dict__.update(defaults)


class TestSanitizeFilename(unittest.TestCase):
    EXTS = ('.jpg', '.png', '.mp4')

    def test_plain(self):
        self.assertEqual(mu.sanitize_upload_filename('photo.JPG', self.EXTS), 'photo.jpg')

    def test_chinese_kept(self):
        self.assertEqual(mu.sanitize_upload_filename('烟花 产品图.png', self.EXTS), '烟花 产品图.png')

    def test_path_components_stripped(self):
        self.assertEqual(mu.sanitize_upload_filename('../../etc/x.jpg', self.EXTS), 'x.jpg')
        self.assertEqual(mu.sanitize_upload_filename('C:\\a\\b.png', self.EXTS), 'b.png')

    def test_unsafe_chars(self):
        self.assertEqual(mu.sanitize_upload_filename('a<b>|c?.jpg', self.EXTS), 'a_b_c.jpg')

    def test_control_chars_removed(self):
        self.assertEqual(mu.sanitize_upload_filename('a\x00b\n.jpg', self.EXTS), 'ab.jpg')

    def test_disallowed_ext(self):
        for bad in ('x.php', 'x.svg.exe', 'noext', 'x.JPG.html'):
            with self.assertRaises(mu.ValidationFailure):
                mu.sanitize_upload_filename(bad, self.EXTS)

    def test_empty(self):
        for bad in ('', '.', '..', '/'):
            with self.assertRaises(mu.ValidationFailure):
                mu.sanitize_upload_filename(bad, self.EXTS)

    def test_only_ext(self):
        with self.assertRaises(mu.ValidationFailure):
            mu.sanitize_upload_filename('.jpg', self.EXTS)  # hidden file, no extension

    def test_length_capped(self):
        name = mu.sanitize_upload_filename('a' * 400 + '.jpg', self.EXTS)
        self.assertLessEqual(len(name), mu.MAX_FILENAME_LEN)
        self.assertTrue(name.endswith('.jpg'))


class TestUploadPath(unittest.TestCase):
    def test_inside_root(self):
        self.assertEqual(mu.build_upload_path('/media/2026', 'a.jpg', '/media'), '/media/2026/a.jpg')

    def test_root_itself(self):
        self.assertEqual(mu.build_upload_path('/media', 'a.jpg', '/media'), '/media/a.jpg')

    def test_root_slash(self):
        self.assertEqual(mu.build_upload_path('/', 'a.jpg', '/'), '/a.jpg')

    def test_dotdot_refused(self):
        with self.assertRaises(mu.ValidationFailure):
            mu.build_upload_path('/media/../etc', 'a.jpg', '/media')

    def test_outside_root_refused(self):
        with self.assertRaises(mu.ValidationFailure):
            mu.build_upload_path('/private', 'a.jpg', '/media')

    def test_prefix_trick_refused(self):
        with self.assertRaises(mu.ValidationFailure):
            mu.build_upload_path('/media-secret', 'a.jpg', '/media')

    def test_filename_with_slash_refused(self):
        with self.assertRaises(mu.ValidationFailure):
            mu.build_upload_path('/media', 'x/a.jpg', '/media')


class TestTemplatesAndSrcset(unittest.TestCase):
    CF = '{origin}/cdn-cgi/image/width={width},format=auto{path}'

    def test_render(self):
        self.assertEqual(
            mu.render_url_template(self.CF, 'https://m.example.com/a/b.jpg?x=1', 320),
            'https://m.example.com/cdn-cgi/image/width=320,format=auto/a/b.jpg?x=1')

    def test_empty_template_passthrough(self):
        self.assertEqual(mu.render_url_template('', 'https://a/b.jpg', 1), 'https://a/b.jpg')

    def test_bad_template_passthrough(self):
        self.assertEqual(mu.render_url_template('{nope}', 'https://a/b.jpg', 1), 'https://a/b.jpg')

    def test_srcset(self):
        s = mu.build_srcset('https://m.example.com/a.jpg', self.CF, (480, 960))
        self.assertEqual(s, 'https://m.example.com/cdn-cgi/image/width=480,format=auto/a.jpg 480w, '
                            'https://m.example.com/cdn-cgi/image/width=960,format=auto/a.jpg 960w')

    def test_srcset_bad_template_empty(self):
        self.assertEqual(mu.build_srcset('https://a/b.jpg', '{nope}', (480,)), '')
        self.assertEqual(mu.build_srcset('https://a/b.jpg', '', (480,)), '')

    def test_parse_widths(self):
        self.assertEqual(mu.parse_widths('960, 480,abc,99999,480'), (480, 960))
        self.assertEqual(mu.parse_widths(''), (480, 960, 1600))


class TestExtractUrls(unittest.TestCase):
    HOSTS = {'media.example.com'}

    def test_html_and_css(self):
        html = ('<img src="https://media.example.com/a.jpg"/>'
                '<section style="background-image: url(&quot;https://media.example.com/bg.webp&quot;)">'
                '<img src="https://other.com/x.jpg"/>'
                '<a href="https://media.example.com/doc.pdf?a=1&amp;b=2">x</a>')
        self.assertEqual(mu.extract_urls_for_hosts(html, self.HOSTS), {
            'https://media.example.com/a.jpg',
            'https://media.example.com/bg.webp',
            'https://media.example.com/doc.pdf?a=1&b=2',
        })

    def test_css_unquoted_url(self):
        self.assertEqual(mu.extract_urls_for_hosts('url(https://media.example.com/c.png)', self.HOSTS),
                         {'https://media.example.com/c.png'})

    def test_json_escaped_translations(self):
        text = '{"en_US": "<img src=\\"https://media.example.com/a.jpg\\">", "zh_CN": "..."}'
        self.assertEqual(mu.extract_urls_for_hosts(text, self.HOSTS), {'https://media.example.com/a.jpg'})

    def test_srcset_attribute(self):
        text = 'srcset="https://media.example.com/cdn-cgi/image/width=480/a.jpg 480w, https://media.example.com/a.jpg 960w"'
        self.assertEqual(len(mu.extract_urls_for_hosts(text, self.HOSTS)), 2)

    def test_host_lookalike_ignored(self):
        self.assertEqual(mu.extract_urls_for_hosts('https://media.example.com.evil.io/a.jpg', self.HOSTS), set())

    def test_empty(self):
        self.assertEqual(mu.extract_urls_for_hosts('', self.HOSTS), set())
        self.assertEqual(mu.extract_urls_for_hosts('x', set()), set())


class TestSecretStorage(unittest.TestCase):
    def test_modes(self):
        self.assertEqual(mu.secret_storage_mode('', 'ENV'), 'env')
        self.assertEqual(mu.secret_storage_mode('tok', ''), 'database')
        self.assertEqual(mu.secret_storage_mode('tok', 'ENV'), 'mixed')
        self.assertEqual(mu.secret_storage_mode('', '', 's3secret'), 'database')
        self.assertEqual(mu.secret_storage_mode(None, None), 'none')


class TestAlistClient(unittest.TestCase):
    def setUp(self):
        ac._list_cache.clear()
        ac._breaker_failures.clear()
        ac._breaker_open_until.clear()

    def test_env_token_wins_over_db(self):
        src = FakeSource(token='db-token', secret_ref='WAM_TEST_TOKEN')
        with mock.patch.dict(os.environ, {'WAM_TEST_TOKEN': 'env-token'}):
            self.assertEqual(ac._token_for(src), 'env-token')

    def test_db_token_fallback_when_env_missing(self):
        src = FakeSource(token='db-token', secret_ref='WAM_TEST_MISSING')
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop('WAM_TEST_MISSING', None)
            self.assertEqual(ac._token_for(src), 'db-token')

    def test_remote_search_maps_and_filters_outside_root(self):
        src = FakeSource()
        data = {'content': [
            {'parent': '/media/2026', 'name': 'a.jpg', 'is_dir': False, 'size': 1},
            {'parent': '/private', 'name': 'leak.jpg', 'is_dir': False, 'size': 1},
            {'parent': '/media', 'name': 'sub', 'is_dir': True, 'size': 0},
        ], 'total': 3}
        with mock.patch.object(ac, '_request', return_value=data) as req:
            res = ac.search(src, 'a', path='/media')
        self.assertEqual(req.call_args[0][2], '/api/fs/search')
        self.assertEqual(req.call_args[0][3]['parent'], '/media')
        refs = [i['ref'] for i in res['items']]
        self.assertEqual(refs, ['/media/2026/a.jpg', '/media/sub'])
        self.assertEqual(res['search_mode'], 'remote')
        self.assertTrue(res['items'][0]['preview_url'].startswith('https://media.example.com/'))

    def test_search_falls_back_to_local_on_error(self):
        src = FakeSource()
        listing = {'items': [{'ref': '/media/a.jpg', 'name': 'a.jpg'}, {'ref': '/media/b.jpg', 'name': 'b.jpg'}],
                   'total': 2, 'path': '/media'}
        with mock.patch.object(ac, '_request', side_effect=ac.AlistError('search not enabled')), \
                mock.patch.object(ac, 'list_dir', return_value=listing):
            res = ac.search(src, 'b', path='/media')
        self.assertEqual(res['search_mode'], 'local')
        self.assertEqual([i['ref'] for i in res['items']], ['/media/b.jpg'])

    def test_search_local_mode_never_calls_remote(self):
        src = FakeSource(search_mode='local')
        with mock.patch.object(ac, '_request') as req, \
                mock.patch.object(ac, 'list_dir', return_value={'items': [], 'total': 0, 'path': '/media'}):
            ac.search(src, 'x', path='/media')
        req.assert_not_called()

    def test_thumbnail_template_applied_in_listing(self):
        src = FakeSource(thumbnail_url_template='{origin}/cdn-cgi/image/width={width}{path}')
        data = {'content': [{'name': 'a.jpg', 'is_dir': False}], 'total': 1}
        with mock.patch.object(ac, '_request', return_value=data):
            res = ac.list_dir(src, path='/media', use_cache=False)
        self.assertEqual(res['items'][0]['preview_url'],
                         'https://media.example.com/cdn-cgi/image/width=320/media/a.jpg')

    def test_upload_headers_and_cache_invalidation(self):
        src = FakeSource(secret_ref='WAM_UP', token='')
        ac._list_cache[(1, '/media', 1, 30)] = (0, {'stale': True})
        ac._list_cache[(1, '/other', 1, 30)] = (0, {'keep': True})
        resp = mock.Mock(status_code=200)
        resp.json.return_value = {'code': 200, 'data': {}}
        with mock.patch.dict(os.environ, {'WAM_UP': 'tok'}), \
                mock.patch.object(ac.requests, 'put', return_value=resp) as put, \
                mock.patch.object(ac, '_request', return_value={}):
            out = ac.upload(src, '/media/烟花 a.jpg', b'data', 'image/jpeg', 4)
        headers = put.call_args.kwargs['headers']
        self.assertEqual(headers['File-Path'], '/media/%E7%83%9F%E8%8A%B1%20a.jpg')
        self.assertEqual(headers['Authorization'], 'tok')
        self.assertEqual(headers['Content-Length'], '4')
        self.assertEqual(put.call_args.args[0], 'https://one.example.com/api/fs/put')
        self.assertEqual(out, {'ref': '/media/烟花 a.jpg'})
        self.assertNotIn((1, '/media', 1, 30), ac._list_cache)
        self.assertIn((1, '/other', 1, 30), ac._list_cache)

    def test_upload_api_error_surfaces(self):
        src = FakeSource()
        resp = mock.Mock(status_code=200)
        resp.json.return_value = {'code': 403, 'message': 'permission denied'}
        with mock.patch.object(ac.requests, 'put', return_value=resp):
            with self.assertRaises(ac.AlistError) as ctx:
                ac.upload(src, '/media/a.jpg', b'x', 'image/jpeg', 1)
        self.assertIn('permission denied', str(ctx.exception))

    def test_upload_error_message_has_no_token(self):
        src = FakeSource(token='SUPERSECRET')
        with mock.patch.object(ac.requests, 'put', side_effect=ac.requests.exceptions.ConnectionError('boom')):
            with self.assertRaises(ac.AlistError) as ctx:
                ac.upload(src, '/media/a.jpg', b'x', 'image/jpeg', 1)
        self.assertNotIn('SUPERSECRET', str(ctx.exception))


if __name__ == '__main__':
    unittest.main()
