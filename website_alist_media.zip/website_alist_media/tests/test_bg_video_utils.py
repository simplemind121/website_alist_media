# -*- coding: utf-8 -*-
"""Pure unit tests mirroring static/src/utils/bg_video_utils.js helpers."""
import unittest


DIRECT_VIDEO_EXTENSIONS = (
    ".mp4",
    ".webm",
    ".ogg",
    ".ogv",
    ".mov",
    ".m4v",
    ".mkv",
    ".avi",
)

EMBED_HOST_MARKERS = (
    "youtube.com",
    "youtu.be",
    "youtube-nocookie.com",
    "vimeo.com",
    "player.vimeo.com",
    "dailymotion.com",
    "instagram.com",
)


def url_path_lower(src):
    if not src or not isinstance(src, str):
        return ""
    no_hash = src.split("#", 1)[0]
    path = no_hash.split("?", 1)[0]
    return path.lower()


def is_direct_media_video_url(src):
    if not src or not isinstance(src, str):
        return False
    trimmed = src.strip()
    if not trimmed or trimmed == "about:blank":
        return False
    lower = trimmed.lower()
    if any(h in lower for h in EMBED_HOST_MARKERS):
        return False
    path = url_path_lower(trimmed)
    return any(path.endswith(ext) for ext in DIRECT_VIDEO_EXTENSIONS)


def extract_background_video_src(media):
    """media is a dict stand-in: {tag, src, iframe_src, video_src, oe_expression, data_src}."""
    if not media:
        return ""
    tag = (media.get("tag") or "").upper()
    if tag == "VIDEO":
        return media.get("src") or ""
    if tag == "IFRAME":
        return media.get("src") or ""
    if media.get("iframe_src"):
        return media["iframe_src"]
    if media.get("video_src"):
        return media["video_src"]
    if media.get("oe_expression"):
        return media["oe_expression"]
    if media.get("data_src"):
        return media["data_src"]
    return ""


def merge_visible_tabs(visible_tabs, extra_ids=None):
    extra_ids = extra_ids if extra_ids is not None else ["ALIST"]
    base = list(visible_tabs) if isinstance(visible_tabs, (list, tuple)) else []
    for i in extra_ids:
        if i and i not in base:
            base.append(i)
    return base


def merge_extra_tabs_with_alist(extra_tabs, alist_tab):
    tabs = list(extra_tabs) if isinstance(extra_tabs, (list, tuple)) else []
    if not alist_tab or not alist_tab.get("id"):
        return tabs
    if any(t and t.get("id") == alist_tab["id"] for t in tabs):
        return tabs
    tabs.append(alist_tab)
    return tabs


class TestIsDirectMediaVideoUrl(unittest.TestCase):
    def test_mp4_cdn(self):
        self.assertTrue(
            is_direct_media_video_url("https://cdn.example.com/b2/hero.mp4?sign=abc")
        )

    def test_webm(self):
        self.assertTrue(is_direct_media_video_url("https://cdn.example.com/x.webm"))

    def test_youtube_rejected(self):
        self.assertFalse(
            is_direct_media_video_url("https://www.youtube.com/embed/abc123?autoplay=1")
        )

    def test_vimeo_rejected(self):
        self.assertFalse(
            is_direct_media_video_url("https://player.vimeo.com/video/12345")
        )

    def test_empty(self):
        self.assertFalse(is_direct_media_video_url(""))
        self.assertFalse(is_direct_media_video_url(None))
        self.assertFalse(is_direct_media_video_url("about:blank"))


class TestExtractBackgroundVideoSrc(unittest.TestCase):
    def test_video_el(self):
        self.assertEqual(
            extract_background_video_src(
                {"tag": "VIDEO", "src": "https://cdn.example.com/a.mp4"}
            ),
            "https://cdn.example.com/a.mp4",
        )

    def test_iframe_wrapper(self):
        self.assertEqual(
            extract_background_video_src(
                {"tag": "DIV", "iframe_src": "https://youtube.com/embed/x"}
            ),
            "https://youtube.com/embed/x",
        )

    def test_none(self):
        self.assertEqual(extract_background_video_src(None), "")


class TestMergeTabs(unittest.TestCase):
    def test_merge_visible(self):
        self.assertEqual(
            merge_visible_tabs(["VIDEO_BACKGROUND"]),
            ["VIDEO_BACKGROUND", "ALIST"],
        )

    def test_merge_visible_idempotent(self):
        self.assertEqual(
            merge_visible_tabs(["VIDEO_BACKGROUND", "ALIST"]),
            ["VIDEO_BACKGROUND", "ALIST"],
        )

    def test_merge_extra(self):
        tabs = merge_extra_tabs_with_alist(
            [{"id": "VIDEO_BACKGROUND"}],
            {"id": "ALIST", "title": "AList"},
        )
        self.assertEqual([t["id"] for t in tabs], ["VIDEO_BACKGROUND", "ALIST"])

    def test_merge_extra_already(self):
        tabs = merge_extra_tabs_with_alist(
            [{"id": "VIDEO_BACKGROUND"}, {"id": "ALIST"}],
            {"id": "ALIST", "title": "AList"},
        )
        self.assertEqual(len(tabs), 2)


class TestVideosOnlyFilter(unittest.TestCase):
    """Mirror AListSelector.visibleItems videosOnly / onlyImages rules."""

    @staticmethod
    def visible_items(items, only_images=False, videos_only=False):
        if only_images:
            return [i for i in items if i.get("is_dir") or i.get("media_type") == "image"]
        if videos_only:
            return [i for i in items if i.get("is_dir") or i.get("media_type") == "video"]
        return list(items)

    def test_videos_only(self):
        items = [
            {"is_dir": True, "name": "folder"},
            {"media_type": "image", "name": "a.jpg"},
            {"media_type": "video", "name": "b.mp4"},
        ]
        out = self.visible_items(items, videos_only=True)
        self.assertEqual([i["name"] for i in out], ["folder", "b.mp4"])

    def test_body_non_only_images_keeps_video(self):
        items = [
            {"media_type": "image", "name": "a.jpg"},
            {"media_type": "video", "name": "b.mp4"},
        ]
        out = self.visible_items(items, only_images=False, videos_only=False)
        self.assertEqual(len(out), 2)


if __name__ == "__main__":
    unittest.main()
