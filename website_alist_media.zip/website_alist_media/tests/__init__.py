# -*- coding: utf-8 -*-
# MEDIUM tests (need Odoo): discovered by Odoo's test runner.
#   odoo -d <db> -i website_alist_media --test-enable --test-tags /website_alist_media --stop-after-init
# SMALL tests (no Odoo) are NOT imported here; run them standalone:
#   python3 -m unittest tests.test_small tests.test_cdn_utils -v
#   bash tests/js/run.sh
import importlib.util

if importlib.util.find_spec('odoo') is not None:  # only under Odoo
    from . import test_medium
