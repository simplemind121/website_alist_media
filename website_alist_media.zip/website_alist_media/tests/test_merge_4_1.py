# -*- coding: utf-8 -*-
"""SMALL tests for the 19.0.4.1.0 merge (hermetic, no Odoo). Run:
    cd website_alist_media && python3 -m unittest tests.test_merge_4_1 -v
"""
import importlib.util
import os
import unittest

_HERE = os.path.dirname(__file__)
_spec = importlib.util.spec_from_file_location(
    '_wam_cdn_utils_41', os.path.join(_HERE, '..', 'models', 'cdn_utils.py'))
cdn_utils = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(cdn_utils)
guess = cdn_utils.guess_media_type


class TestGuessMediaType41(unittest.TestCase):
    def test_extensions_still_win(self):
        self.assertEqual(guess('a.PNG'), 'image')
        self.assertEqual(guess('demo.mp4'), 'video')
        self.assertEqual(guess('clip.webm', content_type=5), 'video')

    def test_default_video_ext_browser_playable_only(self):
        self.assertIn('.ogv', cdn_utils.DEFAULT_VIDEO_EXT)
        self.assertNotIn('.mkv', cdn_utils.DEFAULT_VIDEO_EXT)
        self.assertNotIn('.avi', cdn_utils.DEFAULT_VIDEO_EXT)

    def test_alist_integer_type_does_not_crash(self):
        # 3.0.1 crashed here: int has no .split()
        self.assertEqual(guess('notes.txt', content_type=4), 'unknown')
        self.assertEqual(guess('noext', content_type=5), 'image')
        self.assertEqual(guess('noext', content_type=2), 'video')
        self.assertEqual(guess('noext', content_type=0), 'unknown')
        self.assertEqual(guess('noext', content_type='2'), 'video')
        self.assertEqual(guess('noext', content_type=True), 'unknown')

    def test_mime_fallback(self):
        self.assertEqual(guess('blob', content_type='image/jpeg'), 'image')
        self.assertEqual(guess('blob', content_type='video/mp4; codecs="avc1"'), 'video')
        self.assertEqual(guess('blob', content_type='text/plain'), 'unknown')
        self.assertEqual(guess('blob', content_type=None), 'unknown')

    def test_non_web_video_never_via_fallback(self):
        self.assertEqual(guess('movie.mkv', content_type=2), 'unknown')
        self.assertEqual(guess('movie.avi', content_type='video/x-msvideo'), 'unknown')

    def test_explicit_opt_in_still_possible(self):
        self.assertEqual(guess('movie.mkv', video_ext=('.mkv',)), 'video')


if __name__ == '__main__':
    unittest.main()
