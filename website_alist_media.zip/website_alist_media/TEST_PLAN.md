# 测试计划：website_alist_media 19.0.4.1.0（合并版；第 1 节起为 19.0.4.0.0 原计划，仍适用）

| 项 | 内容 |
|---|---|
| 文档状态 | 待执行（Ready for Test） |
| 被测版本 | website_alist_media **19.0.4.0.0**；部署脚本 **v4** |
| 执行方 | 测试 agent（Grok bot），Odoo 19 沙箱 |
| 基线版本 | 19.0.3.0.0（生产当前版本，回归对照） |
| 编写依据 | Google 公开的测试实践：ACC 风险分析（*How Google Tests Software*）、测试规模分级 Small/Medium/Large（Google Testing Blog “Test Sizes”）、Google Issue Tracker 的 Priority/Severity 分级、SRE 发布检查清单（回滚演练、可观测性） |

> 规则：本计划只要求**执行与报告**。执行方**不得修改被测代码**；发现问题按第 9 节提交缺陷，由开发方修复。

---

## 0. 合并版 19.0.4.1.0 增量验收（先做这一节）

合并版 = B 线 19.0.4.0.0 + A 线 19.0.3.0.1 的视频功能。下面每一项都对应「合并时改动过或移植过」的代码，全部 P0。
在 **staging（letaoge 副本）** 上执行，部署后先 Ctrl+Shift+R。浏览器控制台执行 `__websiteAlistMedia`，应看到
`version: "19.0.4.1.0"`，且 `dialogPatch / iconPatch / renderPatch` 均为 `true`。

### 0.1 A 线已实测项 —— 回归（原结果为 PASS，合并后必须仍 PASS）
| ID | 步骤 | 期望 |
|---|---|---|
| M-B1 | 网站编辑 → 正文图片「替换」→ AList → 选一个 **真实 CDN**（media.051288888.xyz）的 mp4 | 插入 `<video controls playsinline>`，class 含 `o_alist_cdn_video`，**不含** `img` / `o_we_custom_image` / `media_iframe_video`；不是 `<img>` |
| M-BG1 | 区块 → 背景 → 视频 → 替换 | 对话框同时有 **Videos** 和 **AList** 两个标签 |
| M-BG2 | AList 标签里只看到文件夹和视频；选 mp4 保存 | 区块有 `o_background_video`，`data-bg-video-src` = CDN mp4 地址 |
| M-BG3 | 保存发布，在**无痕窗口**打开前台 | `.o_bg_video_container.o_bg_video_direct` 内是 `<video autoplay muted loop playsinline>`，自动静音循环播放（**3.0.1 未实测过此项**） |
| M-BG4 | 背景视频改用 Videos 标签里的 Vimeo 样例 | 仍是 iframe，正常播放（原生路径没被破坏） |
| M-BG5 | AList→Vimeo、Vimeo→AList 互相替换；再「移除」 | 均正常；移除后 class 与 data 属性清干净 |
| M-V2 | 正文插入 AList 视频后保存、刷新、再进编辑 | 仍是 `<video>`，类依旧干净（验证保存前清理钩子） |

### 0.2 替换媒体 × AList 矩阵（A 线实测 69/72，复用）
对下列 snippet：拖入页面 → 点图片 → 右侧 Image「替换」→ 对话框应有 **AList** 标签。抽测至少 15 个（含全部 RETEST 与 5 个 Mega Menu），有时间就全测：

`s_accordion_image`, `s_attributes_horizontal`, `s_attributes_vertical`, `s_banner`, `s_card`, `s_card_offset`, `s_cards_grid`, `s_cards_soft`, `s_carousel_cards`, `s_carousel_intro`, `s_closer_look`, `s_company_team`, `s_company_team_basic`, `s_company_team_card`, `s_company_team_detail`, `s_company_team_grid`, `s_company_team_shapes`, `s_company_team_spotlight`, `s_contact_info`, `s_cta_box`, `s_cta_mobile`, `s_cta_mockups`, `s_empowerment`, `s_faq_horizontal`, `s_features_wall`, `s_form_aside`, `s_framed_intro`, `s_freegrid`, `s_image_frame`, `s_image_gallery`, `s_image_hexagonal`, `s_image_punchy`, `s_image_text`, `s_image_text_box`, `s_image_text_overlap`, `s_images_constellation`, `s_images_mosaic`, `s_intro_pill`, `s_key_images`, `s_masonry_block`, `s_media_list`, `s_mega_menu_cards`, `s_mega_menu_images_subtitles`, `s_mega_menu_menu_image_menu`, `s_mega_menu_menus_logos`, `s_mega_menu_thumbnails`, `s_mockup_image`, `s_picture`, `s_pricelist_cafe`, `s_quadrant`, `s_quotes_carousel`, `s_quotes_carousel_minimal`, `s_references`, `s_references_grid`, `s_references_social`, `s_reviews_wall`, `s_shape_image`, `s_showcase`, `s_sidegrid`, `s_striped`, `s_striped_center_top`, `s_striped_top`, `s_tabs_images`, `s_text_image`, `s_three_columns`, `s_timeline_images`, `s_unveil`, `s_wavy_grid`, `s_website_form_info`

A 线未能自动点到、需要人手确认的 3 个：
- `s_blockquote`：N/A（无可替换图片）
- `s_product_list`：点卡片照片 → 右侧 Image 绿色「替换」→ 看有无 AList（注意不要点成背景图）
- `s_quotes_carousel_compact`：点圆形头像 → 替换 → 看有无 AList

### 0.3 仅图片入口（B 线功能，合并后回归）
图库「添加图片」（可多选）、拖入图片 snippet、区块背景**图片**、博客封面、网格「添加图片」、工具栏替换图标：均出现 AList，且**只列图片**；二进制图片字段（如商品主图）**不出现** AList；商品表单「添加媒体」行为与装模块前一致（media_picker 负责）。

### 0.4 本版修复点
| ID | 步骤 | 期望 |
|---|---|---|
| M-T1 | 在 AList 某目录放一个 .txt 和一个无扩展名文件，打开 AList 标签 | 列表正常显示（3.0.1 会报错），.txt 不可插入 |
| M-S1 | 用「网站设计者」账号（非管理员）登录，在浏览器控制台执行：`await (await fetch('/web/dataset/call_kw',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',method:'call',params:{model:'website.alist.media.source',method:'search_read',args:[[]],kwargs:{fields:['token']}}})})).json()` | 返回 `error`（权限错误），拿不到 token；AList 标签仍能正常浏览/插入 |
| M-E1 | 源里 Video Extensions 为空时 | .mkv/.avi 显示但不可插入；手动加 `.mkv` 后可插入 |

### 0.5 通过标准
0.1 全部 PASS、0.2 抽测无失败、0.3/0.4 全部 PASS，才可部署到生产 letaoge。

## 1. 目标与范围

### 1.1 目标
验证 19.0.4.0.0 新增功能正确、19.0.3.0.0 已有功能无退化、部署与回滚流程可靠，产出可支持“是否上线”决策的证据。

### 1.2 范围内
| 阶段 | 功能 |
|---|---|
| v3 回归 | 各插图入口的 AList 标签（仅图片模式、相册多选、背景、封面、网格、工具栏替换图标）及刻意排除项 |
| 阶段 1 | 部署脚本 v4：自动识别容器路径、`--target staging`、部署前自动备份、`--rollback`、兼容性检查；环境变量密钥优先 + 数据库存密钥告警；标签页非阻塞加载 + 重试 |
| 阶段 2 | 缩略图 URL 模板；记住上次目录；AList 索引搜索（子目录）+ 无索引时自动降级；编辑器内上传到 AList/S3 |
| 阶段 3 | 插入图片自动 `loading="lazy"` + `width`/`height`；可选 `srcset`；失效链接巡检（每日定时任务 + 手动） |
| 阶段 4 | 运行时兼容性守卫（`__websiteAlistMedia.compat`）；部署时 Odoo 源码锚点检查；URL 引用索引（“这个文件用在哪”） |

### 1.3 范围外
- 与 media_picker 合并底座（未实现，开发方缺少其源码）。
- 外链图片的裁剪/滤镜/形状处理（已知限制，见 8.3）。
- 真实 CDN 的缩放能力本身（只测模板渲染出的 URL 是否正确）。

### 1.4 前提假设
- 沙箱 Odoo build 尽量与生产一致（生产 `19.0-20260817`）；不一致须在报告中写明。
- 沙箱**必须同时安装 media_picker**（生产装有它，是共存风险的重点）。若无法安装，第 6.6 节标记 BLOCKED 并说明。

---

## 2. ACC 风险分析

### 2.1 Attributes（质量属性）
| ID | 属性 | 含义 |
|---|---|---|
| A1 | 零 filestore | 任何操作都不产生 `ir.attachment` 二进制 |
| A2 | 安全 | 密钥不出服务器；鉴权；上传校验；SSRF；CSRF |
| A3 | 可靠 | AList 故障不卡死编辑器；搜索降级；部署失败可回退 |
| A4 | 兼容 | 不破坏原生编辑器与 media_picker；Odoo 内部变化可被发现 |
| A5 | 可运维 | 备份、回滚、版本核对、可观测标记 |
| A6 | 性能 | 弹窗即时打开；缩略图不拖慢；插图减少布局抖动 |

### 2.2 Components（组件）
| ID | 组件 | 文件 |
|---|---|---|
| C1 | MediaDialog 补丁 | `static/src/media_dialog/alist_media_dialog_patch.js`、`alist_tab_rules.js` |
| C2 | 图标对话框补丁 | 同上 |
| C3 | AList 标签页 UI | `alist_selector.js/.xml` |
| C4 | 上传接口 | `controllers/media.py` `/website_alist_media/upload`；`models/media_source.py` `upload_media` |
| C5 | 搜索 | `models/alist_client.py` `search` |
| C6 | 解析 / srcset | `media_source.resolve_media` |
| C7 | 引用索引与链接巡检 | `models/media_link.py`、定时任务 |
| C8 | 来源配置与密钥 | `media_source.py`、表单视图 |
| C9 | 部署脚本 | `deploy_website_alist_media.sh` |

### 2.3 Capabilities × 风险（H 高 / M 中 / L 低）
风险 = 故障发生可能性 × 对生产的影响。H 项的用例全部为 P0。

| 组件 \ 属性 | A1 | A2 | A3 | A4 | A5 | A6 |
|---|---|---|---|---|---|---|
| C1 | L | – | M | **H** | – | – |
| C2 | L | – | M | **H** | – | – |
| C3 | L | L | **H** | M | – | M |
| C4 | **H** | **H** | M | – | – | M |
| C5 | – | M（越界结果） | M | – | – | L |
| C6 | – | M（SSRF） | L | – | – | M |
| C7 | – | M（SSRF、只读） | M | – | M | L |
| C8 | – | **H** | – | – | – | – |
| C9 | – | M | **H** | M | **H** | – |

---

## 3. 测试策略（按 Google 测试规模）

| 规模 | 定义（Google） | 本计划中的内容 | 由谁提供 |
|---|---|---|---|
| **Small** | 单进程，无网络/数据库/文件系统外部依赖，秒级 | Python 55 项 + JS 26 项，纯逻辑 | 包内已提供，执行方只需运行 |
| **Medium** | 单机，允许本机数据库/localhost，外部网络禁止（mock） | Odoo `TransactionCase` 18 项（`tests/test_medium.py`） | 包内已提供，执行方在 Odoo 中运行 |
| **Large** | 端到端，真实浏览器 + 真实服务 | 第 6 节手工/自动化用例 + 第 7 节部署运维用例 | 执行方按本计划执行 |

执行顺序：Small → Medium → Large。前一级有失败时，后一级仍执行，但报告须标注“前置失败”。

---

## 4. 测试环境

### 4.1 组成
| 组件 | 要求 |
|---|---|
| Odoo | 19.0，与生产 build 尽量一致；容器名建议 `staging-odoo`、数据库容器 `staging-odoo-db`（便于同时验证部署脚本） |
| 已装模块 | website、website_blog、website_sale、**media_picker**、website_alist_media 19.0.3.0.0（作为升级起点） |
| odoo.conf | 含 `dbfilter = ^<库名>$`、`list_db = False` |
| Mock AList | 本机 HTTP 服务，按 4.2 实现；另起一个“CDN”主机名（可同端口不同 Host，或另一端口） |
| 浏览器 | Chrome 最新稳定版；每轮开始前强制刷新 |
| 工具 | Node ≥ 18（JS small 测试）；Python 3.10+ |

### 4.2 Mock AList API 规范（执行方据此实现或扩展已有 8765 mock）
所有响应为 JSON：`{"code": 200, "message": "success", "data": ...}`；错误时 `code != 200`。须校验 `Authorization` 头等于配置的 token（错误返回 `code: 401`）。

| 接口 | 请求 | 返回 `data` |
|---|---|---|
| `POST /api/fs/list` | `{path, page, per_page, refresh}` | `{content: [{name, size, is_dir, sign, thumb}], total}` |
| `POST /api/fs/get` | `{path}` | `{name, size, is_dir, raw_url}`，`raw_url` 形如 `http://<alist>/d/<path>` |
| `POST /api/fs/search` | `{parent, keywords, scope, page, per_page, password}` | `{content: [{parent, name, is_dir, size}], total}`；**须支持开关“索引关闭”**：关闭时返回 `code: 500, message: "search not available"` |
| `PUT /api/fs/put` | 头：`File-Path`（URL 编码）、`Authorization`、`Content-Type`、`Content-Length`、`As-Task`；体：文件字节 | `{}`；须把文件写入 mock 存储，之后 list/get 能看到 |
| `GET /d/<path>` 与 CDN 主机 `GET /<path>` | – | 返回真实图片字节（用于尺寸探测、链接巡检）；可配置某些路径返回 404 |
| 延迟与故障注入 | 环境变量或管理接口 | 可设置固定延迟（如 3000 ms）、整体宕机（拒绝连接） |

测试数据：根目录 `/media`，含子目录 `/media/2026`、至少 40 张图片（跨页）、2 个视频、1 个非媒体文件（`.pdf`），以及 `/private/secret.jpg`（根目录之外，用于越界测试）。至少 1 张图片文件名为中文。

### 4.3 媒体来源配置（沙箱后台）
`API Base URL`=mock AList；`CDN`=mock CDN；`Root Path`=`/media`；`secret_ref`=某环境变量名（容器中已注入 token）；`Token` 字段留空。第 6.4 节会临时改动这些配置，每条用例结束后恢复。

---

## 5. Small 与 Medium 测试执行

### 5.1 Small（全部 P0，要求 100% 通过）
```bash
cd website_alist_media
python3 -m unittest tests.test_small tests.test_cdn_utils -v
bash tests/js/run.sh
```
期望：Python `Ran 55 tests ... OK`；JS `18 tests passed`、`8 simulation tests passed`。

### 5.2 Medium（全部 P0，要求 100% 通过）
在 Odoo 容器内，对**一次性测试库**执行（不要用业务库）：
```bash
odoo -d wam_test_db -i website_alist_media --test-enable \
     --test-tags /website_alist_media --stop-after-init --no-http
```
期望：日志中 `website_alist_media` 的测试 0 failed、0 error。报告须附带完整测试日志片段。
执行完删除 `wam_test_db`（遵守上次事故教训：测试库不得遗留）。

---

## 6. Large 测试用例（端到端）

格式：**ID｜优先级｜前置｜步骤｜期望**。每条用例执行 **3 次**（见第 8.1 节不稳定判定）。每条须附截图；涉及 DOM 的附元素 HTML。

### 6.0 冒烟（P0，任一失败则停止后续 Large 测试并上报）
| ID | 步骤 | 期望 |
|---|---|---|
| L-00-1 | 升级到 19.0.4.0.0 后，浏览器 Console 输入 `__websiteAlistMedia` | `version: "19.0.4.0.0"`、`dialogPatch: true`、`iconPatch: true`、`pluginRegistered: true`，`compat` 四项全为 true |
| L-00-2 | 网站编辑器正文 `/image` | 弹窗出现且**只有一个** AList 标签，标签内列出 `/media` 内容 |
| L-00-3 | 后台「应用」 | 版本 19.0.4.0.0，状态已安装 |

### 6.1 入口覆盖回归（v3 功能，C1/C2）
| ID | 优先级 | 步骤 | 期望 |
|---|---|---|---|
| L-01-1 | P0 | 拖入 Image 积木 | 有 AList，显示“仅图片”提示，视频不显示；选图后替换占位 |
| L-01-2 | P0 | 相册 s_image_gallery → Add | 有 AList；连选 3 张后点添加，3 张全部进入相册；再点已选中项可取消 |
| L-01-3 | P0 | 区块背景 → 图片 → 替换 | 有 AList；保存后前台背景为 CDN URL |
| L-01-4 | P1 | 博客文章封面 → 设置背景 | 有 AList；保存后前台封面正常 |
| L-01-5 | P1 | 网格布局 → Add element → Image | 有 AList；图片进入网格 |
| L-01-6 | P0 | 后台富文本字段中插入图标 → 选中 → 工具栏替换图标 | 标签为 Icons + AList；选图后图标被整个替换为 `<img>`；Ctrl+Z 恢复图标 |
| L-01-7 | P0 | 图文混排 / 轮播替换已有图 | 有且仅有一个 AList |
| L-01-8 | P0 | 评分 s_rating 自定义图标；手风琴 s_accordion 自定义图标 | **无** AList（只有 Icons） |
| L-01-9 | P0 | 网站上可编辑的二进制图片字段（如商品主图，`data-oe-type="image"`） | **无** AList |
| L-01-10 | P1 | 视频背景 | **无** AList |

### 6.2 标签页可靠性（阶段 1，C3）
| ID | 优先级 | 步骤 | 期望 |
|---|---|---|---|
| L-02-1 | P0 | Mock AList 设置 3000 ms 延迟，打开弹窗并切到 AList | 弹窗**立即**打开，AList 标签显示加载动画，约 3 秒后出现内容；其他标签在此期间可正常使用 |
| L-02-2 | P0 | Mock AList 整体宕机，打开 AList 标签 | 显示红色错误和「Retry」按钮，弹窗不卡死，其他标签可用 |
| L-02-3 | P0 | 在 L-02-2 状态下恢复 mock，点 Retry | 内容正常加载，无需关闭弹窗 |
| L-02-4 | P1 | 连续 3 次请求失败后立即再次打开 | 显示“暂时禁用，稍后重试”类提示（熔断）；约 30 秒后恢复 |

### 6.3 浏览体验（阶段 2，C3/C5）
| ID | 优先级 | 步骤 | 期望 |
|---|---|---|---|
| L-03-1 | P1 | 进入 `/media/2026`，关闭弹窗，再打开 | 直接停在 `/media/2026`；Up 按钮可回到 `/media` |
| L-03-2 | P1 | 清除该浏览器站点数据后打开 | 回到根目录，无报错 |
| L-03-3 | P1 | 修改 localStorage 中 `website_alist_media.last_folder` 为 `{"<id>":"/private"}` 后打开 | 列表为 `/media`（被服务端钳制在根目录内），**不显示** `/private` 内容 |
| L-03-4 | P0 | 搜索开启（mock 索引可用），在 `/media` 搜索子目录中文件名 | 结果含子目录文件，提示“此目录及所有子目录” |
| L-03-5 | P0 | mock 搜索索引关闭，重复 L-03-4 | 不报错；提示“索引不可用：仅当前目录”；结果为当前目录的匹配项 |
| L-03-6 | P0 | mock 搜索接口返回一条 `parent: "/private"` 的结果 | 该结果**不显示** |
| L-03-7 | P1 | 来源的搜索方式改为“当前目录” | mock 日志中**没有** `/api/fs/search` 请求 |
| L-03-8 | P2 | 配置缩略图模板 `{origin}/thumb/width={width}{path}` | 网格缩略图 `src` 形如 `<CDN>/thumb/width=320/media/...`；插入的图片仍为原图 URL |
| L-03-9 | P2 | 缩略图模板填错（如 `{nope}`） | 缩略图回退为原图，功能不受影响 |

### 6.4 上传（阶段 2，C4）—— 安全项全部 P0
| ID | 优先级 | 步骤 | 期望 |
|---|---|---|---|
| L-04-1 | P0 | 来源关闭上传 | AList 标签**无**「Upload here」按钮；直接 POST 上传接口返回 error |
| L-04-2 | P0 | 开启上传（上限 20 MB），在 `/media/2026` 上传一张 jpg | 成功提示；列表刷新可见新文件；mock 存储路径为 `/media/2026/<名>`；**`ir.attachment` 条数不变**（上传前后 SQL `SELECT count(*) FROM ir_attachment` 对比） |
| L-04-3 | P1 | 一次选择 3 个文件上传 | 显示逐个进度，3 个全部成功 |
| L-04-4 | P1 | 上传中文名文件 `烟花 产品图.png` | 成功，文件名保留中文 |
| L-04-5 | P0 | 上传 `shell.php`（可通过改文件选择框 accept 或直接 POST） | 被拒绝，mock 未收到 PUT |
| L-04-6 | P0 | 上传超过上限的文件 | 被拒绝；前端先拦截；绕过前端直接 POST 时服务端也拒绝 |
| L-04-7 | P0 | 直接 POST，`folder=/private` 与 `folder=/media/../private` | 均被拒绝，mock 未收到 PUT |
| L-04-8 | P0 | 直接 POST，不带 `csrf_token` | 被拒绝（HTTP 400/403 或 error），mock 未收到 PUT |
| L-04-9 | P0 | 用**非网站设计师**的内部用户会话直接 POST | 被拒绝 |
| L-04-10 | P1 | 仅图片模式（如相册 Add）下上传 | 文件选择框只接受图片扩展名 |
| L-04-11 | P1 | 单选模式上传 1 张 | 上传后该图被自动选中 |
| L-04-12 | P1 | mock 对 PUT 返回 `code: 403` | 前端显示该错误信息；不崩溃 |

### 6.5 插入质量（阶段 3，C3/C6）
| ID | 优先级 | 步骤 | 期望 |
|---|---|---|---|
| L-05-1 | P1 | 正文插入一张 1200×800 的图 | `<img>` 含 `loading="lazy"`、`width="1200"`、`height="800"`、`alt` 为去扩展名的文件名；页面显示比例正确 |
| L-05-2 | P2 | CDN 对该图延迟 5 秒 | 约 3 秒后仍完成插入，只是没有 width/height |
| L-05-3 | P1 | 开启 srcset，模板 `{origin}/r/width={width}{path}`，宽度 `480,960` | `<img>` 含 `srcset` 两项与 `sizes="100vw"` |
| L-05-4 | P1 | srcset 开启但模板填错 | 无 srcset，插入正常 |
| L-05-5 | P1 | 插入视频 | `<video controls playsinline preload="metadata">`，src 为 CDN |

### 6.6 引用索引与链接巡检（阶段 3/4，C7）
| ID | 优先级 | 步骤 | 期望 |
|---|---|---|---|
| L-06-1 | P0 | 在两个页面、一篇博客、一个商品描述中各插入 AList 图（含一处背景图），执行「Scan usage now」 | 「URL usage & health」列出这些 URL；每条“Used in”数量正确；点进去可打开对应记录 |
| L-06-2 | P0 | 扫描前后比较这些页面的 `arch_db` / 内容 | **完全一致**（扫描只读） |
| L-06-3 | P0 | 在 mock CDN 上让其中一个文件返回 404，执行「Check links now」 | 该 URL 状态 Broken(4xx)、http_code 404、列表中红色显示；其余为 OK |
| L-06-4 | P0 | 手工创建一条指向非白名单主机的链接记录后执行检查 | 状态 Error，“Host not allowlisted”，mock/外部**未收到**请求 |
| L-06-5 | P1 | 删除 L-06-1 中一个页面后重新扫描 | 该页面独有的 URL 显示“Used in = 0”，可用「Not used anywhere」筛选出 |
| L-06-6 | P1 | 多语言：页面有中英两种翻译各含不同 AList 图 | 两种语言的图都被索引 |
| L-06-7 | P1 | 设置 → 技术 → 计划任务，手动运行「AList Media: scan URL usage and check links」 | 成功，无错误日志 |
| L-06-8 | P0 | 非网站设计师用户尝试运行扫描（RPC 或菜单） | 被拒绝 |

### 6.7 密钥与配置（阶段 1，C8）
| ID | 优先级 | 步骤 | 期望 |
|---|---|---|---|
| L-07-1 | P0 | 在来源表单的 Token 字段填值 | 表单顶部出现黄色安全警告 |
| L-07-2 | P0 | 同时设置 Token（错误值）和 secret_ref（环境变量为正确值），点 Test Connection | 成功（环境变量优先） |
| L-07-3 | P0 | 浏览器 Network 中查看 `/website_alist_media/sources` 响应 | 不含 token、secret_ref、s3_secret_key、base_url |
| L-07-4 | P1 | 上传上限填 0 或 501 | 保存被拒绝 |

### 6.8 共存与兼容（C1/C2，A4）
| ID | 优先级 | 步骤 | 期望 |
|---|---|---|---|
| L-08-1 | P0 | 商品表单「电子商务媒体 → 添加媒体」（media_picker 功能） | 行为与升级前**完全一致**（先在 19.0.3 上录屏作基线，再在 19.0.4 上对比） |
| L-08-2 | P0 | `/shop` 商品页图库 | 正常显示 |
| L-08-3 | P1 | 执行 L-00-1 时检查 Console | 无 `[website_alist_media]` 警告、无 JS 报错 |
| L-08-4 | P1 | 网站编辑器与后台各打开 10 次媒体弹窗 | 无重复 AList 标签，无 `Duplicate` 类报错 |

---

## 7. 部署与运维测试（C9，A3/A5）

在**沙箱的 staging 容器**上用包内脚本执行。每步记录完整终端输出。

| ID | 优先级 | 步骤 | 期望 |
|---|---|---|---|
| L-09-1 | P0 | 从 19.0.3.0.0 升级：`sudo bash deploy_website_alist_media.sh --target staging` | 识别正确的容器/库/addons 目录；5 项兼容检查均为“兼容”；生成备份；结尾“数据库确认 … 19.0.4.0.0” |
| L-09-2 | P0 | **回滚演练**：升级后在网站上新建一个页面，然后 `--rollback --target staging`，输入库名确认 | 模块回到 19.0.3.0.0；新建页面消失（证明数据库已恢复）；网站可正常访问 |
| L-09-3 | P0 | 回滚确认时输入错误库名 | 取消，数据库与文件均未改变 |
| L-09-4 | P0 | 输错数据库密码 | 立即中止，无任何改动 |
| L-09-5 | P1 | 在安装包中故意放一个会导致 XML 报错的版本 | 脚本报错、**不重启容器**、提示回滚命令 |
| L-09-6 | P1 | 连续部署 7 次 | 备份目录只保留最近 5 份 |
| L-09-7 | P1 | 部署后检查备份文件权限 | 目录 700、`db.dump` 600 |
| L-09-8 | P0 | L-09-1 后检查 `--target prod` 所指的生产容器/库 | **未被触碰**（沙箱中若有模拟生产库，确认其版本未变） |

---

## 8. 通过标准

### 8.1 不稳定（flaky）判定
Large 用例每条执行 3 次：3/3 通过为 PASS；0/3 为 FAIL；1–2/3 为 **FLAKY**，按缺陷上报（至少 P2），并附每次的差异证据。FLAKY 不计为通过。

### 8.2 发布（上线）标准 —— 全部满足才可上线
1. Small、Medium 100% 通过。
2. 所有 P0 用例 PASS（3/3）。
3. P1 用例通过率 ≥ 95%，且未通过项均有开发方书面豁免。
4. 无未关闭的 S0/S1 缺陷。
5. 回滚演练 L-09-2 通过。
6. 目标生产 build 上兼容检查无“变化”警告（或已在 staging 验证过对应入口）。
7. 报告中写明 Odoo build 与生产的差异（若有）。

### 8.3 已知限制（出现时记录为“符合预期”，不作为缺陷）
- 外链图无法使用 Odoo 的裁剪/滤镜/形状；用 AList 图替换带形状的图时形状丢失。
- 外链图不会被转为 webp。
- S3 来源无服务端搜索，始终为“仅当前目录”；S3 上传需要服务器安装 boto3。
- 链接巡检每次最多检查 200 条（最久未检查的优先）。

---

## 9. 缺陷报告格式（参照 Google Issue Tracker）

**Priority（修复紧迫度）**
| 级别 | 定义 |
|---|---|
| P0 | 阻断上线，必须立即修复 |
| P1 | 上线前必须修复，或获得书面豁免 |
| P2 | 应修复，可随后续版本 |
| P3 | 可延后 |
| P4 | 视情况处理 |

**Severity（影响程度）**
| 级别 | 定义 |
|---|---|
| S0 | 系统不可用、数据丢失/损坏、安全漏洞 |
| S1 | 核心功能不可用且无替代方案 |
| S2 | 功能受损但有替代方案 |
| S3 | 轻微问题（文案、样式） |
| S4 | 建议 |

每个缺陷一条，字段：
```
标题：[组件ID] 一句话描述
关联用例：L-xx-x
Priority / Severity：
环境：Odoo build、浏览器版本、是否装 media_picker、模块版本
复现步骤：1. 2. 3.
期望结果：
实际结果：
复现频率：x/3
证据：截图、元素 HTML、Console 原文、Odoo 服务器日志片段（含时间戳）、mock AList 请求日志
是否回归：是（19.0.3 正常）/ 否 / 未知
```

---

## 10. 测试报告模板（交回开发方）

```
# website_alist_media 19.0.4.0.0 测试报告

## 1. 环境
Odoo build：        生产 build：        差异：
media_picker 版本：       浏览器：
__websiteAlistMedia 输出（原文）：

## 2. 汇总
| 规模 | 总数 | PASS | FAIL | FLAKY | BLOCKED | 跳过 |
| Small |
| Medium |
| Large P0 |
| Large P1 |
| Large P2 |
| 部署/运维 |

## 3. 发布标准核对（8.2 逐条：满足/不满足 + 依据）

## 4. 逐条结果
| 用例 | 结果 | 3 次记录 | 证据文件 | 备注 |

## 5. 缺陷列表（按第 9 节格式）

## 6. 风险与观察（未构成缺陷但值得注意的现象）
```
